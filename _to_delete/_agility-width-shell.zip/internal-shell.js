(function () {
  const body = document.body;

  if (!body) return;

  const label = body.dataset.shellLabel || "Internal Tool";
  const icon = body.dataset.shellIcon || "payments";
  const replaceHero = body.dataset.shellReplaceHero === "true";
  // Pages served from a subfolder (e.g. /maintenance/) set
  // data-shell-root="/" so the shell's relative links and images still
  // resolve to the dashboard root instead of the subfolder.
  const shellRoot = body.dataset.shellRoot || "";
  function withRoot(href) {
    const value = String(href || "");
    if (!shellRoot || !value || /^(?:[a-z]+:|\/|#)/i.test(value)) return value;
    return shellRoot + value;
  }

  // ------------------------------------------------------------------
  // Color scheme. Green is the default; red and purple are per-user
  // choices saved on the profile. Applied as data-theme on <html>, which
  // the shared variable blocks in internal-shell.css pick up. The last
  // choice is cached locally so pages paint in the right scheme before
  // the session round-trip completes.
  // ------------------------------------------------------------------
  const THEMES = [
    { key: "green", label: "Green", swatch: "#21692c" },
    { key: "red", label: "Red", swatch: "#a32222" },
    { key: "purple", label: "Purple", swatch: "#635bff" }
  ];

  function applyTheme(theme) {
    const key = THEMES.some((t) => t.key === theme) ? theme : "green";
    if (key === "green") {
      delete document.documentElement.dataset.theme;
    } else {
      document.documentElement.dataset.theme = key;
    }
    document.querySelectorAll(".internal-shell-theme-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.themePick === key);
    });
    return key;
  }

  function cachedTheme() {
    try { return localStorage.getItem("wilsonTheme") || ""; } catch { return ""; }
  }

  applyTheme(cachedTheme());

  function pickTheme(theme) {
    const key = applyTheme(theme);
    try { localStorage.setItem("wilsonTheme", key); } catch {}
    fetch("/api/me/theme", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ theme: key })
    }).catch(() => {});
  }

  document.addEventListener("click", (event) => {
    const btn = event.target.closest?.("[data-theme-pick]");
    if (btn) pickTheme(btn.dataset.themePick);
  });

  function buildThemePicker() {
    return `
      <div class="internal-shell-menu-title" style="margin-top: 12px;">Color Scheme</div>
      <div class="internal-shell-theme-row">
        ${THEMES.map((t) => `
          <button type="button" class="internal-shell-theme-btn" data-theme-pick="${t.key}">
            <span class="internal-shell-theme-dot" style="background: ${t.swatch};"></span>${t.label}
          </button>`).join("")}
      </div>
    `;
  }

  function iconSvg(name) {
    const icons = {
      payments: `
        <svg viewBox="0 0 24 24" fill="none">
          <rect x="3" y="6" width="18" height="12" rx="3" fill="currentColor" opacity="0.18"></rect>
          <rect x="3" y="8" width="18" height="3" rx="1.5" fill="currentColor"></rect>
          <rect x="6" y="14" width="5" height="1.8" rx="0.9" fill="currentColor"></rect>
          <rect x="13" y="14" width="4" height="1.8" rx="0.9" fill="currentColor" opacity="0.65"></rect>
        </svg>
      `,
      sales: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M14.5 3.5l6 6-8.75 8.75-6.5 1 1-6.5L14.5 3.5z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"></path>
          <path d="M12 6l6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `,
      lookup: `
        <svg viewBox="0 0 24 24" fill="none">
          <circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="2"></circle>
          <path d="M16 16L21 21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `,
      link: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M10 14L14 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M8 16H7a4 4 0 010-8h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M16 8h1a4 4 0 010 8h-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `,
      terminal: `
        <svg viewBox="0 0 24 24" fill="none">
          <rect x="5" y="3.5" width="14" height="17" rx="3" stroke="currentColor" stroke-width="2"></rect>
          <rect x="8" y="7" width="8" height="2.5" rx="1.25" fill="currentColor"></rect>
          <circle cx="9" cy="14" r="1" fill="currentColor"></circle>
          <circle cx="12" cy="14" r="1" fill="currentColor"></circle>
          <circle cx="15" cy="14" r="1" fill="currentColor"></circle>
        </svg>
      `,
      card: `
        <svg viewBox="0 0 24 24" fill="none">
          <rect x="3" y="6" width="18" height="12" rx="3" stroke="currentColor" stroke-width="2"></rect>
          <path d="M3 10h18" stroke="currentColor" stroke-width="2"></path>
          <rect x="6" y="14" width="5" height="1.8" rx="0.9" fill="currentColor"></rect>
        </svg>
      `,
      accounting: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M6 4.5V19.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M18 4.5V19.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M6 7.5H18" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M6 12H18" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M6 16.5H18" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `,
      service: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M7 4.5H17L20 7.5V19a2 2 0 01-2 2H7a2 2 0 01-2-2V6.5a2 2 0 012-2z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"></path>
          <path d="M8.5 11H15.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M8.5 15H13" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `,
      home: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M4 11L12 4l8 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
          <path d="M6 10v9a1 1 0 001 1h3.5v-5.5h3V20H17a1 1 0 001-1v-9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
      `,
      commissions: `
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M5 18.5h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M8 15V10" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M12 15V6" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
          <path d="M16 15v-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
      `
    };

    return icons[name] || icons.payments;
  }

  function firstNameOf(user) {
    const name = String(user?.displayName || user?.name || "").trim();
    return name ? name.split(/\s+/)[0] : "";
  }

  // data-shell-label-personal="Dashboard" renders as "<First>'s Dashboard"
  // for the logged-in user ("My Dashboard" when the name is unknown).
  function resolveLabel(session) {
    const personal = body.dataset.shellLabelPersonal;
    if (!personal) return label;
    const user = session?.user || session;
    const first = firstNameOf(user);
    return first ? `${first}'s ${personal}` : `My ${personal}`;
  }

  function canSeePage(session, href) {
    const pages = session?.grantedPages;

    if (!Array.isArray(pages)) {
      return true; // legacy sessions without page lists keep full nav
    }

    const path = "/" + String(href || "").split("?")[0].replace(/^\//, "");
    return pages.includes(path);
  }

  function filterLinksForSession(links, session) {
    return links
      .map((link) => {
        if (Array.isArray(link.children)) {
          const children = link.children.filter((child) => canSeePage(session, child.href));
          return children.length ? { ...link, children } : null;
        }

        if (link.href && link.href !== "logout.html" && !canSeePage(session, link.href)) {
          return null;
        }

        return link;
      })
      .filter(Boolean);
  }

  function buildMenuLinks(session) {
    const user = session?.user || session;
    const links = [
      {
        href: "dashboard.html",
        title: "Home",
        icon: "home"
      },
      {
        title: "Payments",
        children: [
          { href: "index.html", title: "Send Payment Link" },
          { href: "terminal.html", title: "Send To Card Reader" },
          { href: "charge-saved-card.html", title: "Charge A Saved Card" },
          { href: "hvac-dashboard.html", title: "Deposit Agreements" }
        ]
      },
      {
        title: "Accounting",
        children: [
          { href: "paid-order-detail.html", title: "Paid Order Detail" },
          { href: "intent-lookup.html", title: "Issue Refund" },
          { href: "refund-dashboard.html", title: "Refund Dashboard" },
          { href: "incoming-payouts.html", title: "Incoming Payouts" },
          { href: "bank-balancing.html", title: "Bank Balancing" },
          { href: "credit-applications.html", title: "Builder Credit Applications" },
          { href: "mileage.html", title: "Mileage" },
          { href: "mileage-review.html", title: "Mileage Review" }
        ]
      },
      {
        title: "Client Care",
        children: [
          { href: "appliance-service-calls.html", title: "Service Request Queue" },
          { href: "service-order-health.html", title: "Service Order Health" },
          { href: "service-estimates.html", title: "Service Estimate Approvals" },
          { href: "shopper-profiles.html", title: "Shopper Profiles" }
        ]
      },
      {
        title: "Sales Tools",
        children: [
          { href: "salesdashboard.html", title: "Sales Dashboard" },
          { href: "my-commissions.html", title: "My Commission Review" },
          { href: "sales-order-health.html", title: "Sales Order Health Report" },
          { href: "sales-order-detail.html", title: "Sales Order Detail" },
          { href: "brand-sales.html", title: "Brand Sales" },
          { href: "lead-report.html", title: "DIBS Lead Report" },
          { href: "quote-follow-up.html", title: "Quote Follow-Up" },
          { href: "aging-inventory.html", title: "Aging Inventory" },
          { href: "flag-closures.html", title: "Notification Closure Report" },
          { href: "target-builder.html", title: "Target Builder" },
          { href: "secret-menu.html", title: "Secret Menu" },
          { href: "clearance.html", title: "Clearance Hit List" },
          { href: "shop-orders.html", title: "Online Shop Orders" },
          { href: "spec-packages.html", title: "Spec Packages" },
          { href: "terms-signatures.html", title: "Terms & Conditions Signatures" }
        ]
      },
      {
        title: "Delivery",
        children: [
          { href: "dispatch.html", title: "Delivery Dispatch" },
          { href: "driver.html", title: "Driver Run Sheet" }
        ]
      },
      {
        title: "Installation",
        children: [
          { href: "install-damage.html", title: "Install Damage Report" }
        ]
      },
      {
        title: "Company Tools",
        children: [
          { href: "epass-uploads.html", title: "ePASS Upload Center" },
          { href: "message-automations.html", title: "Text Automations" },
          { href: "event-rsvps.html", title: "Event RSVPs" },
          { href: "signature-builder.html", title: "Email Signature" }
        ]
      },
      {
        title: "HR",
        children: [
          { href: "hr-phone-screen.html", title: "Phone Screen" },
          { href: "hr-candidates.html", title: "Candidates" },
          { href: "uniform-orders.html", title: "Uniform Ordering" }
        ]
      },
      {
        title: "Test Modules",
        children: [
          { href: "satisfaction-survey.html", title: "Client Satisfaction Survey" },
          { href: "satisfaction-results.html", title: "Satisfaction Results" },
          { href: "case-visit-survey.html", title: "Case Visit Survey" },
          { href: "case-visit-results.html", title: "Case Visit Results" }
        ]
      },
      {
        title: "Maintenance Plans",
        children: [
          { href: "/maintenance/admin.html", title: "Today (Command Center)" },
          { href: "/maintenance/customers.html", title: "Customers" },
          { href: "/maintenance/monitoring.html", title: "Refrigeration Guardian" },
          { href: "/maintenance/tech-maintenance.html", title: "Field Tool" },
          { href: "/maintenance/appliance-signup.html", title: "New Quote or Enrollment" },
          { href: "/maintenance/invoice-import.html", title: "Invoice Import" },
          { href: "/maintenance/filter-finder.html", title: "Filter Finder" },
          { href: "/maintenance/index.html", title: "Customer-Facing Site (Demo)" }
        ]
      }
    ];

    if (user?.accessGroup === "executive" || user?.isExecutive) {
      links.push({
        title: "Commissions",
        children: [
          { href: "commissions.html", title: "Sales Commissions" }
        ]
      });
    }

    if (session?.canManageUsers) {
      links.push({
        title: "Admin",
        children: [
          { href: "user-admin.html", title: "User Admin" },
          { href: "audit-log.html", title: "User Activity Audit" },
          { href: "returns-report.html", title: "Returns Report" }
        ]
      });
    }

    links.push({
      href: "logout.html",
      title: "Sign Out",
      text: "End the current dashboard session."
    });

    return filterLinksForSession(links, session).map((link) => {
      if (Array.isArray(link.children) && link.children.length) {
        return `
          <div class="internal-shell-menu-group">
            <button class="internal-shell-menu-link internal-shell-menu-link-button" type="button">
              <div class="internal-shell-menu-link-title">${link.title}</div>
              <span class="internal-shell-menu-link-caret" aria-hidden="true">&rsaquo;</span>
            </button>
            <div class="internal-shell-submenu-panel">
              ${link.children.map((child) => `
                <a class="internal-shell-submenu-link" href="${withRoot(child.href)}">${child.title}</a>
              `).join("")}
            </div>
          </div>
        `;
      }

      const iconHtml = link.icon
        ? `<span class="internal-shell-menu-link-icon" aria-hidden="true" style="display:inline-flex;width:15px;height:15px;vertical-align:-2px;margin-right:8px;">${iconSvg(link.icon).replace("<svg ", '<svg style="width:100%;height:100%;display:block;" ')}</span>`
        : "";
      return `
        <a class="internal-shell-menu-link" href="${withRoot(link.href)}">
          <div class="internal-shell-menu-link-title">${iconHtml}${link.title}</div>
          ${link.text ? `<div class="internal-shell-menu-link-text">${link.text}</div>` : ""}
        </a>
      `;
    }).join("");
  }

  function buildFooterLinks(session) {
    const user = session?.user || session;
    const candidates = [
      { href: "dashboard.html", title: "Home" },
      { href: "paid-order-detail.html", title: "Accounting" },
      { href: "salesdashboard.html", title: "Sales Tools" },
      { href: "event-rsvps.html", title: "Event RSVPs" }
    ];

    const links = candidates
      .filter((link) => canSeePage(session, link.href))
      .map((link) => `<a class="internal-shell-footer-link" href="${withRoot(link.href)}">${link.title}</a>`);

    if (user?.accessGroup === "executive" || user?.isExecutive) {
      links.push(`<a class="internal-shell-footer-link" href="${withRoot("commissions.html")}">Commissions</a>`);
    }

    if (session?.canManageUsers) {
      links.push(`<a class="internal-shell-footer-link" href="${withRoot("user-admin.html")}">User Admin</a>`);
      links.push(`<a class="internal-shell-footer-link" href="${withRoot("audit-log.html")}">Activity Audit</a>`);
    }

    links.push(`<a class="internal-shell-footer-link" href="${withRoot("logout.html")}">Sign Out</a>`);
    return links.join("");
  }

  function buildHeader(user) {
    const headerLabel = resolveLabel(user);
    if (body.dataset.shellLabelPersonal && document.title.includes(label)) {
      document.title = document.title.replace(label, headerLabel);
    }
    return `
      <div class="internal-shell-header">
        <div class="internal-shell-header-top">
          <div class="internal-shell-brand">
            <div class="internal-shell-menu-wrap">
              <button class="internal-shell-menu-trigger" type="button" aria-label="Dashboard menu">
                <span class="internal-shell-menu-bars">
                  <span></span>
                  <span></span>
                  <span></span>
                </span>
              </button>
              <div class="internal-shell-menu-panel">
                <div class="internal-shell-menu-title">Dashboards</div>
                ${buildMenuLinks(user)}
                ${buildThemePicker()}
              </div>
            </div>
            <img class="internal-shell-logo" src="${withRoot("logo-black.png")}" alt="Wilson AC & Appliance" />
            <div class="internal-shell-labels">
              <div class="internal-shell-badge-wrap">
                <span class="internal-shell-badge-icon" aria-hidden="true">${iconSvg(icon)}</span>
                <div class="internal-shell-badge"><span>${headerLabel}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function buildFooter(user) {
    return `
      <div class="internal-shell-footer-row">
        <div class="internal-shell-footer-text">Wilson AC & Appliance internal tools.</div>
        <div class="internal-shell-footer-links">
          ${buildFooterLinks(user)}
        </div>
      </div>
    `;
  }

  async function loadSessionUser() {
    try {
      const response = await fetch("/api/auth/session", {
        credentials: "same-origin"
      });

      if (!response.ok) {
        return null;
      }

      const data = await response.json();
      if (!data.user) return null;
      // Return the full session payload: { user, grantedPages, canManageUsers }
      return { ...data, accessGroup: data.user.accessGroup };
    } catch {
      return null;
    }
  }

  function renderShell(user) {
    if (replaceHero) {
      const hero = document.querySelector(".hero");
      if (hero) {
        hero.innerHTML = buildHeader(user);
      }
    } else {
      const headerHost = document.getElementById("internal-shell-header");
      if (headerHost) {
        headerHost.innerHTML = buildHeader(user);
      }
    }

    const navFooter = document.querySelector(".internal-nav");
    if (navFooter) {
      navFooter.classList.add("internal-shell-footer");
      navFooter.innerHTML = buildFooter(user);
    } else {
      const footerHost = document.getElementById("internal-shell-footer");
      if (footerHost) {
        footerHost.classList.add("internal-shell-footer");
        footerHost.innerHTML = buildFooter(user);
      }
    }
  }

  loadSessionUser().then((session) => {
    renderShell(session);
    // The profile's saved scheme wins over the local cache (covers a new
    // machine, a cleared cache, or a choice made on another device). Either
    // way, re-apply after render so the picker buttons mark the active one.
    if (session?.theme) {
      try { localStorage.setItem("wilsonTheme", session.theme); } catch {}
    }
    applyTheme(session?.theme || cachedTheme());
  });
})();
