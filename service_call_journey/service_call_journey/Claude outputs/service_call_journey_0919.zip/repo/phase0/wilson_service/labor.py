"""Labor pricing (9/18; spec §5): the zone fee, the diagnostic fee, and per-task labor.

    zone_band(miles, bands=(7, 26, 47))        -> 1..4
    zone_fee_lines(miles, units=1, fees=None)  -> [ZNn line] + one ZNADD per extra appliance
    diag_fee_line(miles)                       -> {code: 'DZn', ...}
    miles_from_shop(latlng)                    -> statute miles, straight line from the shop
    quote_labor_lines(db, job, task_hours)     -> zone fee line(s) for the job's location + one line per task at hours × rate

Provenance: fitted to 3,807 zoned tickets 2024–26 in the ePASS labor table (service_labor.labor_rate_code ZN1–ZN4/ZNADD,
DZ1–DZ4). Straight-line bands of 7 / 26 / 47 statute miles from the shop reproduce the zone ePASS charged on 81% of them;
the rest are the office rounding up (downtown 78701 is priced ZN3 at 18.8 mi — hence zone.fee_band). Prices are the 2026
modal rates: ZN1 $120 ×366, ZN2 $130 ×414, ZN3 $140 ×109, ZN4 $150 ×20, ZNADD $85 ×228, DZ1 $157 ×799. The $169.95 the
customer sees on the diagnostic is DZ1 $157 + 8.25% tax. So every quote carries two labor lines — the zone fee and the
component replacement — which is what the office asked for.

The band/fee functions are pure and take plain numbers; the seeded defaults are here so a test can run without a DB, and
quote_labor_lines reads the live values from settings (labor.zone_bands_miles, labor.zone_fees, labor.diag_fees, labor.hourly_rate).
"""
from __future__ import annotations

from typing import Optional

from .db import DB
from .placement import SHOP, _km

ZONE_BANDS = (7, 26, 47)
ZONE_FEES = {"ZN1": 120.0, "ZN2": 130.0, "ZN3": 140.0, "ZN4": 150.0, "ZNADD": 85.0}
DIAG_FEES = {"DZ1": 157.0, "DZ2": 157.0, "DZ3": 179.0, "DZ4": 209.0}
MILES_PER_KM = 0.621371


def miles_from_shop(latlng) -> float:
    if latlng is None:
        return 0.0
    return _km(SHOP, latlng) * MILES_PER_KM


def zone_band(miles: float, bands=ZONE_BANDS) -> int:
    """1 up to and including bands[0] miles, 2 up to bands[1], 3 up to bands[2], 4 beyond."""
    for i, edge in enumerate(bands):
        if miles <= edge:
            return i + 1
    return len(bands) + 1


def zone_fee_lines(miles: float, units: int = 1, fees: Optional[dict] = None, bands=ZONE_BANDS, band: Optional[int] = None) -> list[dict]:
    """The service-zone line for the distance (or the given `band` override) plus one 'Additional Appliance' per extra unit."""
    fees = fees or ZONE_FEES
    b = int(band) if band else zone_band(miles, bands)
    code = f"ZN{b}"
    out = [{"code": code, "desc": f"Service Zone {b}", "amount": float(fees[code]), "auto": True}]
    for _ in range(max(int(units or 1) - 1, 0)):
        out.append({"code": "ZNADD", "desc": "Additional Appliance", "amount": float(fees["ZNADD"]), "auto": True})
    return out


def diag_fee_line(miles: float, fees: Optional[dict] = None, bands=ZONE_BANDS, band: Optional[int] = None) -> dict:
    fees = fees or DIAG_FEES
    b = int(band) if band else zone_band(miles, bands)
    code = f"DZ{b}"
    return {"code": code, "desc": f"Diagnostic Zone {b}", "amount": float(fees[code]), "auto": True}


def _job_miles_and_band(db: DB, job: dict) -> tuple[float, Optional[int]]:
    """Distance for the job (placement.location; else the zone's km_from_shop) and the zone's fee_band override if any."""
    from . import placement
    here = placement.location(db, job)
    zc = job.get("zone_code")
    if not zc and job.get("address_id"):
        zc = (db.fetchone("SELECT zone_code FROM address WHERE address_id=?", (job["address_id"],)) or {}).get("zone_code")
    z = db.fetchone("SELECT fee_band, km_from_shop FROM zone WHERE zone_code=?", (zc,)) if zc else None
    if here is not None:
        miles = miles_from_shop(here)
    elif z and z.get("km_from_shop") is not None:
        miles = float(z["km_from_shop"]) * MILES_PER_KM
    else:
        miles = 0.0
    return miles, (int(z["fee_band"]) if z and z.get("fee_band") else None)


def quote_labor_lines(db: DB, job: dict, task_hours: list[tuple[str, float]]) -> list[dict]:
    """Two kinds of labor line on every quote: the zone fee (by distance from the shop, or the zone's fee_band override,
    plus ZNADD per extra unit) and one line per task at hours × labor.hourly_rate."""
    bands = tuple(db.setting("labor.zone_bands_miles", list(ZONE_BANDS)))
    fees = db.setting("labor.zone_fees", ZONE_FEES)
    rate = float(db.setting("labor.hourly_rate", 130))
    miles, band = _job_miles_and_band(db, job)
    lines = zone_fee_lines(miles, units=job.get("units") or 1, fees=fees, bands=bands, band=band)
    for name, hours in task_hours:
        h = float(hours)
        lines.append({"code": "LAB", "desc": f"{name} {h:g}h", "amount": round(h * rate, 2), "hours": h, "rate": rate, "auto": False})
    return lines
