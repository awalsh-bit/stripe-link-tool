@echo off
REM ===================================================================
REM  WILSON GUARDIAN - find the LoRaWAN gateway on this network
REM
REM  Double-click this file. It looks for the SenseCAP M2 and prints
REM  the address you type into a browser to configure it.
REM
REM  It only listens and pings - it changes nothing, anywhere.
REM ===================================================================
setlocal enabledelayedexpansion
title Find the Guardian gateway
color 0F

echo.
echo   Looking for the Guardian gateway...
echo.

REM The M2's Ethernet MAC. Windows writes MACs with dashes.
set MAC=2c-f7-f1-1d-7b-d2

REM --- First try: it may already be in this PC's address table -------
for /f "tokens=1" %%A in ('arp -a ^| findstr /i "%MAC%"') do set FOUND=%%A
if defined FOUND goto :found

REM --- Otherwise, wake the network up and look again ------------------
REM Find this PC's own address so we know which network to look on.
for /f "tokens=2 delims=:" %%A in ('ipconfig ^| findstr /i /c:"IPv4 Address"') do (
  if not defined MYIP set MYIP=%%A
)
set MYIP=%MYIP: =%
if not defined MYIP goto :nonetwork

for /f "tokens=1,2,3 delims=." %%A in ("%MYIP%") do set PREFIX=%%A.%%B.%%C

echo   Checking %PREFIX%.1 to %PREFIX%.254 - this takes about 20 seconds.
echo.
for /l %%i in (1,1,254) do start /b "" ping -n 1 -w 150 %PREFIX%.%%i >nul 2>&1
timeout /t 20 /nobreak >nul

for /f "tokens=1" %%A in ('arp -a ^| findstr /i "%MAC%"') do set FOUND=%%A
if defined FOUND goto :found
goto :notfound

:found
echo.
echo   ============================================================
echo.
echo      FOUND IT.  The gateway is at:   !FOUND!
echo.
echo      Open a browser and go to:       http://!FOUND!
echo.
echo      Username: admin
echo      Password: the one on the gateway's label
echo.
echo   ============================================================
echo.
echo   Tell Claude the address above and we will carry on.
echo.
pause
exit /b 0

:notfound
echo.
echo   ------------------------------------------------------------
echo   Could not find it on %PREFIX%.x
echo.
echo   That usually means one of three things:
echo     1. Your WiFi and the gateway's wired port are on different
echo        networks (common if there is a guest WiFi).
echo     2. The gateway has not finished getting an address yet -
echo        wait a minute and run this again.
echo     3. It is plugged into a port that is not live.
echo.
echo   Either way, tell Claude what this said and we will find it
echo   another way. Nothing is broken.
echo   ------------------------------------------------------------
echo.
pause
exit /b 1

:nonetwork
echo.
echo   This PC does not seem to have a network address at all.
echo   Check that you are connected to WiFi, then run this again.
echo.
pause
exit /b 1
