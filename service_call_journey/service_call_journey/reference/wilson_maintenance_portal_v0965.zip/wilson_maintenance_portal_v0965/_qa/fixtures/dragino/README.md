# Dragino LHT65N decoders — TEST ORACLES, not product code

These three files are **Dragino's own published payload decoders**, copied
verbatim from their public decoder repository
(`github.com/dragino/dragino-end-node-decoder`, folder `LHT65N/`) on
2026-09-08:

| File here | Upstream name |
|---|---|
| `lht65n-chirpstack-4.0.js` | `LHT65N Chirpstack  4.0 decoder.txt` (note: two spaces before `4.0`) |
| `lht65n-chirpstack-1.5.6.js` | `LHT65N-ChiprstackV4-1.5.6_decoder.txt` (their filename really does misspell "Chirpstack") |
| `lht65n-chirpstack-v3.js` | `LHT65N-chirpstack decoder.txt` — the ChirpStack **v3** style file |

## Why they are in this repository

`tools/guardian-lora-bridge.js` deliberately does **not** decode raw LoRaWAN
bytes. Dragino's decoder is the authoritative one, it gets pasted into the
ChirpStack device profile, and a home-grown copy of it in our tree would be a
second implementation waiting to disagree. That decision is right, and it
leaves exactly one thing untested: **the field-name contract between Dragino's
decoder output and our bridge's reader.**

A wrong field name there is the worst class of bug — the pipe runs, the log
looks calm, and no temperature ever reaches the rules. So
`_qa/verify-lora-bridge.py` closes the gap by running the REAL decoder over
known payload bytes and feeding its REAL output into our bridge. If Dragino
renames a field in a future decoder version, dropping the new file in here and
re-running the suite tells us in one command.

These files are therefore **test fixtures only**:

- nothing under `_qa/` is loaded by any product page or shipped surface;
- they are never inlined into `guardian.html` (see `tools/build_guardian_module.py`);
- they are not in the service worker's app shell.

They are Dragino's work, unmodified, retained here for interoperability
testing against the hardware Wilson bought. If Dragino asks for them to be
removed, `_qa/verify-lora-bridge.py` can point at a locally downloaded copy
instead via `GUARDIAN_DECODER_DIR`.

## What the vectors prove

`decode.js` in this folder emulates the ONE thing ChirpStack does between the
decoder and the MQTT event: it calls `decodeUplink(input)` and stores
**`result.data`**, unwrapping exactly one level. That is verified from
ChirpStack's own source (`chirpstack/src/codec/js/mod.rs`):

```rust
let data = out.fields.get("data").cloned().unwrap_or_default();
if let Some(pbjson_types::value::Kind::StructValue(v)) = data.kind {
    return Ok(v);
}
Err(anyhow!("decodeUplink did not return 'data'"))
```

Three consequences worth knowing before hardware day, all asserted by the
suite:

1. **`TempC_DS` is the external-probe field. `TempC_DS18B20` does not exist**
   in any Dragino LHT65N decoder version (1.3.3 through 1.5.6). A reader
   looking for the longer name silently never matches.
2. **The v3 file cannot be used in a ChirpStack 4 profile at all.** It defines
   `Decode(fPort, bytes)` and no `decodeUplink`, so ChirpStack throws a JS
   error and publishes the uplink with **no `object` field**. The failure looks
   exactly like "codec not pasted yet". This is why
   `docs/GUARDIAN_BRINGUP.md` names the file to paste.
3. **`Bat_status` changed type** between decoder versions — a number `0..3` up
   to v1.5.0, the strings `"Good" / "OK" / "Low" / "Ultra Low"` in v1.5.6. Our
   bridge reads `BatV` (volts, stable in every version) and treats
   `Bat_status` as opaque, which is why both oracles pass.

## Payload vectors used by the suite

Assembled from the per-field worked examples in Dragino's own user manual
(§2.4.2–2.4.6) and then confirmed by executing the decoders above. Dragino
does not publish a complete hex→object example, so these are constructed
payloads with manual-sourced constants, not device captures — stated plainly
because it matters.

| Vector | Hex (fPort 2) | What it is |
|---|---|---|
| nominal | `CBA40ABB025C010ADD0000` | probe fitted, 27.81 °C probe / 27.47 °C internal, 2.98 V |
| no probe | `CBA40ABB025C017FFF0000` | the documented 327.67 °C "no external probe" sentinel |
| negative | `CBA4F5C6025C01F54F0000` | −27.37 °C probe / −26.18 °C internal (two's complement) |
| no ext fitted | `CBA40ABB025C0000000000` | `Ext=0`, no `TempC_DS` key at all |
| probe + timestamp | `0ADD0ABB025C0965B0A1C0` | `Ext=9`: probe in bytes 0–1 and **no `BatV` field** |

Manual constants these reproduce: `0xCBA4 & 0x3FFF = 2980 mV`,
`0x0ABB/100 = 27.47 °C`, `(0xF5C6-65536)/100 = -26.18 °C`,
`0x025C/10 = 60.4 %`, `0x0ADD/100 = 27.81 °C`,
`(0xF54F-65536)/100 = -27.37 °C`.
