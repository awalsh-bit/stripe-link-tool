#!/usr/bin/env node
/*
 * CHIRPSTACK'S HALF OF THE PIPE, EMULATED FOR TESTING ONLY.
 *
 * Usage:  node _qa/fixtures/dragino/decode.js <decoder-file> <hex> [fPort]
 * Prints: {"object": {...}}                      decode succeeded
 *         {"error": "..."}                       ChirpStack would publish the
 *                                                uplink with NO object field
 *
 * Between Dragino's decoder and the MQTT `up` event, ChirpStack v4 does
 * exactly one interesting thing, and this reproduces it:
 *
 *     const out = decodeUplink({bytes, fPort, recvTime, variables});
 *     if (out.errors && out.errors.length) -> decode FAILS, no object
 *     object = out.data            // exactly ONE level unwrapped
 *
 * Verified against chirpstack/src/codec/js/mod.rs (byte-identical in v4.0.0,
 * v4.14.1 and master):
 *
 *     let data = out.fields.get("data").cloned().unwrap_or_default();
 *     if let Some(pbjson_types::value::Kind::StructValue(v)) = data.kind {
 *         return Ok(v);
 *     }
 *     Err(anyhow!("decodeUplink did not return 'data'"))
 *
 * Two behaviours that follow from that single unwrap, and that this file
 * must reproduce faithfully because the suite asserts on both:
 *
 *   - a decoder returning the object BARE (the ChirpStack v3 style, or any
 *     codec that forgets the wrapper) yields NO object at all, not a
 *     mis-shaped one. It is indistinguishable, from the bridge's side, from
 *     "the codec was never pasted in";
 *   - a decoder returning {data:{data:{...}}} yields object = {data:{...}},
 *     because only one level comes off.
 *
 * This is a TEST ORACLE. It is not product code, it is not shipped, and
 * nothing in assets/ or tools/ imports it. See README.md in this folder.
 */
"use strict";

const fs = require("fs");
const vm = require("vm");

const [, , decoderFile, hex, fPortArg] = process.argv;
if (!decoderFile || !hex) {
  console.error("usage: decode.js <decoder-file> <hex> [fPort]");
  process.exit(2);
}

function hexToBytes(text) {
  const clean = String(text).replace(/[^0-9a-fA-F]/g, "");
  if (clean.length % 2) { console.error("odd-length hex"); process.exit(2); }
  const out = [];
  for (let i = 0; i < clean.length; i += 2) out.push(parseInt(clean.substr(i, 2), 16));
  return out;
}

const sandbox = { console: { log: function () {}, warn: function () {}, error: function () {} } };
vm.createContext(sandbox);
try {
  vm.runInContext(fs.readFileSync(decoderFile, "utf8"), sandbox);
} catch (e) {
  console.log(JSON.stringify({ error: "decoder failed to load: " + e.message }));
  process.exit(0);
}

/* ChirpStack calls decodeUplink and nothing else. A file that only defines
   Decode() -- every ChirpStack v3 decoder -- throws a ReferenceError here,
   which is precisely the real-world failure this emulation exists to show. */
if (typeof sandbox.decodeUplink !== "function") {
  console.log(JSON.stringify({ error: "decodeUplink is not defined (this is a ChirpStack v3 style codec; v4 profiles need the 4.0 file)" }));
  process.exit(0);
}

let result;
try {
  result = sandbox.decodeUplink({
    bytes: hexToBytes(hex),
    fPort: Number(fPortArg || 2),
    recvTime: new Date().toISOString(),
    variables: {}
  });
} catch (e) {
  console.log(JSON.stringify({ error: "JS error: " + e.message }));
  process.exit(0);
}

if (result && Array.isArray(result.errors) && result.errors.length) {
  console.log(JSON.stringify({ error: "decodeUplink returned errors: " + result.errors.join(", ") }));
  process.exit(0);
}
if (!result || typeof result !== "object" || !result.data || typeof result.data !== "object") {
  console.log(JSON.stringify({ error: "decodeUplink did not return 'data'" }));
  process.exit(0);
}
console.log(JSON.stringify({ object: result.data }));
