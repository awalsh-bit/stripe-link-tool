#!/usr/bin/env node
/*
 * A MINIMAL MQTT 3.1.1 BROKER — TEST FIXTURE ONLY.
 *
 * Usage: node _qa/fixtures/mqtt-broker.js [port]
 *        prints "listening <port>" on stdout once it is accepting.
 *
 * The real broker is eclipse-mosquitto in tools/guardian-chirpstack, and
 * that is what runs at Wilson. But a suite that needs Docker is a suite
 * that does not run, so this stands in: it is just enough MQTT to fan a
 * PUBLISH out to whoever subscribed, which is the only broker behaviour
 * the bridge and the synthetic node depend on.
 *
 * Supports: CONNECT/CONNACK, SUBSCRIBE/SUBACK (QoS 0, '+' and '#'
 * wildcards), PUBLISH fan-out, PINGREQ/PINGRESP, DISCONNECT.
 * Does NOT support: QoS 1/2, retained messages, wills, sessions, auth.
 * Anything relying on those would be relying on something the product
 * does not use.
 *
 * Not product code. Nothing under assets/ or tools/ imports it.
 */
"use strict";

const net = require("net");
const path = require("path");
const mqtt = require(path.join(__dirname, "..", "..", "tools", "guardian-mqtt-framing.js"));

const PORT = Number(process.argv[2] || 1883);
const clients = [];

/* MQTT topic matching: '+' is exactly one level, '#' is the rest. */
function matches(filter, topic) {
  const f = filter.split("/"), t = topic.split("/");
  for (let i = 0; i < f.length; i += 1) {
    if (f[i] === "#") return true;
    if (i >= t.length) return false;
    if (f[i] !== "+" && f[i] !== t[i]) return false;
  }
  return f.length === t.length;
}

const server = net.createServer(function (socket) {
  const client = { socket: socket, filters: [] };
  clients.push(client);
  let buffer = Buffer.alloc(0);

  socket.on("data", function (chunk) {
    const read = mqtt.readPackets(Buffer.concat([buffer, chunk]));
    buffer = read.rest;
    read.packets.forEach(function (frame) {
      if (frame.type === 1) {                        /* CONNECT  */
        socket.write(Buffer.from([0x20, 0x02, 0x00, 0x00]));   /* CONNACK, accepted */
      } else if (frame.type === 8) {                 /* SUBSCRIBE */
        const packetId = frame.body.slice(0, 2);
        let offset = 2;
        while (offset < frame.body.length) {
          const length = (frame.body[offset] << 8) | frame.body[offset + 1];
          client.filters.push(frame.body.slice(offset + 2, offset + 2 + length).toString("utf8"));
          offset += 2 + length + 1;                  /* +1 for the requested QoS byte */
        }
        socket.write(mqtt.packet(9, 0, Buffer.concat([packetId, Buffer.from([0])])));
      } else if (frame.type === 3) {                 /* PUBLISH (QoS 0) */
        const message = mqtt.readPublish(frame.body);
        clients.forEach(function (other) {
          if (other.socket.destroyed) return;
          if (other.filters.some(function (f) { return matches(f, message.topic); })) {
            other.socket.write(mqtt.publishPacket(message.topic, message.payload));
          }
        });
      } else if (frame.type === 12) {                /* PINGREQ */
        socket.write(Buffer.from([0xd0, 0x00]));     /* PINGRESP */
      } else if (frame.type === 14) {                /* DISCONNECT */
        socket.end();
      }
    });
  });

  const drop = function () {
    const i = clients.indexOf(client);
    if (i > -1) clients.splice(i, 1);
  };
  socket.on("close", drop);
  socket.on("error", drop);
});

server.listen(PORT, "127.0.0.1", function () {
  console.log("listening " + server.address().port);
});
