#!/usr/bin/env python3
"""
THE PILOT MACHINE'S DEPLOYMENT ASSETS.                            (v0.9.64)

Cayden is standing up a dedicated box for the pilot. Three classes of thing
have to be right, and none of them are exercised by any other suite because
none of them run inside this repository:

  1. THE SERVICES SURVIVE A REBOOT. A monitoring system that stops when a
     terminal closes, or when the machine patches itself at 3am, is worse
     than no monitoring system -- everyone believes it is running. So every
     unit must be enabled-able, restart on failure, and point at a file
     that actually exists at the path it claims.

  2. NO CREDENTIAL IS IN THE REPOSITORY. The env file that ships is an
     EXAMPLE with empty values. A real token committed here would be a
     token in every zip, forever.

  3. THE BACKUP COVERS WHAT CANNOT BE REGENERATED. The sensor registry
     holds every customer access key, and the install desk shows each key
     exactly once -- so a backup that quietly omits it is a backup that
     does not matter. Same for the labeled failure-drill dataset.

Run: python3 _qa/verify-deployment.py
"""
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SYSTEMD = ROOT / "tools" / "systemd"

checks = 0
failures = []


def check(label, got, want=True):
    global checks
    checks += 1
    ok = got == want
    print(("ok    " if ok else "FAIL  ") + label.ljust(66) + ("" if ok else f" got {got!r}"))
    if not ok:
        failures.append(label)


def unit_fields(path):
    """A systemd unit is INI-ish; keys can repeat, so collect lists."""
    fields = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("["):
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        fields.setdefault(key.strip(), []).append(value.strip())
    return fields


# The path the documentation tells the operator to install to. Every unit
# has to agree with it, or the copy-paste in the doc produces services that
# cannot find their own program.
INSTALL_ROOT = "/opt/guardian"

# The office module used to need a separate static server; the pilot
# server now serves it from its own origin, which removed both the extra
# unit and the "why does it say the feed is unreachable" support call.
LONG_RUNNING = ["guardian-pilot-server.service", "guardian-lora-bridge.service"]
ALL_UNITS = LONG_RUNNING + ["guardian-backup.service"]


def main():
    # ---- 1. the units ----------------------------------------------------
    print("--- the services ---")
    for name in ALL_UNITS + ["guardian-backup.timer"]:
        check(f"{name} ships", (SYSTEMD / name).exists(), True)

    for name in ALL_UNITS:
        fields = unit_fields(SYSTEMD / name)
        check(f"{name} runs as the unprivileged service account",
              fields.get("User"), ["guardian"])
        # A leading '-' marks the file optional, which is right for the
        # backup (it has working defaults) and wrong for the services that
        # need a token. Either spelling points at the same one file.
        env_files = [v.lstrip("-") for v in fields.get("EnvironmentFile", [])]
        check(f"  ...reads its config from the env file, not from literals",
              env_files == ["/etc/guardian/guardian.env"], True)
        check(f"  ...is installed under {INSTALL_ROOT}",
              all(part.startswith(("/usr/bin/", INSTALL_ROOT))
                  for exec_line in fields.get("ExecStart", [])
                  for part in [exec_line.split()[0]])
              and INSTALL_ROOT in " ".join(fields.get("ExecStart", [])), True)
        check(f"  ...cannot escalate or write outside its own directory",
              fields.get("NoNewPrivileges") == ["true"]
              and fields.get("ProtectSystem") == ["strict"]
              and fields.get("ProtectHome") == ["true"], True)

    for name in LONG_RUNNING:
        fields = unit_fields(SYSTEMD / name)
        # The whole reason these exist: they come back by themselves.
        check(f"{name} restarts itself if it dies", fields.get("Restart"), ["always"])
        check(f"  ...and starts on boot without anyone logging in",
              fields.get("WantedBy"), ["multi-user.target"])

    backup = unit_fields(SYSTEMD / "guardian-backup.service")
    check("the backup runs once and exits, rather than restarting forever",
          backup.get("Type"), ["oneshot"])
    # The two services that need a token must FAIL to start without the env
    # file rather than come up half-configured; the backup may run without
    # one, so its reference is the optional '-' form.
    for name in ["guardian-pilot-server.service", "guardian-lora-bridge.service"]:
        check(f"  {name} requires its env file, not optionally",
              any(not v.startswith("-")
                  for v in unit_fields(SYSTEMD / name).get("EnvironmentFile", [])), True)
    check("  the backup tolerates a missing env file",
          any(v.startswith("-") for v in backup.get("EnvironmentFile", [])), True)
    timer = unit_fields(SYSTEMD / "guardian-backup.timer")
    check("the backup timer fires nightly", bool(timer.get("OnCalendar")), True)
    # A machine that was off overnight must run the missed backup on boot,
    # not silently skip a day.
    check("...and catches up a run missed while the machine was off",
          timer.get("Persistent"), ["true"])
    check("...and is enabled into timers.target", timer.get("WantedBy"), ["timers.target"])

    # Every program a unit launches has to exist in this repository at the
    # path the unit names, allowing for the /opt/guardian install prefix.
    for name in ALL_UNITS:
        for exec_line in unit_fields(SYSTEMD / name).get("ExecStart", []):
            for token in exec_line.split():
                if not token.startswith(INSTALL_ROOT):
                    continue
                relative = token[len(INSTALL_ROOT) + 1:]
                if not relative:
                    continue  # the install root itself (the static server's --directory)
                check(f"  {name} -> {relative} exists in the package",
                      (ROOT / relative).exists(), True)

    if shutil.which("systemd-analyze"):
        for name in ALL_UNITS + ["guardian-backup.timer"]:
            out = subprocess.run(["systemd-analyze", "verify", str(SYSTEMD / name)],
                                 capture_output=True, text=True)
            # The container has no /usr/bin/node, so that one complaint is
            # expected and is not a defect in the unit.
            noise = [ln for ln in (out.stderr + out.stdout).splitlines()
                     if ln.strip() and "is not executable" not in ln
                     and "guardian-backup.sh" not in ln]
            check(f"systemd itself accepts {name}", noise, [])

    # ---- 2. no credentials in the repository ------------------------------
    print("\n--- no secrets ship ---")
    env_example = SYSTEMD / "guardian.env.example"
    check("the environment file that ships is an example", env_example.exists(), True)
    check("no retired unit is left lying around for someone to install",
          (SYSTEMD / "guardian-web.service").exists(), False)
    text = env_example.read_text(encoding="utf-8")
    assignments = dict(
        (m.group(1), m.group(2).strip())
        for m in re.finditer(r"^([A-Z_]+)=(.*)$", text, re.M))
    for secret in ["GUARDIAN_ADMIN_TOKEN", "ALERT_WEBHOOK_URL", "CUSTOMER_ALERT_WEBHOOK_URL"]:
        check(f"  {secret} ships empty", assignments.get(secret, "unset"), "")
    check("  the real file is documented as living outside the repo",
          "/etc/guardian/guardian.env" in text, True)
    # Rehearsal mode on the production box would let invented readings into
    # the archive, so the example must not switch it on.
    check("  rehearsal mode is NOT switched on by the example",
          "\nGUARDIAN_REHEARSAL=1" not in text, True)
    check("  ...though it is explained, so nobody sets it by accident",
          "GUARDIAN_REHEARSAL" in text, True)

    ignored = (ROOT / ".gitignore").read_text(encoding="utf-8")
    for pattern in ["backups/", "guardian-pilot-sensors.json", "guardian-pilot-training.jsonl"]:
        check(f"  .gitignore excludes {pattern}", pattern in ignored, True)

    # ---- 3. the backup covers what cannot be regenerated ------------------
    print("\n--- the backup ---")
    script = ROOT / "tools" / "guardian-backup.sh"
    check("the backup script ships", script.exists(), True)
    check("...and is executable", bool(script.stat().st_mode & stat.S_IXUSR), True)
    body = script.read_text(encoding="utf-8")
    # These three are the ones with no recovery path. The others are nice
    # to have; these are the business.
    for irreplaceable in ["guardian-pilot-sensors.json",      # every customer key
                          "guardian-pilot-training.jsonl",    # the labeled drills
                          "guardian-pilot-history.jsonl"]:    # every reading ever
        check(f"  it backs up {irreplaceable}", irreplaceable in body, True)
    # And deliberately NOT the throwaway one. Checked against the FILES
    # list rather than the whole file, because the script explains in a
    # comment why it is excluded -- and that comment is worth keeping.
    file_list = re.search(r"^FILES=\((.*?)^\)", body, re.S | re.M)
    check("  the backup list parses", bool(file_list), True)
    listed = (file_list.group(1).split() if file_list else [])
    check("  the 48h working window is deliberately NOT in the list",
          "guardian-pilot-data.json" in listed, False)
    check("  ...and the script says why, so nobody 'fixes' it later",
          "guardian-pilot-data.json" in body, True)

    workdir = Path(tempfile.mkdtemp(prefix="guardian-deploy-qa-"))
    (workdir / "tools").mkdir()
    shutil.copy(script, workdir / "tools" / "guardian-backup.sh")
    (workdir / "guardian-pilot-sensors.json").write_text(
        json.dumps({"sensors": [], "customers": [{"key": "x" * 48, "name": "QA"}]}))
    (workdir / "guardian-pilot-training.jsonl").write_text('{"f":37}\n')
    (workdir / "guardian-pilot-history.jsonl").write_text('{"t":1,"c":"a","f":37}\n')
    # Present on a real box and deliberately NOT in the archive.
    (workdir / "guardian-pilot-data.json").write_text("{}")

    run = subprocess.run(["bash", str(workdir / "tools" / "guardian-backup.sh")],
                         capture_output=True, text=True, timeout=60)
    check("running it succeeds", run.returncode, 0)
    archives = sorted((workdir / "backups").glob("guardian-*.tar.gz"))
    check("...producing one archive", len(archives), 1)
    if archives:
        with tarfile.open(archives[0]) as tar:
            members = tar.getnames()
        check("...containing the registry", "guardian-pilot-sensors.json" in members, True)
        check("...the labeled training set", "guardian-pilot-training.jsonl" in members, True)
        check("...the full history", "guardian-pilot-history.jsonl" in members, True)
        check("...and NOT the regenerable working window",
              "guardian-pilot-data.json" in members, False)
        # The archive carries customer access keys. It must not be
        # world-readable on a shared machine.
        mode = stat.S_IMODE(archives[0].stat().st_mode)
        check("the archive is readable by its owner ONLY (it holds customer keys)",
              oct(mode), "0o600")
        check("...as is the directory it sits in",
              oct(stat.S_IMODE((workdir / "backups").stat().st_mode)), "0o700")

    # Running with nothing to back up must not look like a failure, or a
    # fresh machine's first nightly run would page somebody.
    empty = Path(tempfile.mkdtemp(prefix="guardian-deploy-qa-empty-"))
    (empty / "tools").mkdir()
    shutil.copy(script, empty / "tools" / "guardian-backup.sh")
    run = subprocess.run(["bash", str(empty / "tools" / "guardian-backup.sh")],
                         capture_output=True, text=True, timeout=60)
    check("a machine with no data yet backs up cleanly, not noisily", run.returncode, 0)

    # ---- 4. the document a human actually follows -------------------------
    print("\n--- the build document ---")
    doc = (ROOT / "docs" / "GUARDIAN_PILOT_MACHINE.md").read_text(encoding="utf-8")
    check("the build document ships", len(doc) > 4000, True)
    for must_say, why in [
        ("systemctl enable", "the services have to be enabled, not just started"),
        ("sudo reboot", "the reboot test is the one people skip"),
        ("/etc/guardian/guardian.env", "credentials live outside the repo"),
        ("guardian-backup", "backups are part of the build, not an afterthought"),
        ("UPS", "this box is the fleet's single point of failure"),
        ("port forwarding", "the LAN-only rule is restated where it can be broken"),
        ("guardian.html", "the module has to be SERVED, not opened as a file"),
    ]:
        check(f"  it covers: {why}", must_say in doc, True)
    # The rehearsal rig must not be pointed at the production archive.
    # Look at the paragraph AROUND the mention, not just after it -- the
    # warning naturally comes before the command it is warning about.
    at = doc.find("GUARDIAN_REHEARSAL")
    around = doc[max(0, at - 700):at + 300].lower() if at > -1 else ""
    check("  it warns to rehearse on a DIFFERENT machine",
          "different" in around and "invented" in around, True)

    print()
    if failures:
        print(f"{len(failures)} FAILURE(S) of {checks} checks")
        sys.exit(1)
    print(f"ALL {checks} DEPLOYMENT CHECKS PASSED")


if __name__ == "__main__":
    main()
