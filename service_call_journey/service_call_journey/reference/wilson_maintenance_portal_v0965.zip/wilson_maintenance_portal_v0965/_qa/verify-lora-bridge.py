#!/usr/bin/env python3
"""
THE LORA BRIDGE, END TO END.                                      (v0.9.62)

The hardware arrives this week; this suite proves the receiving side before
the box is opened. It boots the REAL pilot server, then pipes
ChirpStack-shaped uplink events through the REAL bridge (--stdin mode uses
the same handleEvent as the MQTT path) and checks that:

  - a decoded LHT65N reading lands in the pilot server as Fahrenheit,
    judged by the production flag rules;
  - the glycol PROBE reading wins over the internal sensor when both exist;
  - Dragino's 327.67 no-probe sentinel falls back to the internal reading
    rather than dispatching a truck to a 621°F freezer;
  - an event with no decoded object (codec not pasted into the device
    profile) is SKIPPED with a message naming the fix, never forwarded;
  - a sustained over-temp series through the bridge produces the same
    DISPATCH the UbiBot path produces — one rules implementation.

AND, SINCE v0.9.62, THE PART THAT WAS NEVER TESTED: the field-name contract
between Dragino's decoder and our reader.

The bridge deliberately does not decode raw bytes — Dragino's decoder is
authoritative and gets pasted into the ChirpStack device profile. That is
the right call, and it left exactly one thing unproven: whether the keys we
read are the keys they emit. A wrong name there is the worst class of bug,
because the pipe runs, the log looks calm, and no temperature ever reaches
the rules.

So the second half of this suite runs DRAGINO'S OWN DECODERS
(_qa/fixtures/dragino/, copied verbatim from their public repo) over known
payload bytes, applies the one transformation ChirpStack applies
(unwrapping `data`), and feeds the REAL decoded object into the REAL bridge.
Every temperature asserted below traces back to a constant in Dragino's own
user manual. Three findings this closes over:

  - `TempC_DS` is the probe field. `TempC_DS18B20` does not exist in ANY
    decoder version — an earlier draft of the bridge read that name as a
    fallback, and it could never have matched.
  - the ChirpStack **v3** decoder file in Dragino's repo cannot be used in a
    v4 device profile at all: it defines Decode() and no decodeUplink(), so
    ChirpStack throws and publishes the uplink with no decoded object. It
    looks exactly like "codec not pasted yet", which is why the skip message
    has to name both.
  - `Bat_status` changed type between decoder versions (0-3, then
    "Good"/"OK"/"Low"). Both versions are run here; the bridge reads volts
    and treats the label as opaque, which is why both pass.

Run: python3 _qa/verify-lora-bridge.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

checks = 0
failures = []


def check(label, got, want=True):
    global checks
    checks += 1
    ok = got == want
    print(("ok    " if ok else "FAIL  ") + label.ljust(66) + ("" if ok else f" got {got!r}"))
    if not ok:
        failures.append(label)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


DEV_FRIDGE = "a84041ffff123456"
DEV_FREEZER = "a84041ffff654321"
# The dispatch drill gets its own channel: the mapping tests above leave
# fresh healthy readings on DEV_FRIDGE, and a healthy point inside the
# hold window would (correctly) break a sustained-over-temp run.
DEV_NOCOOL = "a84041ffffabcdef"
# One channel per decoder version, so the real-payload assertions never
# tread on each other's series.
DEV_DEC40 = "a84041ffffdec040"
DEV_DEC156 = "a84041ffffdec156"
DEV_MIXEDCASE = "A84041FFFFCA5E01"

DECODERS = ROOT / "_qa" / "fixtures" / "dragino"

# Hex payloads assembled from the per-field worked examples in Dragino's own
# user manual (§2.4.2-2.4.6) and confirmed by executing their decoders. See
# _qa/fixtures/dragino/README.md for the constant-by-constant provenance.
VEC_NOMINAL = "CBA40ABB025C010ADD0000"    # probe 27.81C, internal 27.47C, 2.98V
VEC_NO_PROBE = "CBA40ABB025C017FFF0000"   # the documented 327.67C sentinel
VEC_NEGATIVE = "CBA4F5C6025C01F54F0000"   # probe -27.37C, internal -26.18C
VEC_NO_EXT = "CBA40ABB025C0000000000"     # Ext=0: no TempC_DS key at all
VEC_TIMESTAMP = "0ADD0ABB025C0965B0A1C0"  # Ext=9: probe in bytes 0-1, NO BatV


def c_to_f(celsius):
    return celsius * 9 / 5 + 32


def decode(decoder, hex_payload):
    """Run Dragino's real decoder the way ChirpStack runs it."""
    proc = subprocess.run(
        ["node", str(DECODERS / "decode.js"), str(DECODERS / decoder), hex_payload, "2"],
        capture_output=True, text=True, timeout=30, check=True)
    return json.loads(proc.stdout)


def uplink(dev_eui, minutes_ago, obj, extra=None):
    now = datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)
    event = {
        "deviceInfo": {"devEui": dev_eui, "deviceName": "qa-" + dev_eui[-4:]},
        "time": now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
        "fPort": 2,
        "object": obj,
    }
    if extra:
        event.update(extra)
    return json.dumps(event)


def run_bridge(lines, pilot_url):
    env = dict(os.environ, GUARDIAN_PILOT_URL=pilot_url)
    proc = subprocess.run(
        ["node", str(ROOT / "tools" / "guardian-lora-bridge.js"), "--stdin"],
        input="\n".join(lines) + "\n", capture_output=True, text=True, env=env, timeout=30)
    return proc.stdout + proc.stderr


def main():
    workdir = Path(tempfile.mkdtemp(prefix="guardian-lora-qa-"))
    sensors_file = workdir / "sensors.json"
    sensors_file.write_text(json.dumps({"sensors": [
        {"channelId": DEV_FRIDGE, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "qa lora fridge"},
        {"channelId": DEV_FREEZER, "field": "field7", "kind": "freezer", "unit": "C", "label": "qa lora freezer"},
        {"channelId": DEV_NOCOOL, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "qa lora no-cool"},
        {"channelId": DEV_DEC40, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "qa decoder 4.0"},
        {"channelId": DEV_DEC156, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "qa decoder 1.5.6"},
        # Registry entry in UPPER case, as a hand-copy from ChirpStack's web
        # UI would be; the bridge lowercases what it forwards.
        {"channelId": DEV_MIXEDCASE, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "qa mixed case"},
    ]}))

    port = free_port()
    env = dict(os.environ,
               PORT=str(port),
               GUARDIAN_SENSORS_FILE=str(sensors_file),
               GUARDIAN_DATA_FILE=str(workdir / "data.json"),
               GUARDIAN_INCIDENT_FILE=str(workdir / "incidents.jsonl"),
               GUARDIAN_DRILL_FILE=str(workdir / "drills.json"),
               GUARDIAN_TRAINING_FILE=str(workdir / "training.jsonl"))
    server = subprocess.Popen(["node", str(ROOT / "tools" / "guardian-pilot-server.js")],
                              env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    base = f"http://127.0.0.1:{port}"
    pilot_url = base + "/ubibot"
    try:
        for _ in range(50):
            try:
                urllib.request.urlopen(base + "/status.json", timeout=1)
                break
            except Exception:
                time.sleep(0.1)
        else:
            print("FAIL  pilot server never came up")
            sys.exit(1)

        def status():
            with urllib.request.urlopen(base + "/status.json", timeout=5) as res:
                return json.loads(res.read().decode())

        # --- one healthy reading: probe beats internal, C becomes F ---------
        out = run_bridge([uplink(DEV_FRIDGE, 0, {
            "TempC_DS": "2.61", "TempC_SHT": "21.40", "Hum_SHT": "41.2",
            "BatV": 3.04, "Ext": 1,
        })], pilot_url)
        check("the bridge forwards and the pilot server answers SUCCESS", "SUCCESS" in out, True)
        check("...announcing the PROBE reading, not the room-temp internals",
              "2.61°C (probe)" in out, True)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("the reading landed on the right channel", rows[DEV_FRIDGE]["readings"], 1)
        check("...converted to Fahrenheit for the rules (2.61°C ≈ 36.7°F)",
              abs(rows[DEV_FRIDGE]["latest"] - 36.7) < 0.15, True)

        # --- the no-probe sentinel falls back, never forwards 327.67 --------
        out = run_bridge([uplink(DEV_FRIDGE, 0, {
            "TempC_DS": "327.67", "TempC_SHT": "3.05", "Hum_SHT": "40.0", "BatV": 3.01,
        })], pilot_url)
        check("327.67 is treated as 'no probe', internal reading used instead",
              "3.05°C (internal)" in out, True)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("no 621°F reading ever reached the rules",
              rows[DEV_FRIDGE]["latest"] < 100, True)

        # --- codec missing: skip, and say exactly what to fix ---------------
        before = {r["channelId"]: r["readings"] for r in status()["sensors"]}
        out = run_bridge([json.dumps({
            "deviceInfo": {"devEui": DEV_FRIDGE}, "time": "2026-09-03T10:00:00Z", "fPort": 2,
        })], pilot_url)
        check("an event with no decoded object is skipped", "skipped" in out, True)
        check("...and the message names the fix (paste Dragino's codec)",
              "codec" in out, True)
        after = {r["channelId"]: r["readings"] for r in status()["sensors"]}
        check("nothing was forwarded for it", after[DEV_FRIDGE], before[DEV_FRIDGE])

        # --- an unknown DevEUI is rejected by the pilot server itself -------
        out = run_bridge([uplink("ffffffffffffffff", 0, {"TempC_SHT": "4.0"})], pilot_url)
        check("a sensor not in the pilot's sensor file is refused downstream",
              "400" in out or "ERROR" in out, True)

        # --- the same dispatch the UbiBot path produces ----------------------
        # Cayden's example through the LoRa path: 48°F (8.89°C) held over an
        # hour on the fridge channel. One rules implementation, so the same
        # series must produce the same DISPATCH.
        series = []
        for m in range(360, -1, -15):
            c = 8.89 if m <= 70 else 2.78  # 48°F held 70 min, else 37°F
            series.append(uplink(DEV_NOCOOL, m, {"TempC_DS": str(c), "TempC_SHT": "20.0", "BatV": 3.0}))
        run_bridge(series, pilot_url)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("Cayden's 48°-for-an-hour example DISPATCHES through the LoRa path",
              rows[DEV_NOCOOL]["tier"], "dispatch")
        check("...for the production rule's own reason", bool(rows[DEV_NOCOOL]["reason"]), True)
        incidents = status()["incidents"]
        check("and the incident was logged like any other",
              any(i["channelId"] == DEV_NOCOOL and i["tier"] == "dispatch" for i in incidents), True)

        # --- the freezer channel stays quiet on a healthy freezer -----------
        run_bridge([uplink(DEV_FREEZER, m, {"TempC_DS": str(-17.8 + (0.6 if (m // 30) % 2 else 0)), "BatV": 3.1})
                    for m in range(360, -1, -15)], pilot_url)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("a healthy freezer sawtooth through the bridge stays OK",
              rows[DEV_FREEZER]["tier"], "ok")

        # ---- Dragino's REAL decoders over REAL payload bytes -------------
        # Everything above fed the bridge a decoded object we wrote. From
        # here down, the object comes out of Dragino's own code.
        print()
        for decoder, channel, version in (
                ("lht65n-chirpstack-4.0.js", DEV_DEC40, "4.0"),
                ("lht65n-chirpstack-1.5.6.js", DEV_DEC156, "1.5.6"),
        ):
            nominal = decode(decoder, VEC_NOMINAL)
            check(f"[{version}] Dragino's decoder produces an object at all",
                  "object" in nominal and isinstance(nominal.get("object"), dict), True)
            obj = nominal["object"]
            check(f"[{version}] ...and names the probe field TempC_DS",
                  "TempC_DS" in obj and "TempC_DS18B20" not in obj, True)
            check(f"[{version}] ...decoding the manual's 0x0ADD to 27.81C",
                  obj["TempC_DS"], 27.81)
            check(f"[{version}] ...and the manual's 0xCBA4 to 2.98V", obj["BatV"], 2.98)

            out = run_bridge([uplink(channel, 0, obj, {
                "rxInfo": [{"gatewayId": "ac1f09fffe0abcde", "rssi": -104, "snr": 6.5}], "dr": 3,
            })], pilot_url)
            check(f"[{version}] the bridge forwards a real decoded payload", "SUCCESS" in out, True)
            rows = {r["channelId"]: r for r in status()["sensors"]}
            expected_f = round(c_to_f(27.81), 1)
            check(f"[{version}] ...as the probe reading in Fahrenheit",
                  rows[channel]["latest"], expected_f)
            check(f"[{version}] ...carrying the battery voltage to the office",
                  rows[channel]["battery"]["volts"], 2.98)
            check(f"[{version}] ...and the radio quality the RF test needs",
                  rows[channel]["radio"]["rssi"] == -104 and rows[channel]["radio"]["snr"] == 6.5, True)

            # The sentinel, through the real decoder: 327.67 must never be
            # forwarded as a temperature.
            sentinel = decode(decoder, VEC_NO_PROBE)
            check(f"[{version}] an unplugged probe really does decode to 327.67",
                  sentinel["object"]["TempC_DS"], 327.67)
            out = run_bridge([uplink(channel, 0, sentinel["object"])], pilot_url)
            check(f"[{version}] ...and the bridge falls back to the internal reading",
                  "(internal)" in out, True)
            rows = {r["channelId"]: r for r in status()["sensors"]}
            check(f"[{version}] ...so no 621F reading ever reaches the rules",
                  rows[channel]["latest"] < 200, True)
            # And with NOTHING to fall back to, the skip has to say what a
            # technician should actually go and do about it. "No usable
            # temperature" would be true and useless; the sentinel means one
            # specific thing, so it gets named.
            sentinel_only = {k: v for k, v in sentinel["object"].items() if k != "TempC_SHT"}
            out = run_bridge([uplink(channel, 0, sentinel_only)], pilot_url)
            check(f"[{version}] a sentinel with no fallback names the E3 cable",
                  "E3 cable" in out and "no probe attached" in out, True)

            # Negative temperatures: the two's-complement path, which is
            # every freezer reading Wilson will ever take.
            negative = decode(decoder, VEC_NEGATIVE)
            check(f"[{version}] a freezer's negative probe decodes signed",
                  negative["object"]["TempC_DS"], -27.37)
            out = run_bridge([uplink(channel, 0, negative["object"])], pilot_url)
            rows = {r["channelId"]: r for r in status()["sensors"]}
            check(f"[{version}] ...and survives the trip as {round(c_to_f(-27.37), 1)}F",
                  rows[channel]["latest"], round(c_to_f(-27.37), 1))

            # Ext=0: no external probe fitted at all. The internal sensor is
            # all there is, and it must be used rather than skipped.
            no_ext = decode(decoder, VEC_NO_EXT)
            check(f"[{version}] with no probe fitted there is no TempC_DS key",
                  "TempC_DS" not in no_ext["object"], True)
            out = run_bridge([uplink(channel, 0, no_ext["object"])], pilot_url)
            check(f"[{version}] ...and the internal reading is used, not skipped",
                  "(internal)" in out and "SUCCESS" in out, True)

            # Ext=9 (probe + timestamp): TempC_DS moves to bytes 0-1 and
            # BatV vanishes entirely. A reader that assumes BatV is always
            # present breaks on exactly this mode.
            stamped = decode(decoder, VEC_TIMESTAMP)
            check(f"[{version}] probe-plus-timestamp mode omits BatV altogether",
                  "BatV" not in stamped["object"] and "TempC_DS" in stamped["object"], True)
            out = run_bridge([uplink(channel, 0, stamped["object"])], pilot_url)
            check(f"[{version}] ...and the reading still lands, without a battery",
                  "SUCCESS" in out, True)

        # ---- the v3 file: the trap that looks like an unset codec ---------
        print()
        v3 = decode("lht65n-chirpstack-v3.js", VEC_NOMINAL)
        check("Dragino's ChirpStack v3 decoder yields NO object on v4",
              "object" not in v3 and "decodeUplink" in v3.get("error", ""), True)
        # ChirpStack omits `object` entirely in that case -- the same event
        # shape as a profile with no codec at all.
        out = run_bridge([json.dumps({
            "deviceInfo": {"devEui": DEV_DEC40}, "time": "2026-09-08T10:00:00Z", "fPort": 2,
        })], pilot_url)
        check("...and the bridge's skip message names BOTH causes",
              "no payload codec" in out and "v3" in out, True)
        check("...and points at the file to paste instead", "Chirpstack 4.0" in out, True)

        # ---- the phantom field name --------------------------------------
        # No decoder version emits TempC_DS18B20, so nothing may read it:
        # a fallback to a name that never appears is dead code that reads
        # like a safety net.
        bridge_src = (ROOT / "tools" / "guardian-lora-bridge.js").read_text(encoding="utf-8")
        reading_lines = [ln for ln in bridge_src.splitlines() if "Number(object." in ln]
        check("the bridge reads TempC_DS and TempC_SHT, and nothing else",
              sorted(ln.split("Number(object.")[1].split(")")[0].split(",")[0]
                     for ln in reading_lines),
              ["BatV", "TempC_DS", "TempC_SHT"])
        out = run_bridge([uplink(DEV_DEC40, 0, {"TempC_DS18B20": "2.5"})], pilot_url)
        check("...so an object carrying ONLY that name is skipped, loudly",
              "skipped" in out and "no usable temperature" in out, True)

        # ---- the double-wrapped object ------------------------------------
        # ChirpStack strips exactly one `data` level, so Dragino's 1.5.6
        # decoder leaves {data:{...}} on a retransmission frame. A good
        # reading inside a stray wrapper is still a good reading.
        out = run_bridge([uplink(DEV_DEC40, 0, {"data": {"TempC_DS": 3.0, "BatV": 2.9}})], pilot_url)
        check("a reading inside a stray data wrapper is still read",
              "SUCCESS" in out and "3°C (probe)" in out, True)

        # ---- the ChirpStack envelope, as it really arrives ----------------
        # The JSON marshaler omits protobuf defaults, so fPort is ABSENT
        # when it is 0 and dr is absent when 0. Nothing may be required.
        out = run_bridge([json.dumps({
            "deviceInfo": {"devEui": DEV_DEC40},
            "time": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            "object": {"TempC_DS": 2.0, "TempC_SHT": 20.0, "BatV": 3.0},
        })], pilot_url)
        check("an event with no fPort and no dr still forwards", "SUCCESS" in out, True)
        # Uppercase in the registry, lowercase on the wire: one shift key
        # must not cost an evening.
        out = run_bridge([uplink(DEV_MIXEDCASE.lower(), 0, {"TempC_DS": 2.2, "BatV": 3.0})], pilot_url)
        check("a lowercase DevEUI matches an UPPERCASE registry entry", "SUCCESS" in out, True)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("...landing on the canonical lowercase channel",
              rows[DEV_MIXEDCASE.lower()]["readings"] >= 1, True)
        # And the other way round, which is what the ChirpStack UI shows.
        out = run_bridge([uplink(DEV_MIXEDCASE, 0, {"TempC_DS": 2.3, "BatV": 3.0})], pilot_url)
        check("...and an UPPERCASE DevEUI on the wire matches too", "SUCCESS" in out, True)
    finally:
        server.terminate()
        server.wait(timeout=5)

    print()
    if failures:
        print(f"{len(failures)} FAILURE(S) of {checks} checks")
        sys.exit(1)
    print(f"ALL {checks} LORA BRIDGE CHECKS PASSED")


if __name__ == "__main__":
    main()
