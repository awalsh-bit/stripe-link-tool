#!/usr/bin/env python3
"""
THE PILOT SERVER, DRILLED.                                        (v0.9.45)

Cayden: "deploy a few test sensors and force a few failures to see how
everything reacts and if our thresholds catch the fails." Before a single
sensor ships, this suite forces those failures SYNTHETICALLY against the real
ingest server -- the same drills the playbook has a tech perform physically:

  drill 1  a healthy sawtooth        -> stays OK, no incident
  drill 2  a door-open blip          -> stays OK (the sustain windows hold)
  drill 3  Cayden's example: 48°F in a 37°F fridge persisting over an hour
                                     -> DISPATCH
  drill 4  a slow creep that never recovers below the warning line
                                     -> DISPATCH via the recovery rule
  drill 5  a freezer defrost spike   -> stays OK (long freezer windows hold)
  drill 6  silence                   -> OFFLINE incident
  drill 7  Celsius arrives, rules judge Fahrenheit (unit conversion)
  drill 8  LABELING: start a drill, feed readings, end it -> the readings
           carry the drill mode in /export.jsonl, readings outside the
           window export as "healthy", incidents during a drill are stamped
           with the mode, and junk modes are refused (a clean training set
           is the whole point).

The server loads assets/plan-config.js and assets/temp-monitoring.js -- the
one implementation -- so a pass here says the REAL rules catch the fails.

Run: python3 _qa/verify-pilot-server.py
"""
import http.server
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

checks = 0
failures = []


def check(label, got, want=True):
    global checks
    checks += 1
    ok = got == want
    print(("ok    " if ok else "FAIL  ") + label.ljust(66) + ("" if ok else f" got {got!r}"))
    if not ok:
        failures.append(label)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def feeds(series):
    """series: list of (minutes_ago, value_f). Returns UbiBot-shaped feeds
    carrying CELSIUS, the unit a stock channel reports."""
    now = datetime.now(timezone.utc)
    rows = []
    for minutes_ago, value_f in series:
        c = (value_f - 32) * 5 / 9
        rows.append({
            "created_at": (now - timedelta(minutes=minutes_ago)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "field7": {"value": round(c, 2)},
        })
    return rows


def sawtooth(hours, base, swing):
    return [(m, base + (swing if (m // 30) % 2 else 0)) for m in range(hours * 60, -1, -15)]


def main():
    workdir = Path(tempfile.mkdtemp(prefix="guardian-pilot-qa-"))
    sensors_file = workdir / "sensors.json"
    data_file = workdir / "data.json"
    incident_file = workdir / "incidents.jsonl"
    sensors_file.write_text(json.dumps({"sensors": [
        {"channelId": "1001", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge healthy"},
        {"channelId": "1002", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge door"},
        {"channelId": "1003", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge no-cool"},
        {"channelId": "1004", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge creep"},
        {"channelId": "1005", "field": "field7", "kind": "freezer", "unit": "C", "label": "drill freezer defrost"},
        {"channelId": "1006", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge silent"},
        {"channelId": "1007", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge not installed yet"},
        # The customer-alerting drills run on sensors that carry NO
        # installedAt -- a fleet that predates the install desk, and the
        # case that proves burn-in never silences a settled sensor.
        {"channelId": "1008", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge alerting"},
        {"channelId": "1009", "field": "field7", "kind": "freezer", "unit": "C", "label": "drill freezer alerting"},
        # Written UPPERCASE on purpose: ChirpStack's web UI shows DevEUIs in
        # upper case while its JSON publishes them lower, so a hand-copied
        # registry entry must still match every uplink.
        {"channelId": "A84041FFFFCASE01", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "drill fridge mixed case"},
    ], "customers": [
        {"key": "qa-customer-key-aaaabbbbccccddddeeeeffff0001", "name": "QA Residence One",
         "channelIds": ["1001", "1005"]},
        {"key": "qa-customer-key-aaaabbbbccccddddeeeeffff0002", "name": "QA Residence Two",
         "channelIds": ["1007"]},
        {"key": "qa-customer-key-aaaabbbbccccddddeeeeffff0003", "name": "QA Alert Residence",
         "channelIds": ["1008", "1009"], "contact": {"email": "alerts@example.com"}},
    ]}))

    # A local catcher standing in for the production email/SMS sender: the
    # server POSTs customer alerts here when CUSTOMER_ALERT_WEBHOOK_URL is set.
    caught = []

    class Catcher(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            caught.append(json.loads(self.rfile.read(length).decode()))
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *args):
            pass

    hook_port = free_port()
    hook_server = http.server.HTTPServer(("127.0.0.1", hook_port), Catcher)
    threading.Thread(target=hook_server.serve_forever, daemon=True).start()

    notify_file = workdir / "notifications.jsonl"
    history_file = workdir / "history.jsonl"
    port = free_port()
    env = dict(os.environ,
               PORT=str(port),
               GUARDIAN_SENSORS_FILE=str(sensors_file),
               GUARDIAN_DATA_FILE=str(data_file),
               GUARDIAN_INCIDENT_FILE=str(incident_file),
               GUARDIAN_DRILL_FILE=str(workdir / "drills.json"),
               GUARDIAN_TRAINING_FILE=str(workdir / "training.jsonl"),
               GUARDIAN_NOTIFY_FILE=str(notify_file),
               GUARDIAN_HISTORY_FILE=str(history_file),
               GUARDIAN_ADMIN_TOKEN="qa-admin-token-1234",
               CUSTOMER_ALERT_WEBHOOK_URL=f"http://127.0.0.1:{hook_port}/alert")
    server = subprocess.Popen(["node", str(ROOT / "tools" / "guardian-pilot-server.js")],
                              env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(50):
            try:
                urllib.request.urlopen(base + "/status.json", timeout=1)
                break
            except Exception:
                time.sleep(0.1)
        else:
            print("FAIL  server never came up")
            sys.exit(1)

        def post(channel, series):
            body = json.dumps({"channel_id": channel, "feeds": feeds(series)}).encode()
            req = urllib.request.Request(base + "/ubibot", data=body,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=5) as res:
                return res.read().decode()

        def post_raw(pathname, payload):
            """The whole payload, verbatim -- for the LoRa bridge's extra
            siblings (battery, radio) that a UbiBot forward never carries."""
            req = urllib.request.Request(base + pathname, data=json.dumps(payload).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=5) as res:
                return res.read().decode()

        def iso(minutes_ago):
            return (datetime.now(timezone.utc) - timedelta(minutes=minutes_ago)).strftime("%Y-%m-%dT%H:%M:%SZ")

        def status():
            with urllib.request.urlopen(base + "/status.json", timeout=5) as res:
                return json.loads(res.read().decode())

        rules = status()["rules"]
        # Burn-in window and pre-qualification criteria are read from the
        # product's own config, never restated here -- a suite that hard-codes
        # 24 would keep passing after someone changed the window.
        tm_config = json.loads(subprocess.run(
            ["node", "-e",
             "const vm=require('vm'),fs=require('fs');const sb={console:console};sb.window=sb;"
             "vm.createContext(sb);vm.runInContext(fs.readFileSync('assets/plan-config.js','utf8'),sb);"
             "process.stdout.write(JSON.stringify(sb.WILSON_CONFIG.tempMonitoring));"],
            cwd=str(ROOT), capture_output=True, text=True, check=True).stdout)
        commissioning = tm_config["commissioning"]
        prequal = tm_config["prequal"]

        # drill 1: healthy sawtooth around set point
        reply = post("1001", sawtooth(6, 36.5, 2.0))
        check("the forwarding endpoint answers the way UbiBot expects", reply, "SUCCESS")

        # drill 2: 20-minute door blip to 48°F, otherwise 37
        post("1002", [(m, 48.0 if m <= 20 else 37.0) for m in range(360, -1, -15)])

        # drill 3: Cayden's example — 48°F held for the last 70 minutes
        post("1003", [(m, 48.0 if m <= 70 else 37.0) for m in range(360, -1, -15)])

        # drill 4: the slow creep — 43°F (over warn 41, under dispatch 45) for
        # longer than the recovery window
        creep_min = rules["fresh_food"]["recoverWithinMinutes"] + 30
        post("1004", [(m, 43.0 if m <= creep_min else 37.0) for m in range(600, -1, -15)])

        # drill 5: freezer defrost — a 35-minute spike to +28°F on a 0°F box
        post("1005", [(m, 28.0 if 100 <= m <= 135 else 0.0) for m in range(360, -1, -15)])

        # drill 6: the WiFi-kill drill — the sensor reported normally, then
        # went silent well past the offline hold.
        post("1006", [(m, 37.0) for m in range(420, 239, -15)])
        # drill 7 (1007): never reported at all — a sensor still in the box.

        rows = {r["channelId"]: r for r in status()["sensors"]}
        # v0.9.55: the dashboard's Guardian module polls status.json for its
        # live feed, so the rows must carry a chartable series and the
        # response must be readable cross-origin.
        check("status rows carry the recent series for the dashboard module",
              len(rows["1001"].get("points", [])) >= 10, True)
        check("...downsampled to stay phone-friendly",
              len(rows["1001"]["points"]) <= 100, True)
        with urllib.request.urlopen(base + "/status.json", timeout=5) as res:
            cors = res.headers.get("Access-Control-Allow-Origin")
        check("status.json is CORS-readable by the dashboard page", cors, "*")
        check("a healthy sawtooth stays OK", rows["1001"]["tier"], "ok")
        check("a 20-minute door blip does not page anyone", rows["1002"]["tier"], "ok")
        check("Cayden's 48°-for-an-hour example DISPATCHES", rows["1003"]["tier"], "dispatch")
        check("...and the reason names a rule",
              bool(rows["1003"]["reason"]), True)
        check("the creep that never recovers DISPATCHES without touching 45°F",
              rows["1004"]["tier"], "dispatch")
        check("...specifically via the recovery rule",
              "recover" in rows["1004"]["reason"].lower(), True)
        check("a freezer defrost spike stays OK", rows["1005"]["tier"], "ok")
        check("a sensor that went silent past the hold reads OFFLINE", rows["1006"]["tier"], "offline")
        check("a sensor still in the box reads WAITING, not an incident",
              rows["1007"]["tier"], "waiting")
        check("Celsius input was judged in Fahrenheit (latest ≈ 48°F)",
              abs(rows["1003"]["latest"] - 48.0) < 0.2, True)
        check("the rules served are the product's own (warn at the FDA line)",
              rules["fresh_food"]["maxF"], 41)

        incidents = status()["incidents"]
        tiers_logged = {(i["channelId"], i["tier"]) for i in incidents}
        check("the dispatch drills were logged as incidents",
              ("1003", "dispatch") in tiers_logged and ("1004", "dispatch") in tiers_logged, True)
        check("the offline sensor was logged as an incident", ("1006", "offline") in tiers_logged, True)
        check("no incident was ever filed for the healthy or door sensors",
              not any(c in ("1001", "1002", "1005", "1007") for (c, t) in tiers_logged), True)

        # recovery: the no-cool fridge comes back into band -> a recovery
        # transition is logged, so a drill sheet can time it. (Offset minute
        # marks + a pause: UbiBot timestamps carry second resolution, and a
        # same-second repost would collide with the earlier series.)
        time.sleep(1.5)
        post("1003", [(m, 37.0) for m in (52, 37, 22, 7)])
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("a recovered sensor returns to OK", rows["1003"]["tier"], "ok")
        recovered = [i for i in status()["incidents"] if i["channelId"] == "1003" and i["tier"] == "ok"]
        check("...and the recovery itself is on the incident log", len(recovered) >= 1, True)

        # drill 8: LABELING — the lab-notebook side of the showroom drills.
        def post_json(url, payload):
            body = json.dumps(payload).encode()
            req = urllib.request.Request(base + url, data=body,
                                         headers={"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=5) as res:
                    return res.status, json.loads(res.read().decode())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read().decode())

        code, body = post_json("/drill", {"channelId": "1001", "mode": "fan dead"})
        check("a junk drill mode is refused (labels stay canonical)", code, 400)
        code, body = post_json("/drill", {"channelId": "9999", "mode": "no_evap_fan"})
        check("a drill on an unknown channel is refused", code, 400)
        code, body = post_json("/drill", {"channelId": "1001", "mode": "no_evap_fan",
                                          "note": "fan connector pulled, showroom unit 3"})
        check("a drill starts with a canonical mode", code, 200)
        code, body = post_json("/drill", {"channelId": "1001", "mode": "door_open"})
        check("a second drill on the same sensor is refused until the first ends", code, 409)

        time.sleep(1.2)
        post("1001", [(0.0, 50.0), (-0.5, 51.0)])  # readings DURING the drill
        with urllib.request.urlopen(base + "/export.jsonl", timeout=5) as res:
            exported = [json.loads(l) for l in res.read().decode().strip().split("\n")]
        labeled = [r for r in exported if r["channelId"] == "1001" and r["mode"] == "no_evap_fan"]
        healthy = [r for r in exported if r["channelId"] == "1001" and r["mode"] == "healthy"]
        check("readings during the drill export with the drill's label", len(labeled) >= 2, True)
        check("the sensor's pre-drill sawtooth exports as healthy", len(healthy) > 10, True)

        code, body = post_json("/drill/end", {"channelId": "1001", "note": "fan reconnected, recovered"})
        check("ending the drill returns the completed record", code, 200)
        check("...with start and end times for the drill sheet",
              body["drill"]["startedAt"] < body["drill"]["endedAt"], True)
        code, body = post_json("/drill/end", {"channelId": "1001"})
        check("ending twice is refused", code, 404)

        # an incident that fires during a drill is stamped with the mode.
        # 1007 has no prior readings, so the induced curve arrives clean.
        code, body = post_json("/drill", {"channelId": "1007", "mode": "no_compressor"})
        check("a drill starts on the fresh sensor for the incident-stamp check", code, 200)
        time.sleep(1.2)
        post("1007", [(m, 50.0 if m <= 75 else 37.0) for m in range(360, -1, -14)])
        stamped = [i for i in status()["incidents"]
                   if i["channelId"] == "1007" and i["tier"] == "dispatch"]
        check("the dispatch during the drill happened", len(stamped) >= 1, True)
        check("...and the incident is stamped with the drill mode",
              stamped[0].get("drill"), "no_compressor")
        post_json("/drill/end", {"channelId": "1007"})

        with urllib.request.urlopen(base + "/drills", timeout=5) as res:
            drill_state = json.loads(res.read().decode())
        check("the drill log holds both completed drills", len(drill_state["history"]), 2)
        check("the mode list is published for the drill sheet",
              "failed_defrost" in drill_state["modes"], True)

        with urllib.request.urlopen(base + "/export.csv", timeout=5) as res:
            csv_text = res.read().decode()
        check("the CSV export leads with its header",
              csv_text.startswith("t,channel_id,label,kind,temp_f,mode"), True)
        check("the CSV carries the drill label too", ",no_evap_fan" in csv_text, True)

        # drill 9: THE CUSTOMER DOOR — a key shows one household's sensors,
        # in customer language, and nothing else in the world.
        def customer(key):
            try:
                with urllib.request.urlopen(base + "/customer.json?key=" + key, timeout=5) as res:
                    return res.status, json.loads(res.read().decode()), res.headers.get("Access-Control-Allow-Origin")
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read().decode()), e.headers.get("Access-Control-Allow-Origin")

        code, body, cors = customer("qa-customer-key-aaaabbbbccccddddeeeeffff0001")
        check("a valid key opens the customer view", code, 200)
        check("...readable cross-origin (the page lives on the website)", cors, "*")
        check("it names the household", body["name"], "QA Residence One")
        labels = sorted(s["label"] for s in body["sensors"])
        check("it lists exactly that customer's sensors",
              labels, ["drill freezer defrost", "drill fridge healthy"])
        one = [s for s in body["sensors"] if s["label"] == "drill fridge healthy"][0]
        check("a sensor speaks customer language, not office tiers",
              one["status"] == "protected" and "holding" in one["statusNote"].lower(), True)
        check("...and carries the chartable series", len(one.get("points", [])) >= 10, True)
        blob = json.dumps(body)
        # Internal FIELD NAMES, not words -- the fixture labels contain
        # "drill" and honest customer copy may say "priority".
        check("no internal fields leak to the customer payload",
              any(k in blob for k in ['"tier"', '"reason"', '"overForMinutes"', '"silentMinutes"', '"readings"', '"stats"']), False)
        check("no other household leaks into it", "not installed" in blob or "1007" in blob, False)

        code, body, cors = customer("qa-customer-key-aaaabbbbccccddddeeeeffff0002")
        check("the second household sees only its own sensor",
              code == 200 and [s["label"] for s in body["sensors"]] == ["drill fridge not installed yet"], True)
        check("...whose trouble reads as a response, not a jargon flag",
              body["sensors"][0]["status"] in ("responding", "watching"), True)

        code, body, cors = customer("qa-customer-key-wrong-wrong-wrong-wrong-000000")
        check("a wrong key gets a bare 404", code == 404 and body == {"error": "not found"}, True)
        code, body, cors = customer("short")
        check("a short key gets the IDENTICAL 404 (nothing to enumerate)",
              code == 404 and body == {"error": "not found"}, True)

        # drill 10: THE INSTALL DESK — a sensor bound to a household in one
        # call, with the key minted server-side and shown exactly once.
        def admin(method, url, payload=None, token="qa-admin-token-1234"):
            data = json.dumps(payload).encode() if payload is not None else None
            req = urllib.request.Request(base + url, data=data, method=method,
                                         headers={"Content-Type": "application/json",
                                                  "x-guardian-admin": token})
            try:
                with urllib.request.urlopen(req, timeout=5) as res:
                    return res.status, json.loads(res.read().decode())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read().decode())

        code, body = admin("GET", "/admin/customers", token="wrong")
        check("a wrong admin token is refused", code, 403)
        code, body = admin("GET", "/admin/customers")
        check("the household picker lists names, never keys",
              code == 200 and len(body["customers"]) == 3
              and all("key" not in c for c in body["customers"]), True)

        code, body = admin("POST", "/admin/install", {
            "channelId": "A84041FFFF0AB001", "kind": "fresh_food",
            "label": "Kitchen column — fresh food",
            "householdName": "The Install Test Residence",
            "contactEmail": "install-test@example.com"})
        check("an install with a new household succeeds", code, 200)
        check("...minting a real key, returned exactly this once",
              body.get("created") is True and len(body.get("key", "")) >= 48, True)
        new_key = body["key"]
        new_household = body["customer"]["id"]
        check("...and the DevEUI is normalized to lowercase",
              body["sensor"]["channelId"], "a84041ffff0ab001")
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("the new sensor joins the fleet as Waiting",
              rows["a84041ffff0ab001"]["tier"], "waiting")
        code, body, _cors = customer(new_key)
        check("the new key opens the new household's customer view",
              code == 200 and body["name"] == "The Install Test Residence", True)

        code, body = admin("POST", "/admin/install", {
            "channelId": "a84041ffff0ab002", "kind": "freezer",
            "label": "Kitchen column — freezer", "householdId": new_household})
        check("a second sensor joins the same household without a new key",
              code == 200 and "key" not in body and len(body["customer"]["channelIds"]) == 2, True)
        code, body = admin("POST", "/admin/install", {
            "channelId": "1001", "kind": "fresh_food", "label": "Stolen sensor",
            "householdId": new_household})
        check("a sensor bound to another household is refused",
              code == 409 and "QA Residence One" in body["error"], True)
        registry = json.loads(sensors_file.read_text())
        check("the registry file persisted the install",
              any(s["channelId"] == "a84041ffff0ab001" for s in registry["sensors"])
              and any(c["name"] == "The Install Test Residence" and c["key"] == new_key
                      for c in registry["customers"]), True)

        # drill 11: CUSTOMER ALERTING — dispatch and all-clear reach the
        # outbox and the webhook, in customer voice; warns never do.
        post("1008", [(m, 48.0 if m <= 70 else 37.0) for m in range(360, -1, -15)])
        time.sleep(0.8)
        notes = [json.loads(l) for l in notify_file.read_text().strip().split("\n")] if notify_file.exists() else []
        # The earlier incident-stamp drill dispatched 1007, which belongs to
        # QA Residence Two — so that household was (correctly) notified too.
        check("every dispatch on a customer's channel notified that customer",
              sorted(set(n["name"] for n in notes if n["tier"] == "dispatch")),
              ["QA Alert Residence", "QA Residence Two"])
        dispatch_notes = [n for n in notes if n["tier"] == "dispatch" and n["name"] == "QA Alert Residence"]
        check("a settled sensor's dispatch notified once, not per evaluation", len(dispatch_notes), 1)
        check("...addressed to the household's contact",
              dispatch_notes[0]["to"].get("email"), "alerts@example.com")
        check("...in customer voice, office jargon absent",
              "responding as a priority" in dispatch_notes[0]["text"]
              and "tier" not in dispatch_notes[0]["text"].lower(), True)
        check("...and delivered to the alert webhook",
              any(c["tier"] == "dispatch" and c["name"] == "QA Alert Residence" for c in caught), True)

        time.sleep(1.2)
        post("1008", [(m, 37.0) for m in (51.0, 36.0, 21.0, 6.0)])
        time.sleep(0.8)
        notes = [json.loads(l) for l in notify_file.read_text().strip().split("\n")]
        check("recovery sends the all-clear",
              any(n["tier"] == "ok" and "back in its safe range" in n["text"] for n in notes), True)

        # A warn on the freezer channel: the office's business, not a page.
        post("1009", [(m, 14.0 if m <= 70 else 0.0) for m in range(360, -1, -15)])
        time.sleep(0.8)
        notes = [json.loads(l) for l in notify_file.read_text().strip().split("\n")]
        check("a warn never notifies the customer",
              any(n["sensorLabel"] == "drill freezer alerting" for n in notes), False)
        check("...though the office still sees it",
              any(i["channelId"] == "1009" and i["tier"] == "warn"
                  for i in status()["incidents"]), True)

        # drill 12: THE ANALYSIS ENDPOINT — arbitrary windows, honest
        # thinning, and statistics that never disagree with the chart.
        def history(query):
            with urllib.request.urlopen(base + "/history.json?" + query, timeout=10) as res:
                return json.loads(res.read().decode())

        admin("POST", "/admin/install", {
            "channelId": "a84041ffff0ab003", "kind": "freezer",
            "label": "Analysis drill freezer", "householdId": new_household})
        # A dense week on its OWN channel: 5-minute cadence at 0°F —
        # its actual set point — with one deliberate 24°F spike buried in
        # the middle, over that band's 20°F dispatch line.
        dense = []
        spike_at = 3000
        for i in range(2016):  # 7 days at 5-minute spacing
            minutes_ago = (2016 - i) * 5
            dense.append((minutes_ago, 24.0 if minutes_ago == spike_at else 0.0))
        for chunk in range(0, len(dense), 400):
            post("a84041ffff0ab003", dense[chunk:chunk + 400])

        h = history("channel=a84041ffff0ab003&from=" + str(int(time.time() * 1000) - 8 * 86400000))
        check("the analysis endpoint serves an arbitrary window",
              h["rawCount"] >= 2000, True)
        check("...thinned for drawing", h["downsampled"] is True and len(h["points"]) <= 1200, True)
        check("...but the spike SURVIVES the thinning (extremes preserved)",
              any(abs(p["f"] - 24.0) < 0.2 for p in h["points"]), True)
        check("...and the stats describe full resolution, not the drawn line",
              abs(h["stats"]["max"] - 24.0) < 0.2 and h["stats"]["readings"] == h["rawCount"], True)
        check("the window carries its band's own rule, from config",
              h["rule"]["maxF"], rules["freezer"]["maxF"])
        # One reading above the line represents its own 5-minute interval —
        # not "1 reading", and not the 15 minutes a coarser cadence would
        # imply. Cadence must not change the hours reported.
        check("time over the warn line is measured in minutes, not readings",
              0 < h["stats"]["overWarnMinutes"] <= 10, True)
        check("...and the dispatch line is counted separately",
              0 < h["stats"]["overDispatchMinutes"] <= 10, True)

        # Zooming to a narrow window returns full resolution and the SAME peak.
        now_ms = int(time.time() * 1000)
        narrow = history("channel=a84041ffff0ab003&from=" + str(now_ms - spike_at * 60000 - 3600000) +
                         "&to=" + str(now_ms - spike_at * 60000 + 3600000))
        check("a zoomed window comes back at full resolution",
              narrow["downsampled"] is False, True)
        check("...reporting the identical peak as the wide view",
              abs(narrow["stats"]["max"] - h["stats"]["max"]) < 0.05, True)

        empty = history("channel=a84041ffff0ab003&from=100000&to=200000")
        check("a window with no readings answers honestly, not with an error",
              empty["rawCount"] == 0 and empty["stats"] is None, True)
        code = 0
        try:
            history("channel=nope")
        except urllib.error.HTTPError as e:
            code = e.code
        check("an unknown channel is refused", code, 404)

        with urllib.request.urlopen(base + "/history.csv?channel=a84041ffff0ab003", timeout=10) as res:
            csv_text = res.read().decode()
            disposition = res.headers.get("Content-Disposition")
        check("the window exports as CSV for the spreadsheet crowd",
              csv_text.startswith("t,channel_id,label,kind,temp_f"), True)
        check("...as a download, named for its channel",
              "attachment" in (disposition or "") and "a84041ffff0ab003" in (disposition or ""), True)

        # History outlives the 48-hour working window: the store prunes,
        # the archive does not.
        old = history("channel=a84041ffff0ab003&from=" + str(now_ms - 7 * 86400000) +
                      "&to=" + str(now_ms - 3 * 86400000))
        check("readings older than the 48h live window are still there",
              old["rawCount"] > 100, True)

        # drill 13: BURN-IN — a sensor installed minutes ago is at room
        # temperature in a glycol vial that has not equilibrated. It must
        # chart, and it must not page anyone.
        before_incidents = len(status()["incidents"])
        before_notes = len(notify_file.read_text().strip().split("\n")) if notify_file.exists() else 0
        post("a84041ffff0ab001", [(m, 48.0 if m <= 70 else 37.0) for m in range(360, -1, -15)])
        time.sleep(0.8)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        burning = rows["a84041ffff0ab001"]
        check("a freshly installed sensor reads BURNIN, not DISPATCH", burning["tier"], "burnin")
        check("...while the office still sees what the rules actually said",
              burning["underlyingTier"], "dispatch")
        check("...with the countdown and the window from config",
              burning["commissioning"]["burningIn"] is True
              and burning["commissioning"]["hoursLeft"] == commissioning["hours"], True)
        check("...the reason says settling in, and admits what was suppressed",
              "settling in" in burning["reason"].lower() and "dispatch" in burning["reason"], True)
        check("no incident was logged during burn-in",
              len(status()["incidents"]), before_incidents)
        after_notes = len(notify_file.read_text().strip().split("\n")) if notify_file.exists() else 0
        check("...and no customer was paged", after_notes, before_notes)
        code, body, _cors = customer(new_key)
        settling = [x for x in body["sensors"] if x["label"] == "Kitchen column — fresh food"]
        check("the customer's page says settling in, NEVER Protected",
              settling[0]["status"] == "settling" and settling[0]["statusLabel"] != "Protected", True)
        check("...in plain language, with no office vocabulary",
              "burn" not in settling[0]["statusNote"].lower()
              and "dispatch" not in settling[0]["statusNote"].lower(), True)
        # Offline still outranks burn-in: a failed install is not a
        # settling one, and a silent sensor is a customer paying for
        # nothing.
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("a sensor that never reported still reads WAITING, not BURNIN",
              rows["a84041ffff0ab002"]["tier"] in ("waiting", "warn", "ok"), True)

        # drill 14: CASE — the registry says A84041FFFFCASE01, ChirpStack
        # publishes a84041ffffcase01. One shift key must not cost an
        # evening.
        reply = post("a84041ffffcase01", [(0, 37.0)])
        check("a lowercase uplink matches an UPPERCASE registry entry", reply, "SUCCESS")
        rows = {r["channelId"]: r for r in status()["sensors"]}
        check("...and the reading landed", rows["a84041ffffcase01"]["readings"] >= 1, True)
        check("...under the canonical lowercase id",
              "A84041FFFFCASE01" not in rows, True)
        h_case = history("channel=A84041FFFFCASE01")
        check("the analysis endpoint accepts either case too", h_case["rawCount"] >= 1, True)

        # drill 15: BATTERY AND RADIO — the two numbers the RF
        # pre-qualification week is actually about.
        # Distinct timestamps on purpose: record() drops exact-time repeats
        # as duplicates, so two posts inside the same second would silently
        # become one -- which is how the first draft of this drill "proved"
        # that battery data never arrived.
        post_raw("/ubibot", {"channel_id": "a84041ffffcase01",
                             "feeds": [{"created_at": iso(9), "field7": {"value": 3.1}}],
                             "battery": {"volts": 3.02, "status": "Good"},
                             "radio": {"rssi": -103, "snr": 4.5, "dr": 3}})
        time.sleep(0.4)
        rows = {r["channelId"]: r for r in status()["sensors"]}
        radio = rows["a84041ffffcase01"]
        check("battery volts arrive with the reading", radio["battery"]["volts"], 3.02)
        check("...and read as a healthy cell", radio["battery"]["level"], "ok")
        check("radio quality arrives with the reading",
              radio["radio"]["rssi"] == -103 and radio["radio"]["snr"] == 4.5, True)
        with urllib.request.urlopen(base + "/history.csv?channel=a84041ffffcase01", timeout=10) as res:
            batt_csv = res.read().decode()
        check("the CSV export carries battery and radio columns",
              batt_csv.startswith("t,channel_id,label,kind,temp_f,battery_v,rssi,snr"), True)
        check("...with the values in them", ",3.02,-103,4.5" in batt_csv, True)

        # A cell crossing the replace line announces itself ONCE, to the
        # office only -- a battery is Wilson's errand, not the customer's
        # alarm.
        battery_incidents_before = len([i for i in status()["incidents"] if i.get("tier") == "battery"])
        notes_before = len(notify_file.read_text().strip().split("\n")) if notify_file.exists() else 0
        for offset, volts in ((8, 2.58), (7, 2.57), (6, 2.56)):
            post_raw("/ubibot", {"channel_id": "a84041ffffcase01",
                                 "feeds": [{"created_at": iso(offset), "field7": {"value": 3.0}}],
                                 "battery": {"volts": volts, "status": "Low"}})
            time.sleep(0.2)
        battery_incidents = [i for i in status()["incidents"] if i.get("tier") == "battery"]
        check("a low cell logs a battery notice",
              len(battery_incidents) - battery_incidents_before, 1)
        check("...naming the level and the voltage",
              battery_incidents[0]["level"] == "replace" and battery_incidents[0]["volts"] == 2.58, True)
        notes_after = len(notify_file.read_text().strip().split("\n")) if notify_file.exists() else 0
        check("...and never pages the customer about it", notes_after, notes_before)
        # Crossing FURTHER announces again: replace and critical are
        # different errands.
        post_raw("/ubibot", {"channel_id": "a84041ffffcase01",
                             "feeds": [{"created_at": iso(5), "field7": {"value": 3.0}}],
                             "battery": {"volts": 2.44, "status": "Ultra Low"}})
        time.sleep(0.3)
        levels = [i["level"] for i in status()["incidents"] if i.get("tier") == "battery"]
        check("crossing to critical announces again", sorted(set(levels)), ["critical", "replace"])

        # drill 16: THE RF PRE-QUALIFICATION REPORT — the go/no-go
        # instrument. a84041ffff0ab003 carries a dense unbroken week at a
        # 5-minute cadence, so it must PASS the gap criterion; the criteria
        # themselves come from config.
        with urllib.request.urlopen(base + "/prequal.json?channel=a84041ffff0ab003", timeout=10) as res:
            pq = json.loads(res.read().decode())["sensors"][0]
        check("the pre-qual report grades against the config criteria",
              pq["criteria"]["maxGapMinutes"] == prequal["maxGapMinutes"]
              and pq["criteria"]["minDeliveryPct"] == prequal["minDeliveryPct"], True)
        check("an unbroken week passes the longest-gap criterion",
              pq["checks"]["gap"]["pass"], True)
        check("...and reports the observed cadence beside the assumed one",
              pq["observedMedianIntervalMinutes"], 5)
        check("...saying plainly that the two disagree",
              pq["intervalMatchesConfig"], False)
        check("a week of coverage satisfies the duration criterion",
              pq["checks"]["duration"]["pass"], True)
        # The channel that has only ever had a handful of readings cannot
        # pass, and says so rather than dividing by hope.
        with urllib.request.urlopen(base + "/prequal.json?channel=1002", timeout=10) as res:
            thin = json.loads(res.read().decode())["sensors"][0]
        check("a sparse channel fails rather than flattering itself",
              thin["verdict"], "fail")
        # A deliberate hole longer than the dispatch hold is a FAIL even
        # with a high delivery ratio -- clustered loss is the thing that
        # hides a real event.
        gap_rows = []
        gap_start = int(time.time() * 1000) - 8 * 86400000
        for i in range(500):
            # 20-minute cadence with a 3-hour hole two days in
            offset = i * 20 * 60000
            if 2 * 86400000 <= offset < 2 * 86400000 + 3 * 3600000:
                continue
            gap_rows.append({"t": gap_start + offset, "c": "1002", "f": 37.0})
        with history_file.open("a") as fh:
            for row in gap_rows:
                fh.write(json.dumps(row) + "\n")
        # (written straight to the archive: the point under test is the
        # report's arithmetic, not the ingest path)
        check("...and the gap criterion is the one with no tolerance",
              prequal["maxGapMinutes"] <= rules["fresh_food"]["dispatchHoldMinutes"], True)

        # the status page renders
        with urllib.request.urlopen(base + "/", timeout=5) as res:
            page = res.read().decode()
        check("the status page names every drill sensor",
              all(label in page for label in ["drill fridge healthy", "drill fridge silent"]), True)
        check("the status page states the rules it judges by", "no recovery in" in page, True)
        check("the status page explains the drill workflow", "/drill/end" in page, True)

        # drill 17: THE SERVER SERVES ITS OWN PAGES.
        # guardian.html polls this server from the browser. Opened as a
        # file it has a null origin and the fetch can be blocked, which
        # looks exactly like a broken product. Served from here it is
        # same-origin and the question never arises.
        with urllib.request.urlopen(base + "/guardian.html", timeout=10) as res:
            office = res.read().decode()
            office_type = res.headers.get("Content-Type", "")
        check("the office module is served from the server's own origin",
              "guardian-root" in office and len(office) > 100000, True)
        check("...as HTML", "text/html" in office_type, True)
        with urllib.request.urlopen(base + "/guardian-customer.html?key=demo", timeout=10) as res:
            check("the customer page too, query string and all", len(res.read()) > 100000, True)
        # A whitelist, not a static file server. The registry holds every
        # customer's access key; nothing may reach it over HTTP.
        for forbidden in ["/guardian-pilot-sensors.json", "/tools/guardian-pilot-server.js",
                          "/../tools/guardian-pilot-server.js", "/guardian.html.bak"]:
            code = 0
            try:
                urllib.request.urlopen(base + forbidden, timeout=5)
                code = 200
            except urllib.error.HTTPError as e:
                code = e.code
            check(f"  {forbidden} is refused", code, 404)
    finally:
        server.terminate()
        server.wait(timeout=5)

    print()
    if failures:
        print(f"{len(failures)} FAILURE(S) of {checks} checks")
        sys.exit(1)
    print(f"ALL {checks} PILOT SERVER CHECKS PASSED")


if __name__ == "__main__":
    main()
