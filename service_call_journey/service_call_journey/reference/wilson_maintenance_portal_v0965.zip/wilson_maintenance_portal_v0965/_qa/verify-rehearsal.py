#!/usr/bin/env python3
"""
THE REHEARSAL RIG, AND THE FENCE AROUND IT.                       (v0.9.63)

Cayden has the gateway and no sensors, so tools/guardian-fake-node.js lets
the office practise on a live system: it publishes real ChirpStack-shaped
uplink events onto a real MQTT broker, through the real bridge, into the
real pilot server.

That is useful and it is also the most dangerous tool in this repository,
because a synthetic reading in guardian-pilot-training.jsonl would sit
beside real drill labels forever and there would be no way, later, to tell
which correlations were learned from a refrigerator and which from a
JavaScript sine wave. The labeled drill dataset is the one asset here that
cannot be regenerated.

So this suite proves two different things:

  THE RIG WORKS -- the whole chain below the radio runs end to end with no
  hardware: fake node -> broker -> guardian-lora-bridge -> pilot server ->
  flag rules -> incidents. (A minimal broker fixture stands in for
  mosquitto so the suite needs no Docker.)

  THE FENCE HOLDS -- the pilot server REFUSES synthetic readings unless it
  was started in rehearsal mode; rehearsal mode sandboxes its data files;
  rehearsal incidents are stamped; the reserved prefix cannot be evaded
  from the tool side; and nothing shipped to a customer or a dashboard dev
  references the rig at all.

Run: python3 _qa/verify-rehearsal.py
"""
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

checks = 0
failures = []


def check(label, got, want=True):
    global checks
    checks += 1
    ok = got == want
    print(("ok    " if ok else "FAIL  ") + label.ljust(66) + ("" if ok else f" got {got!r}"))
    if not ok:
        failures.append(label)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def wait_for(url, tries=60):
    for _ in range(tries):
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.1)
    return False


def post(url, payload, headers=None):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers=dict({"Content-Type": "application/json"}, **(headers or {})))
    try:
        with urllib.request.urlopen(req, timeout=5) as res:
            return res.status, res.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


SYNTHETIC = "f0f0f0aabbcc0001"


def main():
    # ---- the constant that has to agree across two runtimes -------------
    server_src = (ROOT / "tools" / "guardian-pilot-server.js").read_text(encoding="utf-8")
    node_src = (ROOT / "tools" / "guardian-fake-node.js").read_text(encoding="utf-8")
    server_prefix = re.search(r'SYNTHETIC_PREFIX = "([0-9a-f]+)"', server_src)
    node_prefix = re.search(r'RESERVED_PREFIX = "([0-9a-f]+)"', node_src)
    check("both runtimes declare the reserved synthetic prefix",
          bool(server_prefix) and bool(node_prefix), True)
    check("...and it is the SAME string on both sides",
          server_prefix.group(1) if server_prefix else None,
          node_prefix.group(1) if node_prefix else "?")

    # ---- the rig is not part of the product ------------------------------
    # A rehearsal tool referenced from a shipped page would be a rehearsal
    # tool a customer could find.
    for name in ["guardian-module.js", "guardian-customer.js", "guardian-analysis.js",
                 "temp-monitoring.js", "plan-config.js"]:
        src = (ROOT / "assets" / name).read_text(encoding="utf-8")
        check(f"assets/{name} never mentions the rig",
              "fake-node" in src or "guardian-fake" in src, False)
    shell = (ROOT / "sw.js").read_text(encoding="utf-8")
    check("the offline app shell does not cache it", "fake-node" in shell, False)

    workdir = Path(tempfile.mkdtemp(prefix="guardian-rehearsal-qa-"))
    broker_port = free_port()
    broker = subprocess.Popen(["node", str(ROOT / "_qa" / "fixtures" / "mqtt-broker.js"), str(broker_port)],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    # The broker prints one line when it is accepting; waiting on that
    # rather than on a sleep keeps the suite honest on a slow machine.
    ready = broker.stdout.readline().strip()
    check("the test broker comes up", ready.startswith("listening"), True)

    procs = [broker]

    def start_server(rehearsal, port, files_prefix):
        env = dict(os.environ,
                   PORT=str(port),
                   GUARDIAN_SENSORS_FILE=str(workdir / f"{files_prefix}-sensors.json"),
                   GUARDIAN_DATA_FILE=str(workdir / f"{files_prefix}-data.json"),
                   GUARDIAN_INCIDENT_FILE=str(workdir / f"{files_prefix}-incidents.jsonl"),
                   GUARDIAN_DRILL_FILE=str(workdir / f"{files_prefix}-drills.json"),
                   GUARDIAN_TRAINING_FILE=str(workdir / f"{files_prefix}-training.jsonl"),
                   GUARDIAN_HISTORY_FILE=str(workdir / f"{files_prefix}-history.jsonl"),
                   GUARDIAN_NOTIFY_FILE=str(workdir / f"{files_prefix}-notify.jsonl"))
        if rehearsal:
            env["GUARDIAN_REHEARSAL"] = "1"
        else:
            env.pop("GUARDIAN_REHEARSAL", None)
        proc = subprocess.Popen(["node", str(ROOT / "tools" / "guardian-pilot-server.js")],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        procs.append(proc)
        return proc

    try:
        # ================================================================
        # THE FENCE: a production server refuses invented readings.
        # ================================================================
        prod_port = free_port()
        (workdir / "prod-sensors.json").write_text(json.dumps({"sensors": [
            {"channelId": "1001", "field": "field7", "kind": "fresh_food", "unit": "C", "label": "real"},
            # Deliberately present in the registry: being KNOWN must not be
            # enough. The prefix is the gate, not the registry.
            {"channelId": SYNTHETIC, "field": "field7", "kind": "fresh_food", "unit": "C", "label": "planted"},
        ]}))
        start_server(False, prod_port, "prod")
        prod = f"http://127.0.0.1:{prod_port}"
        check("a production-mode server starts", wait_for(prod + "/status.json"), True)
        with urllib.request.urlopen(prod + "/status.json", timeout=5) as res:
            body = json.loads(res.read().decode())
        check("...and says it is NOT in rehearsal", body.get("rehearsal"), False)

        status, text = post(prod + "/ubibot", {
            "channel_id": SYNTHETIC,
            "feeds": [{"created_at": "2026-09-08T12:00:00Z", "field7": {"value": 3.0}}]})
        check("a synthetic reading is REFUSED by a production server", status, 400)
        rows = json.loads(urllib.request.urlopen(prod + "/status.json", timeout=5).read().decode())
        planted = [r for r in rows["sensors"] if r["channelId"] == SYNTHETIC][0]
        check("...and nothing was stored for it", planted["readings"], 0)
        check("a real channel on the same server still works",
              post(prod + "/ubibot", {"channel_id": "1001",
                                      "feeds": [{"created_at": "2026-09-08T12:00:00Z",
                                                 "field7": {"value": 3.0}}]})[1], "SUCCESS")
        status, text = post(prod + "/rehearsal/register",
                            {"channelId": SYNTHETIC, "kind": "fresh_food", "label": "nope"})
        check("the rehearsal registration endpoint is OFF in production", status, 403)

        # ================================================================
        # THE RIG: end to end, no hardware, through the real bridge.
        # ================================================================
        reh_port = free_port()
        (workdir / "reh-sensors.json").write_text(json.dumps({"sensors": [], "customers": []}))
        reh_proc = start_server(True, reh_port, "reh")
        reh = f"http://127.0.0.1:{reh_port}"
        check("a rehearsal server starts with an EMPTY registry", wait_for(reh + "/status.json"), True)
        with urllib.request.urlopen(reh + "/status.json", timeout=5) as res:
            body = json.loads(res.read().decode())
        check("...and declares itself a rehearsal in its own feed", body.get("rehearsal"), True)

        bridge = subprocess.Popen(
            ["node", str(ROOT / "tools" / "guardian-lora-bridge.js")],
            env=dict(os.environ, GUARDIAN_MQTT_HOST="127.0.0.1",
                     GUARDIAN_MQTT_PORT=str(broker_port),
                     GUARDIAN_PILOT_URL=reh + "/ubibot"),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        procs.append(bridge)
        time.sleep(1.0)

        # Cayden's own example, told by the rig: a box that stops cooling.
        fake = subprocess.run(
            ["node", str(ROOT / "tools" / "guardian-fake-node.js"),
             "--profile", "no_cool", "--deveui", SYNTHETIC, "--backfill", "1", "--catch-up"],
            env=dict(os.environ, GUARDIAN_MQTT_HOST="127.0.0.1",
                     GUARDIAN_MQTT_PORT=str(broker_port),
                     GUARDIAN_PILOT_URL=reh + "/ubibot"),
            capture_output=True, text=True, timeout=90)
        out = fake.stdout + fake.stderr
        check("the rig announces loudly that its readings are invented",
              "invented" in out.lower() and "not a sensor" in out.lower(), True)
        check("...and self-registers with the rehearsal server", "registered" in out, True)
        time.sleep(2.0)

        rows = json.loads(urllib.request.urlopen(reh + "/status.json", timeout=5).read().decode())
        sensor = [r for r in rows["sensors"] if r["channelId"] == SYNTHETIC]
        check("the synthetic sensor appears in the fleet", len(sensor), 1)
        sensor = sensor[0]
        check("...having travelled node -> broker -> bridge -> server",
              sensor["readings"] > 30, True)
        check("...judged by the production rules to DISPATCH", sensor["tier"], "dispatch")
        check("...with battery carried the whole way",
              sensor["battery"]["known"] is True and sensor["battery"]["volts"] > 2, True)
        check("...and radio quality too", sensor["radio"]["rssi"] < 0, True)
        dispatches = [i for i in rows["incidents"] if i["tier"] == "dispatch"]
        check("an incident was logged", len(dispatches) >= 1, True)
        check("...stamped as a rehearsal, so it can never be read as real later",
              all(i.get("rehearsal") is True for i in rows["incidents"]), True)

        bridge_out = ""
        bridge.terminate()
        try:
            bridge_out = bridge.communicate(timeout=5)[0] or ""
        except Exception:
            pass
        check("the bridge read the PROBE field, not the internal one",
              "(probe)" in bridge_out, True)

        # A profile whose whole point is failing the pre-qualification bar.
        patchy = "f0f0f0aabbcc0002"
        subprocess.run(
            ["node", str(ROOT / "tools" / "guardian-fake-node.js"),
             "--profile", "patchy_radio", "--deveui", patchy, "--backfill", "7", "--catch-up", "--via", "http"],
            env=dict(os.environ, GUARDIAN_PILOT_URL=reh + "/ubibot"),
            capture_output=True, text=True, timeout=180)
        with urllib.request.urlopen(reh + f"/prequal.json?channel={patchy}", timeout=10) as res:
            pq = json.loads(res.read().decode())["sensors"][0]
        check("the patchy-radio profile FAILS the pre-qualification bar", pq["verdict"], "fail")
        check("...on the gap criterion, which is the one with no tolerance",
              pq["checks"]["gap"]["pass"], False)
        check("...while the office can see exactly when the hole was",
              pq["gapsOverLimitCount"] >= 1, True)

        # http transport reaches the server without the bridge at all --
        # the no-Docker path for training staff on a laptop.
        check("the --via http path stored readings too",
              json.loads(urllib.request.urlopen(reh + "/status.json", timeout=5).read().decode()) is not None,
              True)
        rows = json.loads(urllib.request.urlopen(reh + "/status.json", timeout=5).read().decode())
        patchy_row = [r for r in rows["sensors"] if r["channelId"] == patchy][0]
        check("...and they are healthy readings, only badly delivered",
              patchy_row["tier"] in ("ok", "offline", "waiting"), True)

        # ================================================================
        # A rehearsal must LOOK like a rehearsal.
        # ================================================================
        # The server already says so in its feed; the office module has to
        # act on it. A screen of invented readings that is visually
        # identical to a real fleet is how somebody eventually mistakes a
        # drill for a refrigerator.
        module_src = (ROOT / "assets" / "guardian-module.js").read_text(encoding="utf-8")
        check("the module reads the server's rehearsal flag",
              "data.rehearsal === true" in module_src, True)
        check("...and never decides for itself that it is a rehearsal",
              module_src.count("live.rehearsal = ") , 1)
        check("...badging it as invented rather than Live",
              "gm-mode-rehearsal" in module_src and "invented data" in module_src, True)
        check("...and banners it across the top, which cannot be missed",
              "gm-rehearsal-bar" in module_src, True)
        css = (ROOT / "assets" / "guardian-module.css").read_text(encoding="utf-8")
        check("...with styles that actually exist",
              ".gm-mode-rehearsal" in css and ".gm-rehearsal-bar" in css, True)
        built = (ROOT / "guardian.html").read_text(encoding="utf-8")
        check("...and all of it survives into the built module",
              "gm-rehearsal-bar" in built and "invented data" in built, True)

        # ================================================================
        # The tool cannot be talked out of its own prefix.
        # ================================================================
        bad = subprocess.run(
            ["node", str(ROOT / "tools" / "guardian-fake-node.js"),
             "--profile", "healthy", "--deveui", "a84041ffff123456", "--once"],
            env=dict(os.environ, GUARDIAN_PILOT_URL=reh + "/ubibot"),
            capture_output=True, text=True, timeout=30)
        check("the rig refuses to impersonate a real DevEUI", bad.returncode != 0, True)
        check("...and says why", "reserved" in (bad.stdout + bad.stderr).lower()
              or "f0f0f0" in (bad.stdout + bad.stderr), True)

        # Every profile has to actually produce something; a profile that
        # silently emits nothing is a rehearsal that teaches nothing.
        listing = subprocess.run(
            ["node", str(ROOT / "tools" / "guardian-fake-node.js"), "--list"],
            capture_output=True, text=True, timeout=30).stdout
        names = re.findall(r"^  ([a-z_]+) ", listing, re.M)
        check("the rig offers the drill-shaped profiles", len(names) >= 8, True)
        for name in names:
            single = subprocess.run(
                ["node", str(ROOT / "tools" / "guardian-fake-node.js"),
                 "--profile", name, "--deveui", "f0f0f0ffff0000" + format(names.index(name), "02x"),
                 "--once", "--via", "http"],
                env=dict(os.environ, GUARDIAN_PILOT_URL=reh + "/ubibot"),
                capture_output=True, text=True, timeout=30)
            check(f"  profile '{name}' runs clean", single.returncode, 0)
    finally:
        for proc in procs:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                pass

    print()
    if failures:
        print(f"{len(failures)} FAILURE(S) of {checks} checks")
        sys.exit(1)
    print(f"ALL {checks} REHEARSAL CHECKS PASSED")


if __name__ == "__main__":
    main()
