/*
 * WILSON GUARDIAN — TEMPERATURE ANALYSIS                           (v1.5)
 *
 * Cayden: "I'd like our staff to be able to zoom in, change time windows,
 * drag the cursor to see exact readouts at that moment in time etc etc so
 * that we can deeply analyze the temp data."
 *
 * The office's investigation surface. A sparkline answers "is it okay";
 * this answers "what exactly happened at 2:15 on Tuesday, how long was it
 * over the line, and does that shape look like a door or a dead fan."
 *
 * WHAT IT DOES
 *   - time-window presets (6h / 24h / 48h / 7d / 30d / all) in one row
 *   - drag ACROSS the plot to zoom into that span; wheel to zoom around
 *     the pointer; shift-drag to pan; ← → to walk readings; Escape resets
 *   - a crosshair that snaps to the nearest reading and prints its exact
 *     time, temperature, distance from set point, and standing vs the
 *     warn / dispatch lines
 *   - full-resolution statistics for whatever window is on screen
 *   - a table view of the same data, and a CSV of the raw window
 *
 * TWO RULES THIS FILE KEEPS
 *   1. THRESHOLDS ARE NEVER REDEFINED HERE. Every line drawn and every
 *      judgement printed comes from the engine's rule for that band
 *      (plan-config flagRules, via the server or WILSON_TEMPWATCH).
 *   2. STATISTICS DESCRIBE FULL RESOLUTION, NEVER THE DRAWN LINE. The
 *      server thins points for drawing (preserving each bucket's extremes)
 *      but summarizes every reading, so the maximum on the stat strip is
 *      the real maximum at any zoom. A chart that reports a different peak
 *      when you zoom out is a chart that loses alerts.
 *
 * DATA
 *   live: GET <feed>/history.json?channel=&from=&to=&maxPoints=
 *         CSV: <feed>/history.csv?channel=&from=&to=
 *   demo: a deterministic 30-day series per sensor, generated locally so
 *         the whole surface can be exercised with no backend. Demo DATA
 *         only — the thresholds it is judged against are still the
 *         product's own.
 */
(function () {
  "use strict";

  var config = (window.WILSON_CONFIG || {}).tempMonitoring || {};
  var RULES = config.flagRules || {};

  var WINDOWS = [
    { key: "6h", label: "6h", hours: 6 },
    { key: "24h", label: "24h", hours: 24 },
    { key: "48h", label: "48h", hours: 48 },
    { key: "7d", label: "7d", hours: 24 * 7 },
    { key: "30d", label: "30d", hours: 24 * 30 },
    { key: "all", label: "All", hours: 0 }
  ];

  var view = {
    host: null,
    feed: "",
    sensors: [],
    sensorId: "",
    windowKey: "48h",
    from: 0, to: 0,
    data: null,
    loading: false,
    error: null,
    cursor: null,      /* index into data.points */
    pinned: false,
    drag: null,        /* {x0, x1, pan:bool, fromAt, toAt} */
    showTable: false
  };

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function ruleFor(kind) { return RULES[kind] || RULES.fresh_food || {}; }
  function fmtTemp(v) { return (Math.round(v * 10) / 10).toFixed(1) + "°F"; }
  function fmtClock(ms) {
    return new Date(ms).toLocaleString([], {
      month: "short", day: "numeric", hour: "numeric", minute: "2-digit"
    });
  }
  function fmtDuration(minutes) {
    var m = Math.round(minutes || 0);
    if (!m) return "none";
    if (m < 60) return m + " min";
    var h = Math.floor(m / 60), rest = m % 60;
    if (h < 24) return h + "h" + (rest ? " " + rest + "m" : "");
    return Math.floor(h / 24) + "d " + (h % 24) + "h";
  }

  /* ---- demo history (data only; never thresholds) -------------------------- */
  var demoCache = {};
  function seeded(str) {
    var h = 2166136261;
    for (var i = 0; i < str.length; i += 1) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return function () { h += 0x6D2B79F5; var t = h; t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function demoHistory(sensor) {
    if (demoCache[sensor.id]) return demoCache[sensor.id];
    var rule = ruleFor(sensor.kind);
    var set = rule.setpointF !== undefined ? rule.setpointF : 37;
    var rand = seeded(sensor.id);
    var now = Date.now();
    var step = 15 * 60000;
    var count = 30 * 24 * 4;                 /* 30 days at 15 minutes */
    var rows = [];
    /* One induced excursion, ~4 days back, so the analysis surface has
       something worth investigating the first time it is opened. */
    var eventStart = count - 4 * 24 * 4;
    var eventEnd = eventStart + 10;
    for (var i = 0; i < count; i += 1) {
      var t = now - (count - 1 - i) * step;
      var cycle = Math.sin(i / 2.1) * (rule.maxF !== undefined && set < 20 ? 1.6 : 1.1);
      var noise = (rand() - 0.5) * 0.9;
      var door = rand() > 0.985 ? 2 + rand() * 3 : 0;
      var defrost = i % (4 * 8) === 0 ? 3.2 : 0;   /* a defrost bump every 8h */
      var event = 0;
      if (i >= eventStart && i <= eventEnd) event = ((i - eventStart) / (eventEnd - eventStart)) * 11;
      else if (i > eventEnd && i < eventEnd + 8) event = 11 * (1 - (i - eventEnd) / 8);
      rows.push({ t: t, f: Math.round((set + cycle + noise + door + defrost + event) * 10) / 10 });
    }
    demoCache[sensor.id] = rows;
    return rows;
  }

  /* Mirrors the server's downsample EXACTLY — each bucket contributes its
     min and max in time order, two slots are reserved so the cap is a real
     cap, and the window's own first and last readings always survive. Two
     copies of one rule is a bug waiting to happen, so QA holds them to the
     same behavior. */
  function downsample(rows, cap) {
    if (rows.length <= cap) return rows.slice();
    var buckets = Math.max(1, Math.floor((cap - 2) / 2));
    var span = rows.length / buckets;
    var out = [];
    for (var b = 0; b < buckets; b += 1) {
      var start = Math.floor(b * span), end = Math.min(rows.length, Math.floor((b + 1) * span));
      if (end <= start) continue;
      var lo = rows[start], hi = rows[start];
      for (var i = start; i < end; i += 1) {
        if (rows[i].f < lo.f) lo = rows[i];
        if (rows[i].f > hi.f) hi = rows[i];
      }
      if (lo.t <= hi.t) { out.push(lo); if (hi !== lo) out.push(hi); }
      else { out.push(hi); out.push(lo); }
    }
    if (out.length && out[0].t !== rows[0].t) out.unshift(rows[0]);
    if (out.length && out[out.length - 1].t !== rows[rows.length - 1].t) out.push(rows[rows.length - 1]);
    return out;
  }

  function demoStats(rows, rule) {
    if (!rows.length) return null;
    var lo = rows[0], hi = rows[0], sum = 0, overWarn = 0, overDispatch = 0;
    var excursions = 0, over = false;
    for (var i = 0; i < rows.length; i += 1) {
      var r = rows[i];
      if (r.f < lo.f) lo = r;
      if (r.f > hi.f) hi = r;
      sum += r.f;
      var isOver = rule.maxF !== undefined && r.f > rule.maxF;
      if (isOver && !over) excursions += 1;
      over = isOver;
      if (i < rows.length - 1) {
        var minutes = Math.min(60, (rows[i + 1].t - r.t) / 60000);
        if (isOver) overWarn += minutes;
        if (rule.dispatchF !== undefined && r.f > rule.dispatchF) overDispatch += minutes;
      }
    }
    return {
      readings: rows.length,
      min: Math.round(lo.f * 10) / 10, minAt: new Date(lo.t).toISOString(),
      max: Math.round(hi.f * 10) / 10, maxAt: new Date(hi.t).toISOString(),
      avg: Math.round((sum / rows.length) * 10) / 10,
      excursions: excursions,
      overWarnMinutes: Math.round(overWarn),
      overDispatchMinutes: Math.round(overDispatch),
      firstAt: new Date(rows[0].t).toISOString(),
      lastAt: new Date(rows[rows.length - 1].t).toISOString()
    };
  }

  /* ---- loading ------------------------------------------------------------- */
  function currentSensor() {
    return view.sensors.find(function (s) { return s.id === view.sensorId; }) || view.sensors[0] || null;
  }

  function windowBounds(sensor) {
    var win = WINDOWS.find(function (w) { return w.key === view.windowKey; });
    if (view.windowKey === "custom") return { from: view.from, to: view.to };
    var to = Date.now();
    if (win && win.hours) return { from: to - win.hours * 3600000, to: to };
    /* "All": demo knows its own span; live asks for five years and lets
       the server return what it has. */
    if (!view.feed) {
      var rows = demoHistory(sensor);
      return { from: rows[0].t, to: rows[rows.length - 1].t };
    }
    return { from: to - 5 * 365 * 24 * 3600000, to: to };
  }

  function load() {
    var sensor = currentSensor();
    if (!sensor) { view.data = null; paint(); return; }
    var bounds = windowBounds(sensor);
    view.from = bounds.from; view.to = bounds.to;
    view.cursor = null; view.pinned = false;

    if (!view.feed) {
      var all = demoHistory(sensor);
      var rows = all.filter(function (r) { return r.t >= view.from && r.t <= view.to; });
      var rule = ruleFor(sensor.kind);
      view.data = {
        label: sensor.label, kind: sensor.kind, rule: rule,
        points: downsample(rows, 1200), rawCount: rows.length,
        downsampled: rows.length > 1200, stats: demoStats(rows, rule),
        from: view.from, to: view.to, demo: true
      };
      view.error = null;
      paint();
      return;
    }
    view.loading = true; paint();
    var url = view.feed + "/history.json?channel=" + encodeURIComponent(sensor.id) +
      "&from=" + Math.round(view.from) + "&to=" + Math.round(view.to) + "&maxPoints=1200";
    fetch(url).then(function (r) {
      if (!r.ok) throw new Error("server answered " + r.status);
      return r.json();
    }).then(function (d) {
      view.loading = false; view.error = null;
      view.data = {
        label: d.label, kind: d.kind, rule: d.rule || ruleFor(d.kind),
        points: d.points || [], rawCount: d.rawCount, downsampled: d.downsampled,
        stats: d.stats, from: Date.parse(d.from), to: Date.parse(d.to)
      };
      paint();
    }).catch(function (err) {
      view.loading = false;
      view.error = "Could not load history: " + err.message;
      paint();
    });
  }

  /* ---- geometry ------------------------------------------------------------ */
  var PAD = { left: 52, right: 16, top: 14, bottom: 28 };

  function plotBox(canvas) {
    return {
      x: PAD.left, y: PAD.top,
      w: Math.max(10, canvas.clientWidth - PAD.left - PAD.right),
      h: Math.max(10, canvas.clientHeight - PAD.top - PAD.bottom)
    };
  }

  function scales(data, box) {
    var pts = data.points;
    var t0 = data.from, t1 = data.to;
    var values = pts.map(function (p) { return p.f; });
    var rule = data.rule || {};
    /* The warn line is always in frame: a chart of a healthy fridge that
       hides where "too warm" starts is a chart you cannot judge against. */
    if (rule.maxF !== undefined) values.push(rule.maxF);
    if (rule.setpointF !== undefined) values.push(rule.setpointF);
    var lo = values.length ? Math.min.apply(null, values) : 0;
    var hi = values.length ? Math.max.apply(null, values) : 1;
    if (hi - lo < 4) { var mid = (hi + lo) / 2; lo = mid - 2; hi = mid + 2; }
    var padY = (hi - lo) * 0.12;
    lo -= padY; hi += padY;
    return {
      t0: t0, t1: t1, lo: lo, hi: hi,
      X: function (t) { return box.x + ((t - t0) / Math.max(1, t1 - t0)) * box.w; },
      Y: function (f) { return box.y + box.h - ((f - lo) / Math.max(0.001, hi - lo)) * box.h; },
      tAt: function (px) { return t0 + ((px - box.x) / box.w) * (t1 - t0); }
    };
  }

  function niceTicks(lo, hi, target) {
    var span = hi - lo;
    var raw = span / Math.max(1, target);
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var step = [1, 2, 2.5, 5, 10].map(function (m) { return m * mag; })
      .find(function (s) { return s >= raw; }) || 10 * mag;
    var out = [];
    for (var v = Math.ceil(lo / step) * step; v <= hi; v += step) out.push(Math.round(v * 1000) / 1000);
    return out;
  }

  function timeTicks(t0, t1, width) {
    var span = t1 - t0;
    var target = Math.max(2, Math.floor(width / 110));
    var steps = [5 * 60000, 15 * 60000, 30 * 60000, 3600000, 3 * 3600000, 6 * 3600000,
      12 * 3600000, 86400000, 2 * 86400000, 7 * 86400000, 14 * 86400000, 30 * 86400000];
    var step = steps.find(function (s) { return span / s <= target; }) || steps[steps.length - 1];
    var out = [];
    var start = Math.ceil(t0 / step) * step;
    for (var t = start; t <= t1; t += step) out.push(t);
    return { ticks: out, step: step };
  }

  /* ---- painting ------------------------------------------------------------ */
  function css(el, name, fallback) {
    try {
      var v = getComputedStyle(el).getPropertyValue(name).trim();
      return v || fallback;
    } catch (e) { return fallback; }
  }

  function drawChart() {
    var canvas = view.host.querySelector("#ga-canvas");
    if (!canvas || !view.data || !view.data.points.length) return;
    var ratio = window.devicePixelRatio || 1;
    var w = canvas.clientWidth, h = canvas.clientHeight;
    canvas.width = Math.round(w * ratio);
    canvas.height = Math.round(h * ratio);
    var ctx = canvas.getContext("2d");
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, w, h);

    var box = plotBox(canvas);
    var s = scales(view.data, box);
    var rule = view.data.rule || {};

    var ink = css(canvas, "--gm-ink", "#182619");
    var muted = css(canvas, "--gm-muted-2", "#8A968C");
    var line = css(canvas, "--gm-border", "#DCE6D8");
    var accent = css(canvas, "--gm-accent", "#1F5C36");
    var warn = css(canvas, "--gm-warn-line", "#C79000");
    var bad = css(canvas, "--gm-bad-line", "#E04B2E");

    /* Grid: solid hairlines, one shade off the surface — never dashed,
       so dashing can mean "threshold" and only that. */
    ctx.lineWidth = 1;
    ctx.strokeStyle = line;
    ctx.fillStyle = muted;
    ctx.font = "11px system-ui, -apple-system, sans-serif";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    niceTicks(s.lo, s.hi, 5).forEach(function (v) {
      var y = Math.round(s.Y(v)) + 0.5;
      ctx.beginPath(); ctx.moveTo(box.x, y); ctx.lineTo(box.x + box.w, y); ctx.stroke();
      ctx.fillText(v.toFixed(0) + "°", box.x - 8, y);
    });
    var tt = timeTicks(s.t0, s.t1, box.w);
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    tt.ticks.forEach(function (t) {
      var x = Math.round(s.X(t)) + 0.5;
      ctx.beginPath(); ctx.moveTo(x, box.y); ctx.lineTo(x, box.y + box.h); ctx.stroke();
      var d = new Date(t);
      var label = tt.step >= 86400000
        ? d.toLocaleDateString([], { month: "short", day: "numeric" })
        : d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      ctx.fillText(label, x, box.y + box.h + 7);
    });

    /* Threshold lines — dashed BECAUSE they are thresholds, labelled so
       they are never color-alone. */
    /* Each reference line gets its OWN dash rhythm as well as its own hue
       and a text label: the validator puts the warn/dispatch pair in the
       6-8 CVD band, which is legal only with secondary encoding, and this
       is that encoding. A reader who sees no color at all still reads
       three different lines. */
    [{ v: rule.setpointF, c: accent, t: "set point", dash: [1, 3] },
     { v: rule.maxF, c: warn, t: "warn", dash: [7, 4] },
     { v: rule.dispatchF, c: bad, t: "dispatch", dash: [2, 3] }].forEach(function (ref) {
      if (ref.v === undefined || ref.v < s.lo || ref.v > s.hi) return;
      var y = Math.round(s.Y(ref.v)) + 0.5;
      ctx.save();
      ctx.strokeStyle = ref.c;
      ctx.setLineDash(ref.dash);
      ctx.globalAlpha = 0.75;
      ctx.beginPath(); ctx.moveTo(box.x, y); ctx.lineTo(box.x + box.w, y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;
      /* Labelled at the RIGHT edge on its own washed chip: at the left
         edge the text sat directly on the series line, which is exactly
         the "label clipped by / colliding with a mark" anti-pattern. */
      ctx.font = "10px system-ui, -apple-system, sans-serif";
      ctx.textAlign = "right";
      ctx.textBaseline = "bottom";
      var text = ref.t + " " + ref.v + "°";
      var tw = ctx.measureText(text).width;
      ctx.fillStyle = css(canvas, "--gm-card", "#fff");
      ctx.globalAlpha = 0.85;
      ctx.fillRect(box.x + box.w - tw - 6, y - 13, tw + 6, 12);
      ctx.globalAlpha = 1;
      ctx.fillStyle = ref.c;
      ctx.fillText(text, box.x + box.w - 3, y - 2);
      ctx.restore();
    });

    /* The series: 2px, one hue, no fill under it (a fill would imply an
       area that means something). */
    ctx.beginPath();
    view.data.points.forEach(function (p, i) {
      var x = s.X(p.t), y = s.Y(p.f);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = accent;
    ctx.lineWidth = 2;
    ctx.lineJoin = "round";
    ctx.stroke();

    /* Drag selection band. */
    if (view.drag && !view.drag.pan && Math.abs(view.drag.x1 - view.drag.x0) > 2) {
      var x0 = Math.min(view.drag.x0, view.drag.x1), x1 = Math.max(view.drag.x0, view.drag.x1);
      ctx.save();
      ctx.fillStyle = accent;
      ctx.globalAlpha = 0.12;
      ctx.fillRect(x0, box.y, x1 - x0, box.h);
      ctx.globalAlpha = 0.5;
      ctx.strokeStyle = accent;
      ctx.lineWidth = 1;
      ctx.strokeRect(Math.round(x0) + 0.5, box.y + 0.5, Math.round(x1 - x0), box.h);
      ctx.restore();
    }

    /* Crosshair + the reading it names. The marker is 9px with a 2px
       surface ring, so it reads as "this one" over the line. */
    if (view.cursor !== null && view.data.points[view.cursor]) {
      var p = view.data.points[view.cursor];
      var cx = s.X(p.t), cy = s.Y(p.f);
      ctx.save();
      ctx.strokeStyle = ink;
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(Math.round(cx) + 0.5, box.y); ctx.lineTo(Math.round(cx) + 0.5, box.y + box.h); ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.beginPath(); ctx.arc(cx, cy, 5.5, 0, Math.PI * 2);
      ctx.fillStyle = css(canvas, "--gm-card", "#fff");
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = accent;
      ctx.stroke();
      ctx.restore();
    }
  }

  function nearestIndex(px) {
    var canvas = view.host.querySelector("#ga-canvas");
    var box = plotBox(canvas);
    var s = scales(view.data, box);
    var t = s.tAt(px);
    var pts = view.data.points;
    var best = 0, bestDist = Infinity;
    for (var i = 0; i < pts.length; i += 1) {
      var d = Math.abs(pts[i].t - t);
      if (d < bestDist) { bestDist = d; best = i; }
    }
    return best;
  }

  /* ---- readout / stats / table --------------------------------------------- */
  function readoutHtml() {
    var d = view.data;
    if (!d || !d.points.length) return '<span class="ga-sub">No readings in this window.</span>';
    var idx = view.cursor === null ? d.points.length - 1 : view.cursor;
    var p = d.points[idx];
    var rule = d.rule || {};
    var standing = rule.dispatchF !== undefined && p.f > rule.dispatchF
      ? { label: "Above the dispatch line", tone: "dispatch" }
      : rule.maxF !== undefined && p.f > rule.maxF
        ? { label: "Above the warn line", tone: "warn" }
        : { label: "In band", tone: "ok" };
    var delta = rule.setpointF !== undefined
      ? (p.f - rule.setpointF >= 0 ? "+" : "−") + fmtTemp(Math.abs(p.f - rule.setpointF)).replace("°F", "") + "° vs set point"
      : "";
    return '<div class="ga-readout-value">' + esc(fmtTemp(p.f)) + "</div>" +
      '<div class="ga-readout-when">' + esc(fmtClock(p.t)) + "</div>" +
      '<div class="ga-readout-meta"><span class="gm-badge gm-tier-' + standing.tone + '">' + esc(standing.label) + "</span>" +
      (delta ? '<span class="ga-sub">' + esc(delta) + "</span>" : "") + "</div>" +
      '<div class="ga-sub">' + (view.cursor === null ? "Latest reading — move across the chart to inspect any moment" : (view.pinned ? "Pinned · click again to unpin" : "Reading " + (idx + 1) + " of " + d.points.length)) + "</div>";
  }

  function statsHtml() {
    var d = view.data;
    if (!d || !d.stats) return "";
    var st = d.stats, rule = d.rule || {};
    var tile = function (label, value, sub) {
      return '<div class="ga-stat"><span class="ga-stat-label">' + esc(label) + "</span>" +
        '<strong class="ga-stat-value">' + esc(value) + "</strong>" +
        (sub ? '<span class="ga-sub">' + esc(sub) + "</span>" : "") + "</div>";
    };
    return '<div class="ga-stats">' +
      tile("Peak", fmtTemp(st.max), st.maxAt ? fmtClock(Date.parse(st.maxAt)) : "") +
      tile("Low", fmtTemp(st.min), st.minAt ? fmtClock(Date.parse(st.minAt)) : "") +
      tile("Average", fmtTemp(st.avg), rule.setpointF !== undefined ? "set point " + rule.setpointF + "°F" : "") +
      tile("Time over warn", fmtDuration(st.overWarnMinutes),
        rule.maxF !== undefined ? "above " + rule.maxF + "°F" : "") +
      tile("Time over dispatch", fmtDuration(st.overDispatchMinutes),
        rule.dispatchF !== undefined ? "above " + rule.dispatchF + "°F" : "") +
      tile("Excursions", String(st.excursions || 0), "separate trips over the line") +
      tile("Readings", String(st.readings), d.downsampled ? d.points.length + " drawn" : "all drawn") +
      "</div>" +
      '<p class="ga-sub ga-statnote">These numbers describe every reading in the window at full resolution — the chart thins points for drawing but keeps each bucket’s high and low, so a spike is never smoothed away.</p>';
  }

  function tableHtml() {
    var d = view.data;
    if (!view.showTable || !d) return "";
    var rows = d.points.slice(-400).reverse();
    var rule = d.rule || {};
    return '<div class="ga-tablewrap"><table class="ga-table"><thead><tr>' +
      "<th>Time</th><th>Temperature</th><th>vs set point</th><th>Standing</th>" +
      "</tr></thead><tbody>" +
      rows.map(function (p) {
        var standing = rule.dispatchF !== undefined && p.f > rule.dispatchF ? "Over dispatch"
          : rule.maxF !== undefined && p.f > rule.maxF ? "Over warn" : "In band";
        var delta = rule.setpointF !== undefined
          ? ((p.f - rule.setpointF >= 0 ? "+" : "−") + (Math.abs(p.f - rule.setpointF)).toFixed(1) + "°")
          : "—";
        return "<tr><td>" + esc(fmtClock(p.t)) + "</td><td>" + esc(fmtTemp(p.f)) + "</td><td>" +
          esc(delta) + "</td><td>" + esc(standing) + "</td></tr>";
      }).join("") +
      "</tbody></table>" +
      (d.points.length > 400 ? '<p class="ga-sub">Showing the most recent 400 of ' + d.points.length + " drawn points — export the CSV for the full window.</p>" : "") +
      "</div>";
  }

  /* ---- the whole panel ------------------------------------------------------ */
  function paint() {
    if (!view.host) return;
    var active = null;
    try { active = document.activeElement; } catch (e) { active = null; }
    var hadFocus = Boolean(active && active.id === "ga-canvas");
    var sensor = currentSensor();
    var windowButtons = WINDOWS.map(function (w) {
      return '<button type="button" class="ga-chip' + (view.windowKey === w.key ? " active" : "") +
        '" data-ga-window="' + w.key + '">' + esc(w.label) + "</button>";
    }).join("");
    var zoomed = view.windowKey === "custom";
    view.host.innerHTML =
      '<section class="gm-section" id="ga-panel"><details' + (view.open ? " open" : "") + ">" +
      "<summary>Analyze temperature history</summary>" +
      '<div class="gm-card ga-card">' +
      '<div class="ga-controls">' +
      '<label class="ga-picker"><span>Sensor</span><select class="gm-select" id="ga-sensor">' +
      view.sensors.map(function (s) {
        return '<option value="' + esc(s.id) + '"' + (s.id === view.sensorId ? " selected" : "") + ">" +
          esc(s.label) + "</option>";
      }).join("") + "</select></label>" +
      '<div class="ga-chips" role="group" aria-label="Time window">' + windowButtons +
      (zoomed ? '<button type="button" class="ga-chip active" data-ga-window="reset" title="Back to the preset window">Zoomed ✕</button>' : "") +
      "</div>" +
      '<div class="ga-tools">' +
      '<button type="button" class="ga-chip" data-ga-zoom="out" title="Zoom out">−</button>' +
      '<button type="button" class="ga-chip" data-ga-pan="-1" title="Earlier">◀</button>' +
      '<button type="button" class="ga-chip" data-ga-pan="1" title="Later">▶</button>' +
      '<button type="button" class="ga-chip' + (view.showTable ? " active" : "") + '" data-ga-table="1">Table</button>' +
      '<button type="button" class="ga-chip" data-ga-csv="1">CSV</button>' +
      "</div></div>" +
      (view.error ? '<div class="gm-reason gm-reason-dispatch">' + esc(view.error) + "</div>" : "") +
      '<div class="ga-plotrow' + (view.loading ? " ga-loading" : "") + '">' +
      '<div class="ga-plot"><canvas id="ga-canvas" tabindex="0" role="img" aria-label="' +
      esc((sensor ? sensor.label : "sensor") + " temperature over the selected window") + '"></canvas></div>' +
      '<aside class="ga-readout" id="ga-readout" aria-live="polite">' + readoutHtml() + "</aside>" +
      "</div>" +
      statsHtml() +
      '<p class="ga-sub ga-help">Drag across the chart to zoom into that span · wheel to zoom around the pointer · shift-drag or ◀ ▶ to pan · click to pin a reading · ← → to step, Esc to reset.' +
      (view.data && view.data.demo ? " Demo data — a live feed shows the real sensor history." : "") + "</p>" +
      tableHtml() +
      "</div></details></section>";
    drawChart();
    /* A repaint must never cost the analyst their keyboard place. */
    if (hadFocus) {
      var refocus = view.host.querySelector("#ga-canvas");
      if (refocus && refocus.focus) refocus.focus();
    }
  }

  /* ---- interaction ---------------------------------------------------------- */
  function zoomTo(from, to) {
    var span = Math.max(5 * 60000, to - from);
    view.from = from; view.to = from + span;
    view.windowKey = "custom";
    load();
  }

  function zoomBy(factor, anchorT) {
    var span = view.to - view.from;
    var anchor = anchorT === undefined ? (view.from + view.to) / 2 : anchorT;
    var next = Math.max(5 * 60000, span * factor);
    var ratio = (anchor - view.from) / Math.max(1, span);
    zoomTo(anchor - next * ratio, anchor - next * ratio + next);
  }

  function panBy(direction) {
    var span = view.to - view.from;
    zoomTo(view.from + direction * span * 0.4, view.to + direction * span * 0.4);
  }

  function bind() {
    var host = view.host;
    if (!host || host.dataset.gaBound === "1") return;
    host.dataset.gaBound = "1";

    host.addEventListener("click", function (event) {
      var summary = event.target.closest("#ga-panel summary");
      if (summary) { view.open = !view.open; setTimeout(function () { if (view.open && !view.data) load(); else drawChart(); }, 0); return; }
      var win = event.target.closest("[data-ga-window]");
      if (win) {
        var key = win.dataset.gaWindow;
        view.windowKey = key === "reset" ? "48h" : key;
        load();
        return;
      }
      var zoom = event.target.closest("[data-ga-zoom]");
      if (zoom) { zoomBy(2); return; }
      var pan = event.target.closest("[data-ga-pan]");
      if (pan) { panBy(Number(pan.dataset.gaPan)); return; }
      var table = event.target.closest("[data-ga-table]");
      if (table) { view.showTable = !view.showTable; paint(); return; }
      var csv = event.target.closest("[data-ga-csv]");
      if (csv) { exportCsv(); return; }
    });

    host.addEventListener("change", function (event) {
      if (event.target.id === "ga-sensor") {
        view.sensorId = event.target.value;
        view.windowKey = view.windowKey === "custom" ? "48h" : view.windowKey;
        load();
      }
    });

    /* Pointer work happens on the host (delegated), because paint()
       replaces the canvas element each render. */
    host.addEventListener("pointerdown", function (event) {
      var canvas = event.target.closest("#ga-canvas");
      if (!canvas || !view.data) return;
      var rect = canvas.getBoundingClientRect();
      var x = event.clientX - rect.left;
      view.drag = { x0: x, x1: x, pan: event.shiftKey, fromAt: view.from, toAt: view.to, moved: false };
      canvas.setPointerCapture && canvas.setPointerCapture(event.pointerId);
    });

    host.addEventListener("pointermove", function (event) {
      var canvas = host.querySelector("#ga-canvas");
      if (!canvas || !view.data || !view.data.points.length) return;
      var rect = canvas.getBoundingClientRect();
      var x = event.clientX - rect.left;
      var inside = event.target.closest("#ga-canvas");
      if (view.drag) {
        view.drag.x1 = x;
        if (Math.abs(x - view.drag.x0) > 3) view.drag.moved = true;
        if (view.drag.pan) {
          var box = plotBox(canvas);
          var span = view.drag.toAt - view.drag.fromAt;
          var shift = ((view.drag.x0 - x) / box.w) * span;
          view.from = view.drag.fromAt + shift;
          view.to = view.drag.toAt + shift;
          view.windowKey = "custom";
        }
        drawChart();
        return;
      }
      if (!inside || view.pinned) return;
      view.cursor = nearestIndex(x);
      var readout = host.querySelector("#ga-readout");
      if (readout) readout.innerHTML = readoutHtml();
      drawChart();
    });

    host.addEventListener("pointerup", function (event) {
      if (!view.drag || !view.data) return;
      var drag = view.drag;
      view.drag = null;
      var canvas = host.querySelector("#ga-canvas");
      if (!canvas) return;
      if (drag.pan) { load(); return; }
      if (!drag.moved || Math.abs(drag.x1 - drag.x0) < 8) {
        /* A click, not a drag: pin or unpin the reading under it. */
        var rect = canvas.getBoundingClientRect();
        view.cursor = nearestIndex(event.clientX - rect.left);
        view.pinned = !view.pinned;
        paint();
        return;
      }
      var box = plotBox(canvas);
      var s = scales(view.data, box);
      var a = s.tAt(Math.min(drag.x0, drag.x1));
      var b = s.tAt(Math.max(drag.x0, drag.x1));
      zoomTo(a, b);
    });

    host.addEventListener("pointerleave", function () {
      if (view.pinned || view.drag) return;
      view.cursor = null;
      var readout = host.querySelector("#ga-readout");
      if (readout) readout.innerHTML = readoutHtml();
      drawChart();
    }, true);

    host.addEventListener("wheel", function (event) {
      var canvas = event.target.closest("#ga-canvas");
      if (!canvas || !view.data) return;
      event.preventDefault();
      var rect = canvas.getBoundingClientRect();
      var box = plotBox(canvas);
      var s = scales(view.data, box);
      zoomBy(event.deltaY > 0 ? 1.25 : 0.8, s.tAt(event.clientX - rect.left));
    }, { passive: false });

    /* Keyboard: the same readings the pointer reaches, without a pointer. */
    host.addEventListener("keydown", function (event) {
      if (!event.target.closest || !event.target.closest("#ga-canvas") || !view.data) return;
      var pts = view.data.points;
      var step = event.shiftKey ? 10 : 1;
      if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
        event.preventDefault();
        var dir = event.key === "ArrowRight" ? 1 : -1;
        var start = view.cursor === null ? pts.length - 1 : view.cursor;
        view.cursor = Math.max(0, Math.min(pts.length - 1, start + dir * step));
        view.pinned = true;
        var readout = host.querySelector("#ga-readout");
        if (readout) readout.innerHTML = readoutHtml();
        drawChart();
      } else if (event.key === "Home" || event.key === "End") {
        /* Deliberately the SAME lightweight update as the arrows: a full
           repaint replaces the canvas, which drops keyboard focus and
           silently ends the keyboard session mid-investigation. */
        event.preventDefault();
        view.cursor = event.key === "Home" ? 0 : pts.length - 1;
        view.pinned = true;
        var homeReadout = host.querySelector("#ga-readout");
        if (homeReadout) homeReadout.innerHTML = readoutHtml();
        drawChart();
      } else if (event.key === "Escape") {
        event.preventDefault();
        view.pinned = false; view.cursor = null;
        view.windowKey = view.windowKey === "custom" ? "48h" : view.windowKey;
        load();
      } else if (event.key === "+" || event.key === "=") {
        event.preventDefault(); zoomBy(0.6);
      } else if (event.key === "-" || event.key === "_") {
        event.preventDefault(); zoomBy(1.6);
      }
    });

    window.addEventListener("resize", function () { drawChart(); });
  }

  function exportCsv() {
    var sensor = currentSensor();
    if (!sensor || !view.data) return;
    if (view.feed) {
      window.open(view.feed + "/history.csv?channel=" + encodeURIComponent(sensor.id) +
        "&from=" + Math.round(view.from) + "&to=" + Math.round(view.to), "_blank");
      return;
    }
    /* Demo: build the same CSV in the browser from the window's rows. */
    var rows = demoHistory(sensor).filter(function (r) { return r.t >= view.from && r.t <= view.to; });
    var csv = "t,channel_id,label,kind,temp_f\n" + rows.map(function (r) {
      return [new Date(r.t).toISOString(), sensor.id, sensor.label, sensor.kind, r.f].join(",");
    }).join("\n") + "\n";
    var blob = new Blob([csv], { type: "text/csv" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = (sensor.label || "guardian") + "-history.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  }

  /* ---- public API ----------------------------------------------------------- */
  function sync(opts) {
    view.host = opts.host || view.host;
    view.feed = opts.feed || "";
    var rows = (opts.rows || []).map(function (r) {
      return { id: r.id, label: r.label + (r.sub ? " — " + r.sub.split("·")[0].trim() : ""), kind: r.kind };
    });
    var changed = rows.length !== view.sensors.length ||
      rows.some(function (r, i) { return !view.sensors[i] || view.sensors[i].id !== r.id; });
    view.sensors = rows;
    if (!view.sensorId || !rows.some(function (r) { return r.id === view.sensorId; })) {
      view.sensorId = rows.length ? rows[0].id : "";
      changed = true;
    }
    bind();
    /* A repaint from a background poll must never yank the analyst out of
       a zoom, so the panel only re-renders when the SENSOR SET changed. */
    if (changed || !view.host.dataset.gaPainted) {
      view.host.dataset.gaPainted = "1";
      if (view.open && changed) load(); else paint();
    }
  }

  window.WILSON_GUARDIAN_ANALYSIS = {
    sync: sync,
    load: load,
    state: view,
    /* Exposed for QA: the drawing thinner and the window math are the two
       places a bug would silently change what an analyst sees. */
    _downsample: downsample,
    _demoHistory: demoHistory
  };
})();
