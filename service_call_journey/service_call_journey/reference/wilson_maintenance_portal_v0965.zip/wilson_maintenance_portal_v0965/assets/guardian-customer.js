/*
 * WILSON REFRIGERATION GUARDIAN — CUSTOMER VIEW                     (v1.2)
 *
 * Cayden: "Is it possible to build in a path for customers to see their own
 * fridge charts? Like if they have a key they can access the tool on our
 * site and connect?"
 *
 * This page is that path. It lives on Wilson's site (one self-contained
 * file, same drop-in shape as the office module) and shows a customer
 * exactly one thing: THEIR OWN refrigeration, by access key.
 *
 * HOW THE KEY WORKS
 *   Each Guardian customer gets a long random key (generated at install,
 *   stored only in the ingest server's sensor registry). The page takes it
 *   three ways: a ?key=... link Wilson texts/emails ("bookmark this"), a
 *   paste-in field, or the browser's own memory of a previous visit
 *   (localStorage). The key IS the credential: the server answers it with
 *   that household's sensors only, and answers every wrong key with the
 *   same bare 404 — there is nothing to enumerate and no account system to
 *   build yet. Rotating a key is editing one line in the registry.
 *
 * WHAT THE CUSTOMER SEES — AND DELIBERATELY DOES NOT
 *   Sees: current temperature, a 48-hour chart, a plain-language status,
 *   when the sensor last reported, and honest footnotes (defrost bumps are
 *   normal; a sensor without power or WiFi cannot warn anyone).
 *   Does not see: internal alert vocabulary, thresholds tables, incident
 *   logs, drill anything, or any hint other households exist. The office's
 *   view is guardian.html; this page is the customer's.
 *
 * MODES
 *   ?key=demo            simulated household, no backend — for the dev and
 *                        the showroom floor.
 *   ?key=<real> (+feed)  live: GET <feed>/customer.json?key=... every 60s.
 *                        Set GUARDIAN_FEED_URL below when deployed, or pass
 *                        ?feed= while piloting.
 */
(function () {
  "use strict";

  var GUARDIAN_FEED_URL = ""; // set on deploy, e.g. "https://guardian.wilsonappliance.com"
  var KEY_STORAGE = "wilson-guardian-customer-key";
  var POLL_MS = 60000;

  var config = window.WILSON_CONFIG.tempMonitoring;
  var SIM = window.WILSON_TEMPWATCH_SIM;

  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  var params = (function () {
    try { return new URLSearchParams(window.location.search); } catch (e) { return { get: function () { return null; } }; }
  })();
  var feed = (params.get("feed") || GUARDIAN_FEED_URL || "").replace(/\/$/, "");
  var key = params.get("key") || (function () {
    try { return localStorage.getItem(KEY_STORAGE) || ""; } catch (e) { return ""; }
  })();

  function rememberKey(k) { try { localStorage.setItem(KEY_STORAGE, k); } catch (e) { /* fine */ } }

  /* ---- demo household ------------------------------------------------------ */
  var DEMO_ASSETS = [
    { id: "cust_col", brand: "Thermador", model: "T36BT925NS", typeLabel: "Refrigerator",
      type: "refrigerator", customerCategory: "refrigeration", location: "Kitchen",
      tempMonitoringOptIn: true, tempMonitoringCompartments: ["fresh_food", "freezer"] },
    { id: "cust_wine", brand: "Sub-Zero", model: "UW-24", typeLabel: "Wine Storage",
      type: "wine_beverage", customerCategory: "refrigeration", location: "Wine Room",
      tempMonitoringOptIn: true, tempMonitoringCompartments: ["wine"] }
  ];

  function demoData() {
    var sensors = [];
    DEMO_ASSETS.forEach(function (asset) {
      SIM.forAssetSensors(asset, null).forEach(function (r) {
        var latest = r.points.length ? r.points[r.points.length - 1] : null;
        sensors.push({
          label: [asset.brand, asset.typeLabel].join(" ") + " — " + asset.location +
            (r.compartmentLabel ? " (" + r.compartmentLabel + ")" : ""),
          kind: r.compartment,
          latest: latest ? latest.value : null,
          latestAt: new Date().toISOString(),
          points: r.points,
          setpointF: (config.flagRules[r.compartment] || config.flagRules.fresh_food).setpointF,
          status: "protected",
          statusLabel: "Protected",
          statusNote: "Temperatures are holding where they should."
        });
      });
    });
    return { name: "Demo Residence", generatedAt: new Date().toISOString(), sensors: sensors };
  }

  /* ---- rendering ------------------------------------------------------------ */
  /*
   * `settling` is a freshly installed sensor inside its burn-in window.
   * It is deliberately NOT toned as "ok": it does not say Protected,
   * because during burn-in the sensor is charting but not yet alerting,
   * and telling someone they are covered when they are not is the one
   * claim this product cannot make.
   */
  var STATUS_TONE = { protected: "ok", watching: "warn", responding: "dispatch",
                      offline: "offline", waiting: "waiting", settling: "burnin" };
  var OVERALL = {
    responding: "Wilson has been alerted about one of your units and is responding.",
    offline: "One of your sensors is offline — it cannot warn anyone until power and WiFi return.",
    watching: "One of your units is running warm. Most of these settle on their own — we are watching it.",
    waiting: "Waiting on a first reading from your sensors.",
    settling: "A newly installed sensor is settling into place. It starts watching within a day.",
    protected: "Your refrigeration is protected."
  };

  function chart(sensor) {
    var pts = sensor.points || [];
    if (pts.length < 2) return '<div class="gm-spark gm-spark-empty">chart appears after the first few readings</div>';
    var maxMin = pts.reduce(function (m, p) { return Math.max(m, p.minutesAgo); }, 1);
    var values = pts.map(function (p) { return p.value; }).concat([sensor.setpointF]);
    var lo = Math.min.apply(null, values) - 2, hi = Math.max.apply(null, values) + 2;
    var X = function (p) { return (100 - (p.minutesAgo / maxMin) * 100).toFixed(2); };
    var Y = function (v) { return (30 - ((v - lo) / (hi - lo)) * 30).toFixed(2); };
    var line = pts.map(function (p) { return X(p) + "," + Y(p.value); }).join(" ");
    return '<svg class="gm-spark gc-chart" viewBox="0 0 100 30" preserveAspectRatio="none">' +
      '<line x1="0" x2="100" y1="' + Y(sensor.setpointF) + '" y2="' + Y(sensor.setpointF) + '" class="gc-line-set"/>' +
      '<polyline points="' + line + '" class="gm-line-series"/></svg>';
  }

  function sensorCard(sensor) {
    var tone = STATUS_TONE[sensor.status] || "ok";
    var seen = sensor.latestAt ? new Date(sensor.latestAt) : null;
    return '<article class="gm-card gm-sensor gc-sensor">' +
      '<div class="gm-sensor-head"><div><strong>' + esc(sensor.label) + "</strong>" +
      '<span class="gm-sub">Holding near ' + esc(sensor.setpointF) + "°F" +
      (seen ? " · updated " + esc(seen.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })) : "") +
      "</span></div>" +
      '<span class="gm-badge gm-tier-' + tone + '">' + esc(sensor.statusLabel) + "</span></div>" +
      chart(sensor) +
      '<div class="gm-sensor-foot"><span class="gm-latest">' +
      (sensor.latest === null || sensor.latest === undefined ? "—" : esc(Math.round(sensor.latest * 10) / 10) + "°F") +
      '</span><span class="gm-sub">last 48 hours · the dashed line is this unit’s set point</span></div>' +
      '<div class="gm-reason gm-reason-' + (tone === "ok" ? "ok" : tone) + '">' + esc(sensor.statusNote) + "</div>" +
      "</article>";
  }

  function keyScreen(message) {
    return '<div class="gm-card gc-gate">' +
      "<h2>See your refrigeration</h2>" +
      '<p class="gm-sub">Enter the access key from your Wilson Guardian welcome note. If Wilson sent you a link, just open it — the key rides along.</p>' +
      (message ? '<p class="gc-gate-error">' + esc(message) + "</p>" : "") +
      '<div class="gc-gate-row"><input type="text" id="gc-key-input" class="gm-select gc-key-input" placeholder="Paste your access key" autocomplete="off">' +
      '<button type="button" class="gm-button" id="gc-key-go">View my charts</button></div>' +
      '<p class="gm-sub">Lost your key? Call the shop — we can re-issue it in a minute.</p></div>';
  }

  function homeScreenHint() {
    /* Suppressed once installed: in standalone display mode the hint is
       noise about a step already taken. */
    var standalone = false;
    try {
      standalone = (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches)
        || window.navigator.standalone === true;
    } catch (e) { /* fine */ }
    if (standalone) return "";
    return '<div class="gm-tally">One tap from your phone’s home screen: open this page in your phone’s browser, ' +
      "then <strong>Share → Add to Home Screen</strong> (iPhone) or <strong>menu → Add to Home screen</strong> (Android). " +
      "It installs like an app, remembers your key, and opens straight to these charts. Ask your Wilson technician about " +
      "the home-screen temperature widget — they can set it up on your phone in about two minutes.</div>";
  }

  function honesty() {
    return '<footer class="gm-foot">A word on reading these charts: brief warm-ups are NORMAL — defrost cycles ' +
      "and open doors make small hills that settle on their own, and Guardian is tuned to ignore them. We alert on " +
      "temperatures that stay wrong and fail to recover. And plainly: the sensor needs your home’s power and WiFi " +
      "to report — while either is out, it cannot warn anyone. Monitoring shortens the time a problem goes unseen; " +
      "it cannot prevent a component from failing.</footer>";
  }

  var lastError = null;
  var data = null;

  function render() {
    var root = document.getElementById("guardian-root");
    if (!root) return;
    var head = '<div class="gm-topbar"><div class="gm-brand">wilson<span>.</span>' +
      '<em class="gm-pill">' + esc(config.serviceShortName || "GUARDIAN").toUpperCase() + "</em></div>" +
      '<div class="gm-topbar-right"><span class="gm-sub">24/7 refrigeration monitoring by Wilson AC &amp; Appliance</span></div></div>';

    if (!key) { root.innerHTML = head + keyScreen(lastError); bindGate(); return; }
    if (!data) {
      root.innerHTML = head + (lastError
        ? keyScreen(lastError)
        : '<div class="gm-card gc-gate"><p class="gm-sub">Connecting to your sensors…</p></div>');
      bindGate();
      return;
    }
    var worst = "protected";
    /* Ordered worst-first. `settling` sits after the real problems and
       before "protected", so a home with one settling sensor and three
       healthy ones is not announced as fully protected. */
    ["responding", "offline", "watching", "waiting", "settling"].some(function (s) {
      if (data.sensors.some(function (x) { return x.status === s; })) { worst = s; return true; }
      return false;
    });
    root.innerHTML = head +
      '<section class="gc-hero gc-hero-' + esc(STATUS_TONE[worst] || "ok") + '"><h1>' + esc(data.name) + "</h1>" +
      "<p>" + esc(OVERALL[worst]) + "</p></section>" +
      '<div class="gm-fleet">' + data.sensors.map(sensorCard).join("") + "</div>" +
      (key === "demo" ? '<div class="gm-tally">Demo household — simulated data. A real key shows your own sensors.</div>' : "") +
      homeScreenHint() +
      honesty();
  }

  function bindGate() {
    var go = document.getElementById("gc-key-go");
    var input = document.getElementById("gc-key-input");
    if (!go || !input) return;
    var submit = function () {
      var k = input.value.trim();
      if (!k) return;
      key = k; lastError = null; data = null;
      rememberKey(k);
      refresh();
      render();
    };
    go.onclick = submit;
    input.onkeydown = function (e) { if (e.key === "Enter") submit(); };
  }

  function refresh() {
    if (!key) return;
    if (key === "demo") { data = demoData(); lastError = null; render(); return; }
    if (!feed) {
      lastError = "This page is not connected to a Guardian server yet (deploy sets the feed, or pass ?feed= while testing).";
      data = null; render(); return;
    }
    fetch(feed + "/customer.json?key=" + encodeURIComponent(key))
      .then(function (r) {
        if (r.status === 404) throw new Error("That key was not recognized. Check for missing characters, or call the shop for a fresh one.");
        if (!r.ok) throw new Error("The Guardian server answered " + r.status + ".");
        return r.json();
      })
      .then(function (d) { data = d; lastError = null; render(); })
      .catch(function (err) {
        lastError = err.message;
        data = null;
        try { localStorage.removeItem(KEY_STORAGE); } catch (e) { /* fine */ }
        key = params.get("key") === key ? "" : "";
        render();
      });
  }

  window.WILSON_GUARDIAN_CUSTOMER = { render: render, refresh: refresh };

  document.addEventListener("DOMContentLoaded", function () {
    render();
    refresh();
    setInterval(refresh, POLL_MS);
  });
})();
