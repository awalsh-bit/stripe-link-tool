/*
 * WILSON REFRIGERATION GUARDIAN — STANDALONE DASHBOARD MODULE      (v1.6)
 *
 * The temp-monitoring side of the Wilson maintenance project as ONE page a
 * dashboard drops in, the same way Jack's Filter Finder went in. Built by
 * tools/build_guardian_module.py, which inlines the SAME plan-config.js and
 * temp-monitoring.js the prototype runs — the thresholds, tiers and
 * recovery rules here are the product's own, never a copy.
 *
 * TWO MODES
 *   demo  (default)  Three simulated sensors so the page demonstrates
 *                    itself with no backend at all.
 *   live             Point it at the pilot/ingest server and it renders
 *                    the REAL fleet: ?feed=http://<shop-machine>:8091
 *                    (or set GUARDIAN_FEED_URL below). Polls /status.json
 *                    every 60s; the server ships CORS for exactly this.
 *
 * THE CLOSE-OUT PIPELINE (required, in order — Cayden's rule)
 *   A dispatch-tier sensor auto-opens a case (one per sensor per day).
 *   open -> service call logged (ref) -> service complete -> closed with a
 *   CAUSE OF FAILURE picked from the fixed taxonomy in config. No skipped
 *   steps, no free-text causes: every closed case pairs the alert with a
 *   verified diagnosis, which is the dataset Wilson farms for over-temp vs
 *   failure-type correlations.
 *
 * INTEGRATION SEAMS
 *   Case state persists to localStorage under "wilson-guardian-module-v1".
 *   To wire the dashboard's real database instead, define BEFORE this
 *   script runs:
 *     window.WILSON_GUARDIAN_ADAPTER = {
 *       load: function () { return stateObjectOrNull; },
 *       save: function (state) { ... }
 *     };
 *   The state object is JSON ({ cases: [...] }); render() reloads from the
 *   adapter on every action, so an async backend can hydrate late and call
 *   window.WILSON_GUARDIAN.render() when ready.
 *
 *   THE DISPATCH BUTTON (v1.3) — Cayden: "an admin on the back end hitting
 *   this button would move the call over from guardian directly into our
 *   existing service request queue... that way the new product merges into
 *   the existing workflow seamlessly." Every open alert carries a primary
 *   "Dispatch service tech" button. It calls:
 *     window.WILSON_GUARDIAN_DISPATCH = function (request) {
 *       // create a row in the dashboard's service request queue;
 *       // return {ok:true, ref:"SR-1234"} — or a Promise of it, or the
 *       // ref string alone. {ok:false, message} keeps the alert open.
 *     };
 *   On success the case advances to "scheduled" with the queue's own
 *   reference, so the required close-out (service complete -> cause of
 *   failure) still governs — dispatching IS the "log service call" step,
 *   done by the queue instead of a prompt. With no hook defined (demo /
 *   not yet wired) the button still advances the case under a generated
 *   GRD- reference so the flow demonstrates itself.
 *
 * BURN-IN, THE FOURTH TIER (v1.6)
 *   A sensor installed minutes ago is at room temperature in a glycol vial
 *   that has not equilibrated. It WILL read over the fresh-food line, and
 *   the rules WILL be right to say so — so for the window in
 *   plan-config's tempMonitoring.commissioning it reads `burnin`: it
 *   charts, an installer can watch it fall to set point before leaving the
 *   house, and it does not alert, does not open a case, and does not count
 *   as protecting anything. The card still shows what the rules WOULD have
 *   said, because suppressing a page is not the same as being blind.
 *   OFFLINE and WAITING still outrank it: a failed install is not a
 *   settling one. Register a sensor in demo mode to see the state.
 */
(function () {
  "use strict";

  var GUARDIAN_FEED_URL = ""; // e.g. "http://192.168.1.50:8091" — or use ?feed=
  var STORAGE_KEY = "wilson-guardian-module-v1";
  var POLL_MS = 60000;

  var config = window.WILSON_CONFIG.tempMonitoring;
  var SIM = window.WILSON_TEMPWATCH_SIM;
  var RULES = config.flagRules;
  var CAUSES = config.failureCauses || [];
  var COMMISSIONING = config.commissioning || {};

  /* ---- tiny utilities ---------------------------------------------------- */
  function esc(t) {
    return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function isoDay(ms) { return new Date(ms).toISOString().slice(0, 10); }

  /* ---- state (cases), through the adapter seam --------------------------- */
  var adapter = window.WILSON_GUARDIAN_ADAPTER || {
    load: function () {
      try { return JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch (e) { return null; }
    },
    save: function (state) {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) { /* private mode */ }
    }
  };
  function loadState() {
    var s = adapter.load() || {};
    if (!Array.isArray(s.cases)) s.cases = [];
    return s;
  }
  function saveState(s) { adapter.save(s); }

  /* ---- the fleet: demo or live ------------------------------------------- */
  var DEMO_ASSETS = [
    { id: "demo_col", brand: "Thermador", model: "T36BT925NS", typeLabel: "Refrigerator",
      type: "refrigerator", customerCategory: "refrigeration", location: "Kitchen",
      householdName: "Demo — Davenport", tempMonitoringOptIn: true,
      tempMonitoringCompartments: ["fresh_food", "freezer"] },
    { id: "demo_fail", brand: "Sub-Zero", model: "BI-48S", typeLabel: "Refrigerator",
      type: "refrigerator", customerCategory: "refrigeration", location: "Main Kitchen",
      householdName: "Demo — Reynolds", tempMonitoringOptIn: true,
      tempMonitoringCompartments: ["fresh_food"] },
    { id: "demo_wine", brand: "Sub-Zero", model: "UW-24", typeLabel: "Wine Storage",
      type: "wine_beverage", customerCategory: "refrigeration", location: "Wine Room",
      householdName: "Demo — Reynolds", tempMonitoringOptIn: true,
      tempMonitoringCompartments: ["wine"] }
  ];

  /* Set from the feed itself: the ingest server reports whether it is
     running in rehearsal mode, and a screen showing invented readings has
     to say so. See the badge in render(). */
  var feed = (function () {
    try {
      var q = new URLSearchParams(window.location.search).get("feed");
      return (q || GUARDIAN_FEED_URL || "").replace(/\/$/, "");
    } catch (e) { return GUARDIAN_FEED_URL; }
  })();
  var live = { rows: null, error: null, at: null, rehearsal: false };

  /* Both modes normalize to one row shape the renderer speaks. */
  function demoRows() {
    var rows = [];
    DEMO_ASSETS.forEach(function (asset) {
      SIM.forAssetSensors(asset, { name: asset.householdName }).forEach(function (r) {
        var latest = r.points.length ? r.points[r.points.length - 1].value : null;
        rows.push({
          id: asset.id + "|" + r.compartment,
          label: [asset.brand, asset.model].join(" "),
          sub: asset.householdName + " · " + asset.location +
            (r.compartmentLabel ? " · " + r.compartmentLabel : ""),
          kind: r.compartment,
          tier: r.flag.tier || "ok",
          reason: r.flag.reason || "",
          overForMinutes: r.flag.overForMinutes || 0,
          latest: latest,
          points: r.points,
          stats: r.stats
        });
      });
    });
    /* Sensors registered through the demo Install panel join the fleet as
       simulated healthy units, so an install visibly lands somewhere. */
    demoInstalls().forEach(function (inst) {
      var asset = {
        id: inst.id, brand: "", model: "", typeLabel: "Refrigeration",
        type: KIND_TO_TYPE[inst.kind] || "refrigerator", customerCategory: "refrigeration",
        location: "", tempMonitoringOptIn: true, tempMonitoringCompartments: [inst.kind]
      };
      /* A sensor registered in this session was, by definition, installed
         seconds ago — so demo mode shows the burn-in state for real rather
         than describing it, and the dev sees the fourth tier without
         having to wire a backend first. */
      var commissioning = SIM.commissioningState(inst.installedAt || null, Date.now());
      SIM.forAssetSensors(asset, null).forEach(function (r) {
        var latest = r.points.length ? r.points[r.points.length - 1].value : null;
        var ruleTier = r.flag.tier || "ok";
        rows.push({
          id: inst.id + "|" + r.compartment,
          label: inst.label,
          sub: inst.household + " · installed this session · " + inst.channelId,
          kind: r.compartment,
          tier: commissioning.burningIn ? "burnin" : ruleTier,
          underlyingTier: ruleTier,
          commissioning: commissioning,
          reason: r.flag.reason || "",
          overForMinutes: r.flag.overForMinutes || 0, latest: latest,
          points: r.points, stats: r.stats
        });
      });
    });
    return sortRows(rows);
  }

  function liveRows() {
    return sortRows((live.rows || []).map(function (s) {
      return {
        id: s.channelId,
        label: s.label || s.channelId,
        sub: "Channel " + s.channelId + " · " + s.kind.replace("_", " "),
        kind: s.kind,
        tier: s.tier,
        reason: s.reason || "",
        overForMinutes: s.overForMinutes || 0,
        latest: s.latest,
        points: s.points || [],
        stats: s.stats,
        underlyingTier: s.underlyingTier || null,
        commissioning: s.commissioning || null,
        battery: s.battery || null,
        radio: s.radio || null
      };
    }));
  }

  /* dispatch ranks 0, and `0 || 9` is 9 — the QA suite caught exactly that
     falsy-zero bug sorting dispatches LAST. Hence the `in` check.

     Burn-in sits above `waiting` and below every alert: it is not a
     problem, but it is the row an installer standing at the fridge is
     looking for, so it must not sink to the bottom of a long fleet. */
  var TIER_RANK = { dispatch: 0, warn: 1, offline: 2, burnin: 3, waiting: 4, ok: 5 };
  function rank(tier) { return tier in TIER_RANK ? TIER_RANK[tier] : 9; }
  function sortRows(rows) {
    return rows.sort(function (a, b) {
      var d = rank(a.tier) - rank(b.tier);
      return d !== 0 ? d : a.label.localeCompare(b.label);
    });
  }

  function currentRows() { return feed ? liveRows() : demoRows(); }

  /* ---- the case pipeline -------------------------------------------------- */
  function syncCases(rows) {
    var state = loadState();
    var changed = false;
    rows.forEach(function (row) {
      if (row.tier !== "dispatch") return;
      var key = row.id + "|" + isoDay(Date.now());
      if (state.cases.some(function (c) { return c.key === key; })) return;
      /* One case per sensor per day, exactly like the prototype store. */
      state.cases.unshift({
        id: "case_" + Math.random().toString(16).slice(2, 10),
        key: key, sensorId: row.id, label: row.label, sub: row.sub, kind: row.kind,
        flagLabel: row.reason || "Over-temperature dispatch",
        reading: row.latest,
        createdAt: new Date().toISOString(),
        status: "open"
      });
      changed = true;
    });
    if (changed) saveState(state);
    return state;
  }

  function caseAction(caseId, action, payload) {
    var state = loadState();
    var c = state.cases.find(function (x) { return x.id === caseId; });
    if (!c) return { ok: false, message: "Case not found." };
    if (action === "schedule") {
      if (c.status !== "open") return { ok: false, message: "Already " + c.status + "." };
      c.status = "scheduled";
      c.serviceOrderRef = (payload && payload.ref) || "";
      c.dispatchedVia = (payload && payload.via) || "manual";
      c.scheduledAt = new Date().toISOString();
    } else if (action === "serviced") {
      if (c.status !== "scheduled") return { ok: false, message: c.status === "open" ? "Log the service call first — the pipeline does not skip steps." : "Already " + c.status + "." };
      c.status = "serviced";
      c.servicedAt = new Date().toISOString();
    } else if (action === "close") {
      if (c.status !== "serviced") return { ok: false, message: c.status === "closed" ? "Already closed." : "Complete the service call first — the cause is recorded from what the technician actually found." };
      var cause = CAUSES.find(function (x) { return x.id === (payload && payload.cause); });
      if (!cause) return { ok: false, message: "Pick the cause of failure from the list — the alert cannot clear without it." };
      var notes = (payload && payload.notes || "").trim();
      if (cause.notesRequired && !notes) return { ok: false, message: "'" + cause.label + "' needs a note describing what was found." };
      c.status = "closed";
      c.cause = cause.id;
      c.causeLabel = cause.label;
      c.signatureMode = cause.signatureMode || "";
      c.causeNotes = notes;
      c.closedAt = new Date().toISOString();
    }
    saveState(state);
    return { ok: true, kase: c };
  }

  /*
   * DISPATCH INTO THE DASHBOARD'S SERVICE REQUEST QUEUE.
   *
   * Builds the service-request payload from the case, hands it to the
   * dashboard's hook, and advances the case on success. The payload is the
   * CONTRACT (documented in GUARDIAN_HANDOFF.md): everything the queue
   * needs to work the call without opening Guardian first.
   */
  function dispatchRequest(c) {
    return {
      source: "wilson-guardian",
      caseId: c.id,
      priority: "guardian-dispatch",
      summary: c.label + " — " + c.flagLabel,
      sensor: { id: c.sensorId, label: c.label, detail: c.sub, kind: c.kind },
      readingF: c.reading !== null && c.reading !== undefined ? c.reading : null,
      alertAt: c.createdAt,
      requestedAt: new Date().toISOString(),
      notes: "Opened from a Wilson Guardian over-temp alert. Alert must be closed in Guardian with a cause of failure after the call is complete."
    };
  }

  function normalizeDispatchResult(raw) {
    if (typeof raw === "string" && raw.trim()) return { ok: true, ref: raw.trim() };
    if (raw && typeof raw === "object") {
      if (raw.ok === false) return { ok: false, message: raw.message || "The service request queue refused the dispatch." };
      var ref = raw.ref || raw.reference || raw.id || "";
      return { ok: true, ref: String(ref || "") };
    }
    return { ok: true, ref: "" };
  }

  function dispatchCase(caseId, done) {
    var state = loadState();
    var c = state.cases.find(function (x) { return x.id === caseId; });
    if (!c) { if (done) done({ ok: false, message: "Case not found." }); return; }
    if (c.status !== "open") { if (done) done({ ok: false, message: "Already " + c.status + "." }); return; }

    var hook = window.WILSON_GUARDIAN_DISPATCH;
    if (typeof hook !== "function") {
      /* Not wired yet (demo, or the dev has not connected the queue):
         advance under a generated reference so the flow demonstrates
         itself, and say which seam makes it real. */
      var ref = "GRD-" + Date.now().toString(36).toUpperCase();
      var res = caseAction(caseId, "schedule", { ref: ref, via: "queue-demo" });
      if (done) done(res.ok
        ? { ok: true, ref: ref, demo: true }
        : { ok: false, message: res.message });
      return;
    }
    var outcome;
    try { outcome = hook(dispatchRequest(c)); }
    catch (e) { if (done) done({ ok: false, message: "Dispatch hook threw: " + e.message }); return; }
    var settle = function (raw) {
      var norm = normalizeDispatchResult(raw);
      if (!norm.ok) { if (done) done(norm); return; }
      var res = caseAction(caseId, "schedule", { ref: norm.ref, via: "queue" });
      if (done) done(res.ok ? { ok: true, ref: norm.ref } : { ok: false, message: res.message });
    };
    /* A synchronous hook settles synchronously — wrapping every result in
       Promise.resolve deferred even plain returns to a microtask, which the
       QA sandbox (rightly) caught as "nothing happened". */
    if (outcome && typeof outcome.then === "function") {
      outcome.then(settle, function (err) {
        if (done) done({ ok: false, message: "The service request queue did not accept the dispatch: " + (err && err.message ? err.message : String(err)) });
      });
    } else {
      settle(outcome);
    }
  }

  /*
   * THE INSTALL PANEL.                                             (v1.4)
   *
   * Binds a sensor to a compartment, a label, and a household — the step
   * that used to be hand-editing the registry. Live mode drives the ingest
   * server's /admin/install (token in the x-guardian-admin header; the
   * server generates the household's access key and returns it EXACTLY
   * ONCE — the panel displays it with the customer's charts link and it is
   * never retrievable again). Demo mode registers a simulated sensor so
   * the flow demonstrates itself with no backend.
   */
  var install = { customers: null, result: null, error: null, busy: false };

  var KIND_OPTIONS = [
    { id: "fresh_food", label: "Fresh food compartment" },
    { id: "freezer", label: "Freezer compartment" },
    { id: "wine", label: "Wine storage" }
  ];
  var KIND_TO_TYPE = { fresh_food: "refrigerator", freezer: "freezer", wine: "wine_beverage" };

  function adminToken(set) {
    try {
      if (set !== undefined) localStorage.setItem("wilson-guardian-admin-token", set);
      return localStorage.getItem("wilson-guardian-admin-token") || "";
    } catch (e) { return ""; }
  }

  function demoInstalls() {
    var s = loadState();
    return Array.isArray(s.demoInstalls) ? s.demoInstalls : [];
  }

  function installPanel() {
    var options = KIND_OPTIONS.map(function (k) {
      return '<option value="' + k.id + '">' + esc(k.label) + "</option>";
    }).join("");
    var households = (install.customers || []).map(function (c) {
      return '<option value="' + esc(c.id) + '">' + esc(c.name) + " (" + (c.channelIds || []).length + " sensor" + ((c.channelIds || []).length === 1 ? "" : "s") + ")</option>";
    }).join("");
    var keyPanel = "";
    if (install.result && install.result.key) {
      var link = "guardian-customer.html?key=" + encodeURIComponent(install.result.key);
      keyPanel = '<div class="gm-keyonce">' +
        "<strong>New household created — this key is shown ONCE.</strong>" +
        '<code class="gm-keycode">' + esc(install.result.key) + "</code>" +
        '<span class="gm-sub">Send the customer their charts link now (it carries the key): ' +
        '<a href="' + esc(link) + '">' + esc(link) + "</a></span>" +
        '<span class="gm-sub">If it is lost, re-issue a fresh key in the registry — the old one cannot be recovered.</span></div>';
    } else if (install.result) {
      keyPanel = '<div class="gm-tally">Registered to ' + esc(install.result.customer.name) +
        " — Waiting until its first reading, then " + esc(COMMISSIONING.label || "Burn-in") +
        " for " + esc(COMMISSIONING.hours || 24) + "h.</div>";
    }
    return '<section class="gm-section" id="gm-install"><details' + (install.result || install.error ? " open" : "") + ">" +
      "<summary>Install a sensor</summary>" +
      '<div class="gm-card gm-install-card">' +
      (install.error ? '<div class="gm-reason gm-reason-dispatch">' + esc(install.error) + "</div>" : "") +
      keyPanel +
      '<div class="gm-install-grid">' +
      '<label><span>Sensor DevEUI (on the sticker)</span><input class="gm-select" id="gm-in-deveui" placeholder="a84041ffff123456" autocomplete="off"></label>' +
      '<label><span>Compartment</span><select class="gm-select" id="gm-in-kind">' + options + "</select></label>" +
      '<label><span>Label (customer reads this)</span><input class="gm-select" id="gm-in-label" placeholder="Kitchen Sub-Zero — fresh food" autocomplete="off"></label>' +
      '<label><span>Household</span><select class="gm-select" id="gm-in-household"><option value="">+ New household…</option>' + households + "</select></label>" +
      '<label><span>New household name</span><input class="gm-select" id="gm-in-name" placeholder="The Davenport Residence" autocomplete="off"></label>' +
      '<label><span>Alert email (optional)</span><input class="gm-select" id="gm-in-email" placeholder="customer@example.com" autocomplete="off"></label>' +
      '<label><span>Alert phone (optional)</span><input class="gm-select" id="gm-in-phone" placeholder="512-555-0100" autocomplete="off"></label>' +
      (feed ? '<label><span>Admin token (from the server operator)</span><input class="gm-select" id="gm-in-token" type="password" value="' + esc(adminToken()) + '" autocomplete="off"></label>' : "") +
      "</div>" +
      '<button type="button" class="gm-button" id="gm-in-register"' + (install.busy ? " disabled" : "") + ">" +
      (install.busy ? "Registering…" : "Register sensor" + (feed ? "" : " (demo)")) + "</button>" +
      '<span class="gm-sub">Glycol probe in the vial, sensor beside it, all inside the compartment. The key belongs to the customer — it is never stored on this screen.</span>' +
      '<span class="gm-sub gm-install-burnin"><strong>' + esc(COMMISSIONING.hours || 24) + "-hour burn-in: </strong>" +
      esc(COMMISSIONING.installNote || "") + "</span>" +
      "</div></details></section>";
  }

  function loadHouseholds() {
    if (!feed || install.customers !== null) return;
    fetch(feed + "/admin/customers", { headers: { "x-guardian-admin": adminToken() } })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error(r.status === 403 ? "Admin token not accepted." : "Server answered " + r.status + ".")); })
      .then(function (d) { install.customers = d.customers || []; render(); })
      .catch(function () { install.customers = []; });
  }

  function registerSensor() {
    var val = function (id) { var el = document.getElementById(id); return el ? String(el.value || "").trim() : ""; };
    var payload = {
      channelId: val("gm-in-deveui").toLowerCase(),
      kind: val("gm-in-kind") || "fresh_food",
      label: val("gm-in-label"),
      householdId: val("gm-in-household") || undefined,
      householdName: val("gm-in-name") || undefined,
      contactEmail: val("gm-in-email") || undefined,
      contactPhone: val("gm-in-phone") || undefined
    };
    install.error = null; install.result = null;
    if (!payload.channelId) { install.error = "The sensor's DevEUI is required — it is on the unit's sticker."; render(); return; }
    if (!payload.label) { install.error = "Give the sensor a label; it is what the customer and the office both read."; render(); return; }
    if (!payload.householdId && !payload.householdName) { install.error = "Pick an existing household or name a new one."; render(); return; }

    if (!feed) {
      /* Demo: register locally so the fleet gains a simulated row. */
      var state = loadState();
      state.demoInstalls = demoInstalls().concat([{
        id: "inst_" + Math.random().toString(16).slice(2, 8),
        channelId: payload.channelId, kind: payload.kind, label: payload.label,
        household: payload.householdName || "(existing household)",
        installedAt: new Date().toISOString()
      }]);
      saveState(state);
      install.result = payload.householdName
        ? { key: "demo-" + Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2), customer: { name: payload.householdName } }
        : { customer: { name: "(existing household)" } };
      render();
      return;
    }
    install.busy = true; render();
    adminToken(val("gm-in-token"));
    fetch(feed + "/admin/install", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-guardian-admin": adminToken() },
      body: JSON.stringify(payload)
    }).then(function (r) { return r.json().then(function (d) { return { status: r.status, data: d }; }); })
      .then(function (out) {
        install.busy = false;
        if (out.status !== 200) { install.error = out.data.error || ("Server answered " + out.status + "."); render(); return; }
        install.result = out.data;
        install.customers = null; /* re-fetch the picker with the new household */
        loadHouseholds();
        render();
        poll();
      })
      .catch(function (err) { install.busy = false; install.error = "Could not reach the server: " + err.message; render(); });
  }

  /* ---- rendering ----------------------------------------------------------- */
  function bandRule(kind) { return RULES[kind] || RULES.fresh_food; }

  function spark(row) {
    var pts = row.points || [];
    if (pts.length < 2) return '<div class="gm-spark gm-spark-empty">no series yet</div>';
    var rule = bandRule(row.kind);
    var maxMin = pts.reduce(function (m, p) { return Math.max(m, p.minutesAgo); }, 1);
    var values = pts.map(function (p) { return p.value; }).concat([rule.dispatchF, rule.setpointF]);
    var lo = Math.min.apply(null, values) - 2, hi = Math.max.apply(null, values) + 2;
    var X = function (p) { return (100 - (p.minutesAgo / maxMin) * 100).toFixed(2); };
    var Y = function (v) { return (30 - ((v - lo) / (hi - lo)) * 30).toFixed(2); };
    var line = pts.map(function (p) { return X(p) + "," + Y(p.value); }).join(" ");
    return '<svg class="gm-spark" viewBox="0 0 100 30" preserveAspectRatio="none">' +
      '<line x1="0" x2="100" y1="' + Y(rule.maxF) + '" y2="' + Y(rule.maxF) + '" class="gm-line-warn"/>' +
      '<line x1="0" x2="100" y1="' + Y(rule.dispatchF) + '" y2="' + Y(rule.dispatchF) + '" class="gm-line-dispatch"/>' +
      '<polyline points="' + line + '" class="gm-line-series"/></svg>';
  }

  function tierBadge(tier) {
    var label = { ok: "OK", warn: "Warning", dispatch: "DISPATCH", offline: "Offline",
                  waiting: "Waiting", burnin: COMMISSIONING.label || "Burn-in" }[tier] || tier;
    return '<span class="gm-badge gm-tier-' + esc(tier) + '">' + esc(label) + "</span>";
  }

  /*
   * Radio and battery, when the feed knows them. On hardware week these
   * are the two numbers being watched, and they are read together or not
   * at all -- a marginal RSSI and a sagging cell are the same
   * conversation. A low cell is called out rather than printed plainly,
   * because it is the one of the two that has an errand attached.
   */
  function healthLine(row) {
    var parts = [];
    if (row.radio && row.radio.rssi !== null && row.radio.rssi !== undefined) parts.push("RSSI " + esc(row.radio.rssi));
    if (row.radio && row.radio.snr !== null && row.radio.snr !== undefined) parts.push("SNR " + esc(row.radio.snr));
    if (row.battery && row.battery.known) {
      parts.push(row.battery.level === "ok"
        ? esc(row.battery.volts) + "V"
        : '<strong class="gm-batt-' + esc(row.battery.level) + '">' + esc(row.battery.volts) + "V · " + esc(row.battery.level) + "</strong>");
    }
    return parts.length ? '<div class="gm-sub gm-health">' + parts.join(" · ") + "</div>" : "";
  }

  function sensorCard(row) {
    var rule = bandRule(row.kind);
    var burning = row.tier === "burnin";
    return '<article class="gm-card gm-sensor gm-sensor-' + esc(row.tier) + '">' +
      '<div class="gm-sensor-head"><div><strong>' + esc(row.label) + "</strong>" +
      '<span class="gm-sub">' + esc(row.sub) + "</span></div>" + tierBadge(row.tier) + "</div>" +
      spark(row) +
      '<div class="gm-sensor-foot">' +
      '<span class="gm-latest">' + (row.latest === null || row.latest === undefined ? "—" : esc(Math.round(row.latest * 10) / 10) + "°F") + "</span>" +
      '<span class="gm-sub">set ' + esc(rule.setpointF) + "°F · warn &gt;" + esc(rule.maxF) + "°F · dispatch &gt;" + esc(rule.dispatchF) + "°F</span>" +
      "</div>" +
      healthLine(row) +
      /*
       * During burn-in the card says three things, in this order, because
       * that is the order the person reading it needs them: it is not
       * alerting, how long is left, and what the rules WOULD have said.
       * The last one is what keeps suppression from being blindness.
       */
      (burning
        ? '<div class="gm-reason gm-reason-burnin">' +
          esc(COMMISSIONING.officeNote || "Settling in after install — charting, not alerting yet.") +
          (row.commissioning && row.commissioning.hoursLeft
            ? " <strong>" + esc(row.commissioning.hoursLeft) + "h left</strong>" : "") +
          (row.underlyingTier && row.underlyingTier !== "ok"
            ? '<span class="gm-sub">Suppressed while settling: the rules currently read <strong>' +
              esc(row.underlyingTier) + "</strong>. If it is not falling toward set point, the placement is wrong — not the sensor.</span>"
            : "") +
          "</div>"
        : row.reason
          ? '<div class="gm-reason gm-reason-' + esc(row.tier) + '">' + esc(row.reason) +
            (row.overForMinutes ? " · over for " + esc(Math.round(row.overForMinutes / 6) / 10) + "h" : "") + "</div>"
          : "") +
      "</article>";
  }

  function caseCard(c) {
    var stateLine = c.status === "open" ? "Alert open — no service call yet"
      : c.status === "scheduled"
        ? (c.dispatchedVia === "queue" || c.dispatchedVia === "queue-demo"
          ? "In the service request queue" + (c.serviceOrderRef ? " · " + esc(c.serviceOrderRef) : "")
          : "Service call scheduled" + (c.serviceOrderRef ? " · " + esc(c.serviceOrderRef) : ""))
      : "Serviced — cause of failure not recorded yet";
    var action = c.status === "open"
      ? '<button type="button" class="gm-button" data-gm-dispatch="' + esc(c.id) + '">Dispatch service tech</button>' +
        '<button type="button" class="gm-linklike" data-gm-schedule="' + esc(c.id) + '">or log a call made outside the queue</button>'
      : c.status === "scheduled"
        ? '<button type="button" class="gm-button" data-gm-serviced="' + esc(c.id) + '">Service complete</button>'
        : '<select class="gm-select" data-gm-cause-for="' + esc(c.id) + '"><option value="">Cause of failure…</option>' +
          CAUSES.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(x.label) + "</option>"; }).join("") +
          '</select><button type="button" class="gm-button" data-gm-close="' + esc(c.id) + '">Close alert</button>';
    return '<article class="gm-card gm-case">' +
      '<div class="gm-case-main"><strong>' + esc(c.label) + '</strong><span class="gm-sub">' + esc(c.sub) + "</span>" +
      '<span class="gm-sub">' + esc(c.flagLabel) + (c.reading !== null && c.reading !== undefined ? " · " + esc(c.reading) + "°F at alert" : "") + "</span>" +
      '<span class="gm-case-state">' + stateLine + "</span></div>" +
      '<div class="gm-case-actions">' + action + "</div></article>";
  }

  function causeTally(state) {
    var closed = state.cases.filter(function (c) { return c.status === "closed"; });
    if (!closed.length) return "";
    var tally = {};
    closed.forEach(function (c) { tally[c.causeLabel || c.cause] = (tally[c.causeLabel || c.cause] || 0) + 1; });
    return '<div class="gm-tally">Causes recorded so far: ' +
      Object.keys(tally).map(function (k) { return esc(k) + " × " + tally[k]; }).join(" · ") +
      " — every close-out feeds the over-temp vs. cause dataset.</div>";
  }

  /*
   * The root holds two children: #gm-main, which this module repaints
   * wholesale, and #gm-analysis-host, which it never touches. The analysis
   * panel owns its own DOM because an analyst three zooms deep must not
   * lose their place to a background poll.
   */
  function mainHost() {
    var root = document.getElementById("guardian-root");
    if (!root) return null;
    if (!root.querySelector("#gm-main")) {
      root.innerHTML = '<div id="gm-main"></div><div id="gm-analysis-host"></div>';
    }
    return root.querySelector("#gm-main");
  }

  function render() {
    var root = mainHost();
    if (!root) return;
    var rows = currentRows();
    var state = syncCases(rows);
    var openCases = state.cases.filter(function (c) { return c.status !== "closed"; });

    var modeBadge = feed
      ? (live.error
        ? '<span class="gm-badge gm-tier-offline">Live feed unreachable: ' + esc(live.error) + "</span>"
        : live.rehearsal
          ? '<span class="gm-badge gm-mode-rehearsal">Rehearsal — invented data' + (live.at ? " · " + esc(live.at) : "") + "</span>"
          : '<span class="gm-badge gm-mode-live">Live · ' + esc(feed) + (live.at ? " · " + esc(live.at) : "") + "</span>")
      : '<span class="gm-badge gm-mode-demo">Demo data — add ?feed=http://&lt;shop-machine&gt;:8091 for the live fleet</span>';

    root.innerHTML =
      /* A badge can be missed at a glance across a desk; a bar across the
         top of the screen cannot. Only ever shown when the SERVER says so. */
      (live.rehearsal
        ? '<div class="gm-rehearsal-bar">Rehearsal — every reading on this screen is invented. ' +
          'No refrigerator, no customer, nothing to act on.</div>'
        : "") +
      '<div class="gm-topbar"><div class="gm-brand">wilson<span>.</span>' +
      '<em class="gm-pill">' + esc(config.serviceShortName || "GUARDIAN").toUpperCase() + "</em></div>" +
      '<div class="gm-topbar-right">' + modeBadge + "</div></div>" +

      (openCases.length
        ? '<section class="gm-section"><h2>Alerts to close <span class="gm-count">' + openCases.length + "</span></h2>" +
          '<p class="gm-sub">Required, in order: log the service call, complete it, record the cause of failure. An alert cannot clear without all three.</p>' +
          openCases.map(caseCard).join("") + "</section>"
        : "") +

      '<section class="gm-section"><h2>Monitored fleet <span class="gm-count">' + rows.length + "</span></h2>" +
      (rows.length
        ? '<div class="gm-fleet">' + rows.map(sensorCard).join("") + "</div>"
        : '<div class="gm-sub">No sensors reporting' + (feed ? " on this feed yet." : ".") + "</div>") +
      "</section>" +

      causeTally(state) +

      installPanel() +

      '<footer class="gm-foot">Judged by the production flag rules: fresh food warn &gt;' +
      esc(RULES.fresh_food.maxF) + "°F/" + esc(RULES.fresh_food.holdMinutes) + "m, dispatch &gt;" +
      esc(RULES.fresh_food.dispatchF) + "°F/" + esc(RULES.fresh_food.dispatchHoldMinutes) +
      "m or no recovery in " + esc(RULES.fresh_food.recoverWithinMinutes) + "m; freezer and wine carry their own bands; sensor silence past " +
      esc(RULES.offline.holdMinutes) + "m alerts on its own. A sensor installed in the last " +
      esc(COMMISSIONING.hours || 24) + "h is settling in and does not alert.</footer>";

    /* Hand the analysis panel the current fleet; it decides whether that
       is a change worth re-rendering for. */
    if (window.WILSON_GUARDIAN_ANALYSIS) {
      window.WILSON_GUARDIAN_ANALYSIS.sync({
        host: document.getElementById("gm-analysis-host"),
        feed: feed,
        rows: rows
      });
    }
  }

  /* ---- events --------------------------------------------------------------- */
  function toast(title, message) { window.alert(title + "\n\n" + message); }

  document.addEventListener("click", function (event) {
    var reg = event.target.closest ? event.target.closest("#gm-in-register") : null;
    if (reg) { registerSensor(); return; }
    var summary = event.target.closest ? event.target.closest("#gm-install summary") : null;
    if (summary) { loadHouseholds(); return; }
    var el = event.target.closest("[data-gm-dispatch],[data-gm-schedule],[data-gm-serviced],[data-gm-close]");
    if (!el) return;
    if (el.dataset.gmDispatch) {
      el.disabled = true;
      dispatchCase(el.dataset.gmDispatch, function (res) {
        if (!res.ok) toast("Not dispatched", res.message);
        else if (res.demo) toast("Dispatched (demo)",
          "In the dashboard this lands in the service request queue — the dev wires window.WILSON_GUARDIAN_DISPATCH (see GUARDIAN_HANDOFF.md). Ref " + res.ref + ".");
        render();
      });
      return;
    }
    var res;
    if (el.dataset.gmSchedule) {
      var ref = (window.prompt("Service order / ticket for this call (optional):", "") || "").trim();
      res = caseAction(el.dataset.gmSchedule, "schedule", { ref: ref });
    } else if (el.dataset.gmServiced) {
      res = caseAction(el.dataset.gmServiced, "serviced");
    } else {
      var select = document.querySelector('[data-gm-cause-for="' + el.dataset.gmClose + '"]');
      var causeId = select ? select.value : "";
      var causeDef = CAUSES.find(function (x) { return x.id === causeId; });
      var notes = "";
      if (causeDef && causeDef.notesRequired) notes = (window.prompt("Describe what the technician found:", "") || "").trim();
      res = caseAction(el.dataset.gmClose, "close", { cause: causeId, notes: notes });
    }
    if (res && !res.ok) toast("Still open", res.message);
    render();
  });

  /* ---- live polling ----------------------------------------------------------- */
  function installHasFocus() {
    try {
      return Boolean(document.activeElement && document.activeElement.closest && document.activeElement.closest("#gm-install"));
    } catch (e) { return false; }
  }

  function poll() {
    if (!feed) return;
    fetch(feed + "/status.json").then(function (r) { return r.json(); }).then(function (data) {
      live.rows = data.sensors || [];
      live.error = null;
      live.at = new Date().toLocaleTimeString();
      /*
       * The server says whether its readings are invented. Believe it.
       * A rehearsal that looks identical to production is how somebody
       * eventually mistakes a drill for a real refrigerator -- and the
       * whole product rests on people trusting what this screen says.
       */
      live.rehearsal = data.rehearsal === true;
      /* Never wipe a half-typed install form with a background refresh —
         the data lands, the repaint waits. */
      if (!installHasFocus()) render();
    }).catch(function (err) {
      live.error = err.message;
      if (!installHasFocus()) render();
    });
  }

  window.WILSON_GUARDIAN = { render: render, caseAction: caseAction, dispatchCase: dispatchCase, currentRows: currentRows };

  document.addEventListener("DOMContentLoaded", function () {
    render();
    if (feed) { poll(); setInterval(poll, POLL_MS); }
  });
})();
