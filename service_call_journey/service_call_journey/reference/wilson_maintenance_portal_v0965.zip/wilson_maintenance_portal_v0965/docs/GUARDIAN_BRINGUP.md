# Guardian hardware bring-up runbook

**Read this the day the boxes arrive. Work the layers in order.**

There are six layers between a sensor and a temperature on Cayden's screen:

```
LHT65N  --LoRa-->  M2 gateway  --UDP-->  ChirpStack  --MQTT-->  bridge  --HTTP-->  pilot server  --> office module
```

When nothing shows up, the expensive part is not fixing it — it is finding
out **which** of the six is dead. That is what this document is for: bring up
one layer, prove it with the command given, and only then move on. Each step
below has an exact command, the exact output that means *pass*, and the
failure signature with its fix.

Do not skip ahead to putting a sensor in a refrigerator. The first sensor
goes on the bench next to the gateway with the probe in open air. A radio
problem and a placement problem look identical from the office, and you only
get to tell them apart by proving the radio first.

---

## GATEWAY DAY — everything you can do before the sensors land

The M2 arrived first. That is lucky rather than awkward: **five of the six
layers can be proven, and the whole office workflow rehearsed, with no
sensor in the building.** Work this section now and hardware day becomes
"register three devices and watch them join" instead of a day of Docker.

### G1. Let the gateway update itself first

Power it, antenna on, Ethernet in, and leave it alone until the top LED is
**solid green**. A brand-new unit ships on factory firmware and updates
itself once it has internet — a **solid white** LED means exactly that is
pending. Do not start configuring through an update.

LED meanings, from Seeed's quick-start card, and worth knowing because two
of them are easy to misread:

| LED | Means |
|---|---|
| Green, solid | Healthy, internet connected |
| Green, slow blink | Booting (about 15 s) |
| Blue, solid | **Online path not established yet — configure it.** The usual first-boot state |
| Blue, slow blink | Config/AP mode (exits itself after 5 min) |
| White, solid | Factory firmware; will auto-update once online |
| Orange, slow blink | **Updating — do not power off** |
| **Red, slow blink** | **Not connected to the LoRaWAN network server** |
| Red, solid | Hardware fault or no internet |

The two easy misreads: **green solid means the internet is fine, NOT that
your ChirpStack link is up** — there is no separate LED for the packet
forwarder. And **red slow blink is the one you will be looking at all day**;
it means the gateway is healthy but cannot reach your server.

> **Do not flash the open-source firmware.** Seeed publishes one, and it is
> a one-way door: *"After flashing the open source firmware, you CAN NOT
> revert to the factory firmware."* The factory image does everything this
> pilot needs.

### G2. Get into the console, and write the password down

The M2 runs a local web console. Two ways in:

- **Its own access point** (first boot or recovery): hold the button ~5 s
  until the LED blinks blue, join the WiFi network **`SenseCAP_XXXXXX`**
  (last six of the MAC) with password **`12345678`**, then browse to
  **`http://192.168.168.1`**.
- **Over your LAN**: find its DHCP lease on the router and browse to that
  address. `192.168.168.1` is only its own AP-side address.

**The username is `admin`; the PASSWORD is unique per unit and printed on
the label on the back**, next to the AP IP address. Photograph the label
before the gateway goes on a wall — it is the single most annoying thing to
be missing later. (Seeed's `admin`/`admin` default belongs to the
*ChirpStack* login in the on-gateway "Local Network Server" mode, which is
not what we are using.)

> **Change that password at first login, and record the new one in a
> password manager — not in this repository, not in a chat, not in a
> photograph.** The label is a credential: anyone holding a picture of it
> plus access to the shop LAN owns the gateway. Seeed prints "please do not
> share this label" on it for that reason. Everything else on the label —
> EUI, MACs, serial — is fine to pass around.

Two things the label settles that the vendor documentation does not:

- The **EUI is independently assigned, not derived from the MAC.** On the
  unit here the Ethernet MAC and the LoRa EUI share only Seeed's `2CF7F1`
  OUI and diverge after it, so there is no computing one from the other.
  Read the EUI, do not derive it.
- **"Firmware: Multi-Platform version"** on the label is the confirmation
  that this SKU can be pointed at a private LoRaWAN server at all. The
  Data-Only variant cannot.

### G3. Point it at Wilson's ChirpStack

Bring the stack up first (that is Layer 1 below — do it now):

```bash
cd tools/guardian-chirpstack
docker compose up -d
```

Then in the M2 console: **`LoRa` → `LoRa Network`**, and set **Mode =
Packet Forward** (the Semtech UDP forwarder).

- **Server Address:** the pilot machine's LAN IP
- **Server Port Up / Down:** `1700`
- Gateway EUI fills itself in — **copy it from this page, not from the
  label.** It is sixteen hex characters with no word shape to check it
  against, and a mistyped `5` for an `S` or `0` for `O` produces a gateway
  ChirpStack will never recognise, with no error anywhere to say why
- **Save & Apply**

Use Packet Forward, not Basics Station: it is the only path Seeed documents
for ChirpStack, it needs no TLS files, and you can prove it with `tcpdump`.

> **Then navigate away and come back to that page, and re-read the Server
> Address.** There is a reported firmware bug where a custom server address
> silently reverts to a TTN default after "Save & Apply" — the page counts
> down, reloads, and the field is blank again. If it reverts, that is the
> bug, not your typing. Re-enter it, and if it will not stick, say so and
> we will look at Basics Station instead.

### G4. The sub-band — the off-by-one that is not one

**`LoRa` → `Channel Plan`**: region United States 902–928 MHz, and select
**FSB 2**.

Wilson's ChirpStack stack is configured for the same thing under a
different name. Both of these mean **channels 8–15**:

| Where | What it is called |
|---|---|
| M2 console | **FSB 2** (1-indexed, the TTN convention) |
| Our ChirpStack config | **`us915_1`** (0-indexed) |
| Device profile dropdown | **"US915 (channels 8-15 + 65)"** |

They are the same sub-band. Nothing is off by one — the two vendors just
count from different places.

**Verified on Wilson's own unit (2026-09-08): a US915 SenseCAP M2
Multi-Platform ships set to `US902-928` / `FSB2, channel 8 ~ channel 15,
channel 65` out of the box** — which matches our ChirpStack `us915_1`
region exactly, channel 65 included. Seeed does not document this
anywhere, so it was worth reading rather than assuming; but on a factory
unit the expected action here is **change nothing**.

Read the page before touching it anyway. If a future unit ships different,
or somebody has been in here before you, this is the setting that makes
every other layer look perfect while no sensor ever joins.

If the gateway and the server disagree here, every layer below looks
perfect and no uplink ever arrives. It is the number one cause of "the
sensor won't join".

### G5. Prove the link three ways, with zero sensors

A gateway sends **status frames** on its own, every few seconds, whether or
not any device exists. That is your acceptance test.

**1. Packets are arriving at all** (on the pilot machine):

```bash
sudo tcpdump -i any -n udp port 1700
```

Traffic every few seconds means the M2 is reaching you. Silence means a
wrong IP, or a firewall eating **UDP** 1700 — check UDP specifically,
opening TCP 1700 does nothing.

**2. ChirpStack decoded them:**

```bash
cd tools/guardian-chirpstack
docker compose exec mosquitto mosquitto_sub -t '+/gateway/+/event/#' -v
```

Expect topic lines like `us915_1/gateway/<your-eui>/event/stats`. **The
payload will look like binary garbage — that is correct.** Gateway events
use ChirpStack's protobuf marshaler by default; device uplinks (the ones
that matter later) are JSON because our `chirpstack.toml` sets `json=true`
on the application integration. You are reading the **topic**, not the
payload: the gateway EUI appearing there is the proof.

**3. The console agrees:** ChirpStack → **Gateways** → your gateway's
**Last seen** stops saying "never seen" and starts advancing.

Three green lights here and the top half of the pipe is finished, days
early. Note that ChirpStack expects a stats frame roughly once a minute; if
it flags the gateway offline while `tcpdump` shows traffic, that threshold
is what to look at.

### G6. Pre-stage everything that does not need a sensor

Do all of this now, and sensor day is twenty minutes:

- **Create the application** (`wilson-guardian`).
- **Create the device profile** — US915, MAC 1.0.3, RP-A, class A, OTAA,
  region **"US915 (channels 8-15 + 65)"**.
- **Paste the codec** and prove it, without hardware:

  ```bash
  node _qa/fixtures/dragino/decode.js \
       _qa/fixtures/dragino/lht65n-chirpstack-4.0.js CBA40ABB025C010ADD0000
  ```

  Expect `TempC_DS` = **27.81** and `BatV` = **2.98**. Both numbers come
  from Dragino's own manual. Section 3a below explains why the file you
  pick matters more than anything else on this page.
- **Generate the admin token** for the install desk and put it somewhere
  you will find it: `openssl rand -hex 16`.
- **Decide the gateway's permanent home.** Where it sits decides your RF
  result, so put it where a customer's would live — a utility room or an
  office — and leave it there for the pre-qualification week.

### G7. Rehearse the whole product on invented data

Everything below the radio can run now, on the real broker, through the
real bridge, into the real server:

```bash
# terminal 1 — the server, in rehearsal mode
GUARDIAN_REHEARSAL=1 GUARDIAN_ADMIN_TOKEN=<your token> \
  node tools/guardian-pilot-server.js

# terminal 2 — the bridge, unchanged
node tools/guardian-lora-bridge.js

# terminal 3 — a fridge that stops cooling
node tools/guardian-fake-node.js --profile no_cool
```

Then open `guardian.html?feed=http://<pilot-machine>:8091` and watch the
alert arrive, dispatch it, complete it, and close it with a cause of
failure. **This is the week to put your office staff and your ten
technicians in front of it**, because the workflow they need to learn has
nothing to do with radios.

`--list` shows the other stories — a door left open, a slow sealed-system
decline, a multi-day defrost failure, a dying battery, and a patchy radio
that makes `/prequal.json` fail so you know what a failed pre-qual looks
like before one is deciding a hardware order. Load a week of history and
get your prompt back with `--backfill 7 --catch-up`; the analysis chart
then has something real-shaped to zoom around in.

Two things to hold onto:

- **`GUARDIAN_REHEARSAL=1` is not optional.** Without it the server refuses
  invented readings outright. With it, every data file moves into
  `rehearsal/` and every incident is stamped `rehearsal: true`. Synthetic
  readings in the real training file would sit beside genuine drill labels
  forever, and the labeled dataset is the one thing here that cannot be
  regenerated. **Delete `rehearsal/` before the real sensors arrive.**
- **No amount of this proves the radio.** It proves ChirpStack, MQTT, the
  bridge, the rules, the alerting, the office screens and the customer
  page. Whether a 915 MHz packet escapes a stainless column is still an
  open question, and the pre-qualification test at the bottom of this
  document is still the thing that answers it.

### The gateway phones home

Worth knowing given this project's "office LAN only" posture: even in
Packet Forward mode the M2 keeps sending status to Seeed's SenseCAP portal
roughly every five minutes. That is the gateway's own outbound traffic on
factory firmware, it carries no customer data, and it does not make the
pilot server reachable from outside. If your network is segmented and that
traffic is blocked, the gateway still works.

---

## Layer 0 — before you open anything

**Hardware ordered:** 1 × SenseCAP M2 Multi-Platform (US915, SKU 114992982),
3 × Dragino LHT65N-E3.

**Also needed, and easy to be caught without:**

- The **label on each LHT65N**. It carries `DevEUI`, `APPEUI` (also called
  JoinEUI) and `APPKEY`. Photograph all three labels before the sensors go
  anywhere. You cannot read them off a sensor that is already taped inside a
  column, and OTAA will not join without all three.
- The **activation magnet or pin** for the LHT65N (Dragino ships the node
  switched off; check the box).
- **Glycol vials** and a way to suspend the probe tip in the middle of the
  liquid, not touching the glass. Propylene glycol (food-safe) or the CDC
  vaccine-storage style buffer bottle. See "Probe placement" at the bottom —
  this is the single decision that determines whether your first month of
  alerts builds trust or destroys it.
- The **pilot machine**: anything that runs Docker and Node. It must sit on
  the shop LAN, on wired Ethernet if possible, and it must stay on.

**Two things to verify on the machine first, because both are silent
failures later:**

```bash
node --version        # any 18+ is fine; the pilot server has zero dependencies
docker compose version
```

**Security, unchanged from every other part of this project:** the pilot
server and ChirpStack bind the office LAN only. Never on public wifi, never
tunnelled to the internet, no port forwarding. Change ChirpStack's default
`admin/admin` and the API secret in
`tools/guardian-chirpstack/configuration/chirpstack/chirpstack.toml` **before
first start**.

---

## Layer 1 — the network server comes up

```bash
cd tools/guardian-chirpstack
docker compose up -d
docker compose ps
```

**Pass:** every service reads `running`. Then <http://127.0.0.1:8080> loads
the ChirpStack console and logs in.

**Fail — a container restarting in a loop:**

```bash
docker compose logs --tail=50 chirpstack
```

Almost always one of two things: the API secret was left as the placeholder,
or Postgres did not finish initialising before ChirpStack tried to migrate.
For the second, `docker compose restart chirpstack` is enough.

---

## Layer 2 — the gateway is talking to it

In the ChirpStack console: **Gateways → Add gateway**. The Gateway EUI is on
the M2's label. Region **US915**.

Then in the M2's own web interface, point its packet forwarder at the pilot
machine:

- Semtech UDP packet forwarder → `<pilot-machine-ip>` port **1700/udp**, or
- Basics Station → `ws://<pilot-machine-ip>:3001`

**The sub-band is the thing that goes wrong.** Wilson's stack is configured
for **US915 sub-band 2 (`us915_1`, channels 8–15)** — that is the Dragino
factory default and the usual M2 default, and it is why the compose file says
`us915_1` in three places. If the gateway and the server disagree about the
sub-band, everything below this line looks perfect and no uplink ever
arrives. Check it here, not later.

**Pass:** the gateway's row in the console shows a **Last seen** timestamp
that advances, and its Live LoRaWAN frames tab shows periodic stats frames.

**Fail — gateway never seen:**

```bash
docker compose logs --tail=50 chirpstack-gateway-bridge
```

- No traffic at all → the M2 cannot reach the machine. Wrong IP, or a
  firewall eating 1700/udp. Check from the M2's side, not the server's.
- Frames arriving but the console shows nothing → the Gateway EUI you typed
  does not match the one the M2 is sending. Copy it from the bridge log,
  which prints what actually arrived.

---

## Layer 3 — a sensor joins, and its payload decodes

### 3a. The device profile, and the file that matters

**Device profiles → Add.** Name it `Dragino LHT65N`, region **US915**, MAC
version **1.0.3**, regional parameters revision **A**, class A, OTAA.

Then, on the profile's **Codec** tab, choose *JavaScript functions* and paste
Dragino's decoder.

> **Use the right file.** Dragino's repo
> (`github.com/dragino/dragino-end-node-decoder`, folder `LHT65N/`) contains
> several decoders. Use one whose name says **Chirpstack 4.0** or
> **ChirpstackV4** — those define `decodeUplink`, which is what ChirpStack 4
> calls.
>
> The file named `LHT65N-chirpstack decoder.txt` is the ChirpStack **v3**
> codec. It defines `Decode()` and no `decodeUplink()`, so ChirpStack 4
> throws a ReferenceError and publishes the uplink **with no decoded object
> at all**. From the bridge's side that is indistinguishable from never
> having pasted a codec — which is why the bridge's skip message names both
> causes. This is the single most likely way to lose an evening on hardware
> day.
>
> Verified copies of all three files, and the difference between them, are in
> `_qa/fixtures/dragino/` with a README.

You can prove the codec is the right shape **before touching hardware**:

```bash
node _qa/fixtures/dragino/decode.js \
     _qa/fixtures/dragino/lht65n-chirpstack-4.0.js CBA40ABB025C010ADD0000
```

**Pass:** `{"object":{"BatV":2.98,...,"TempC_DS":27.81,...}}` — a `TempC_DS`
of 27.81 °C and a `BatV` of 2.98 V. Those two numbers are constants out of
Dragino's own manual.

Run it against `lht65n-chirpstack-v3.js` and you get the failure this section
is warning about, in the same shape ChirpStack produces it.

### 3b. Register the sensors

**Applications → Add** (call it `wilson-guardian`), then **Add device** per
sensor: DevEUI and JoinEUI from the label, the profile above, then paste the
**APPKEY** as the application key.

Activate each sensor (magnet/pin per Dragino's instructions) and watch the
device's **LoRaWAN frames** tab.

**Pass, in this order:** a `JoinRequest`, a `JoinAccept`, then `UnconfirmedDataUp`
frames. Switch to the **Events** tab and the `up` events show a decoded
object containing `TempC_SHT` and `TempC_DS`.

**Fail — join request, no join accept:** the AppKey is wrong, or the JoinEUI
does not match. Re-read the label; `0` and `O`, `8` and `B` are the usual
culprits.

**Fail — nothing at all:** back to layer 2's sub-band. A node on channels 0–7
talking to a gateway on 8–15 will never be heard.

**Fail — frames arrive, but the Events tab shows no `object`:** the codec.
See 3a. Also check the ChirpStack log stream for a codec error:

```bash
docker compose logs --tail=100 chirpstack | grep -i codec
```

**Fail — `TempC_DS` reads 327.67:** that is Dragino's documented "no external
probe attached" sentinel, not a temperature. The E3 cable is unplugged or
seated badly at the sensor. Fix it at the sensor; nothing downstream can
compensate for it.

---

## Layer 4 — MQTT is carrying the events

This is the layer people skip, and it is the cheapest one to check.

```bash
docker compose exec mosquitto \
  mosquitto_sub -h 127.0.0.1 -t 'application/+/device/+/event/up' -v
```

**Pass:** one JSON blob per uplink, roughly every 20 minutes. Note two things
in it that matter downstream:

- `deviceInfo.devEui` is **lowercase**. The ChirpStack *web UI* displays
  DevEUIs in upper case, which is why the pilot server matches channel ids
  case-insensitively — copy from the screen and it still works.
- `rxInfo[].rssi` and `rxInfo[].snr` are the numbers the RF
  pre-qualification test is about. Write down the first ones you see.

**Fail — silence here but events visible in the console:** you are subscribed
to the wrong topic. The application id is in the URL of the application page
in the console; substitute it for the first `+` if the wildcard is not
matching.

---

## Layer 5 — the bridge forwards to the pilot server

Two processes, two terminals. Start the pilot server **first** so the
bridge's first POST has somewhere to land.

The registry comes first. Copy the example and fill in one line per sensor —
`channelId` is the DevEUI (either case), `field7`, unit `C`:

```bash
cp tools/guardian-pilot-sensors.example.json guardian-pilot-sensors.json
$EDITOR guardian-pilot-sensors.json
```

```bash
# terminal 1
GUARDIAN_ADMIN_TOKEN="$(openssl rand -hex 16)" node tools/guardian-pilot-server.js
```

Keep that token — the office module's install panel needs it. Then:

```bash
# terminal 2
node tools/guardian-lora-bridge.js
```

**Pass:** the bridge logs `connected to mqtt://127.0.0.1:1883 — subscribing
application/+/device/+/event/up`, and then one line per uplink:

```
a84041ffff123456  2.61°C (probe)  bat 3.04V  rssi -104  snr 6.5  → pilot 200 SUCCESS
```

Four things to read in that line, because each one proves a different thing:
`(probe)` means the glycol probe was used rather than the sensor's internal
chip; `bat` proves battery telemetry is flowing; `rssi`/`snr` prove the
pre-qual data is being captured; `200 SUCCESS` proves the pilot server
accepted it.

**Fail — `skipped … no decoded object`:** layer 3a, the codec.

**Fail — `pilot server unreachable`:** the pilot server is not running, or
`GUARDIAN_PILOT_URL` points somewhere else. No reading is lost permanently —
the sensor's next uplink retries naturally.

**Fail — `400 ERROR` / `unknown channel`:** the DevEUI is not in
`guardian-pilot-sensors.json`. Case does not matter; a typo does. The server
prints a note at startup if it had to normalise any ids.

**Fail — `(internal)` instead of `(probe)`:** the external probe is not being
read. Either the E3 cable is unplugged (see the 327.67 note above) or this
sensor is not an -E3. The internal chip reads the air inside the sensor body,
not the glycol, so its numbers are not what the thresholds were written for —
fix this before the sensor goes in a customer's house.

---

## Layer 6 — the office sees it

```
http://<pilot-machine>:8091/
```

**Pass:** every sensor listed with a latest reading, a tier, and a
**Radio / battery** cell. Then the office module, served by that same
server so it is same-origin with its own feed:

```
http://<pilot-machine>:8091/guardian.html?feed=http://<pilot-machine>:8091
```

(Opening `guardian.html` as a file instead gives it a null origin, and the
browser may block its fetch — the page renders and then reports the feed
unreachable. Always reach it through the server.)

**Pass:** the badge reads `Live`, the fleet renders, each card shows its
sparkline and its RSSI/SNR/battery line.

**Fail — module says "Live feed unreachable":** the browser is on a different
machine than the server and the server is bound to `127.0.0.1`. Restart it
with `HOST=0.0.0.0` — office LAN only, still never the internet.

---

## Layer 7 — bind a sensor, and understand burn-in

In the module's **Install a sensor** panel: DevEUI, compartment, the label
the customer will read, and the household. Paste the admin token from layer 5.

A new household mints an access key and **shows it exactly once**. Send the
customer their charts link there and then; it is not recoverable afterwards.

Then the sensor enters **burn-in for 24 hours**. During burn-in it charts, it
is visible, and it does **not** alert, does not open a case, and does not
count as protecting anything — the customer's own page says *Getting settled*
rather than *Protected*.

This is deliberate and it is the moment that matters on an install:

> A sensor out of the box is at room temperature in a glycol vial that has
> not equilibrated. It will read over the fresh-food line, and the rules will
> be right to say so. **Watch the reading fall toward set point before you
> leave the house.** If it is not falling, the placement is wrong — and
> because burn-in suppresses the alert, a bad placement is silent. This is
> the only moment it is cheap to catch.

The card still shows what the rules *would* have said, under
"Suppressed while settling", so suppressing the page is never the same as
being blind.

Offline and Waiting still outrank burn-in: a sensor that joined and then went
quiet is a failed install, not a settling one, and it still alerts.

---

## The RF pre-qualification test — the go/no-go on a fleet order

**Do this before ordering hardware for customers.** It answers the one
question the whole product rests on: can a LoRa packet get out of a stainless
column reliably enough that Guardian catches what it promises to catch.

### Setup

One sensor, **one week**, inside the **worst** stainless column on the
showroom floor — worst meaning the most metal between the sensor and the
gateway. Put the **gateway roughly where a customer's would live** (a utility
room or an office, not three feet from the fridge). Probe in the glycol vial,
as it will be installed.

### The criteria, decided in advance

They live in `assets/plan-config.js` under `tempMonitoring.prequal`, so the
bar is written down before the result is known:

| Criterion | Bar | Why that number |
|---|---|---|
| **Longest radio gap** | **≤ 60 min** | Derived, not chosen. The shortest dispatch window in the product is fresh food — 45 °F sustained for 60 minutes. A gap longer than that can hide the exact event Guardian is sold to catch. **No tolerance on this one.** |
| **Delivery ratio** | **≥ 90 %** | Looser on purpose: every rule fires on *sustained* conditions, never a single reading, so scattered loss is survivable. Clustered loss is what the gap criterion catches instead. |
| **Duration** | **≥ 7 days** | A week covers defrost cycles, a weekend, and ordinary door traffic. |

Battery drift over the week is the fourth thing the test answers for free.
Cold plus a high spreading factor is where a ten-year cell claim goes to die.

### Reading the result

```bash
curl -s 'http://<pilot-machine>:8091/prequal.json' | python3 -m json.tool
```

`verdict` is one of:

- **`pass`** — all three criteria met. Order hardware.
- **`fail`** — a criterion is broken. Note that this can be true on day two;
  an hour of silence has already answered the question, and waiting five more
  days to say so wastes five days.
- **`running`** — clean so far, not yet a week. Keep going.
- **`no data`** — fewer than two readings. Something upstream is wrong; go
  back to layer 4.

Two fields to read carefully:

- `observedMedianIntervalMinutes` beside `criteria.expectedIntervalMinutes`,
  with `intervalMatchesConfig` saying whether they agree. The delivery ratio
  is only as good as that denominator: if the sensor's reporting interval
  (Dragino calls it TDC) is not the 20 minutes config assumes, the ratio is
  grading the config's guess rather than the radio. Change
  `expectedIntervalMinutes` to match reality, not the other way round.
- `gapsOverLimit` — *when* the gaps happened. Gaps clustered at the same time
  of day are usually something in the building (a door closed, a car parked,
  a microwave), and that is a placement or gateway-position problem, not a
  product problem.

The full week exports for a spreadsheet, temperature and radio and battery in
one file:

```bash
curl -s 'http://<pilot-machine>:8091/history.csv?channel=<deveui>' > prequal-week.csv
```

### If it fails

A fail is information, not a dead end. In rough order of cost: move the
gateway closer or higher; add a second gateway (the bridge already records
the best-hearing one, so a second gateway in a detached garage or a far wing
just works); reposition the sensor inside the column, away from the metal
back wall; then, only if none of that works, treat that class of column as
needing a repeater and price it accordingly. What must **not** happen is a
fleet order on a marginal result.

---

## Probe placement — the thing that determines whether alerts build trust

The thresholds in `plan-config.js` assume a **buffered probe**: the probe tip
suspended in glycol, so it reads like the *food* rather than the air.
`docs/GUARDIAN_THRESHOLDS.md` has both columns and the sources.

A bare probe in air reads the *door opening*. Every time someone stands in
front of the fridge deciding what to eat, you get an excursion. In week one
that is how a customer learns to ignore Guardian.

So, mechanically, during the pre-qual week:

- probe tip in the **middle** of the glycol, not touching the glass;
- the vial **secured** so it cannot tip when a shelf is rearranged;
- placed where it survives a customer pulling out the crisper;
- sensor body beside the vial, both inside the compartment (no wires leaving
  the box — that constraint is what put us on LoRa in the first place).

Get this settled on the showroom floor. It is a physical problem and no
amount of software fixes it.

---

## Failure signature quick reference

| What you see | Layer | Most likely cause |
|---|---|---|
| Container restart loop | 1 | API secret placeholder, or Postgres not ready |
| Gateway never "last seen" | 2 | Wrong IP, firewall on 1700/udp, or EUI mismatch |
| Gateway seen, no device frames | 2 | **Sub-band mismatch** (us915_1 / channels 8–15) |
| JoinRequest but no JoinAccept | 3 | Wrong AppKey or JoinEUI |
| Frames arrive, Events show no `object` | 3a | Codec missing, or the **v3** file pasted into a v4 profile |
| `TempC_DS` = 327.67 | 3 | E3 probe cable unplugged at the sensor |
| Nothing on `mosquitto_sub` | 4 | Wrong topic / application id |
| Bridge: `skipped … no decoded object` | 3a | Codec, again |
| Bridge: `pilot server unreachable` | 5 | Pilot server not running |
| Bridge: `400 ERROR unknown channel` | 5 | DevEUI not in the registry (a typo — case is fine) |
| Bridge logs `(internal)` not `(probe)` | 3 | Probe unplugged, or not an -E3 unit |
| Module: "Live feed unreachable" | 6 | Server bound to 127.0.0.1; use `HOST=0.0.0.0` |
| A new sensor reads BURNIN and never alerts | 7 | Working as designed, 24 h |
| Battery notice in the incident log | — | Cell at or below 2.6 V; order a replacement |

---

## What the QA suite already proves, so you do not have to test it by hand

Before the hardware arrived, `_qa/verify-lora-bridge.py` ran **Dragino's own
decoders** over known payload bytes and fed the real decoded objects through
the real bridge into the real pilot server. It asserts, among other things:
the probe field is `TempC_DS`; the 327.67 sentinel never reaches the rules;
negative freezer temperatures survive two's complement; `Ext=9` mode (which
omits `BatV` entirely) still lands; a v3 codec's empty result is skipped with
a message naming the fix; and an uppercase registry entry matches a lowercase
DevEUI.

`_qa/verify-pilot-server.py` proves burn-in suppression, the battery notice,
case-insensitive channel matching, and the pre-qual arithmetic.

So if a layer fails on hardware day, the odds strongly favour configuration
over code. Work the layers.
