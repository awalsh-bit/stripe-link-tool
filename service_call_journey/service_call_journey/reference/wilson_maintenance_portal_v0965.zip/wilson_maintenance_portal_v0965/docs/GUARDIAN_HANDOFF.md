# Wilson Refrigeration Guardian — Handoff for Dashboard Integration

**From:** Cayden Mayfield, Wilson AC & Appliance
**Module:** 24/7 refrigeration temperature monitoring for the dashboard
**Main files:** `guardian.html` (office) and `guardian-customer.html`
(customer-facing) — both beside this doc
**Backend:** `tools/` folder (beside this doc) — runs on Wilson's shop machine

## What it is

One self-contained HTML/CSS/JS page — same integration shape as Jack's
Filter Finder. It renders the Guardian monitoring surface: every enrolled
sensor with its 48-hour temperature chart and alert tier, plus the
**required alert close-out pipeline** (more below). No framework, no build
step, no external requests except the optional live feed you point it at.

Open it with no arguments and it runs on three simulated sensors so you can
see every state (including a dispatch) without any backend. Open it as
`guardian.html?feed=http://<shop-machine>:8091` and it renders the REAL
sensor fleet from the ingest server, polling every 60 seconds.

## How to integrate it

Same options as Filter Finder, and option 2 is again the recommendation:

1. **Iframe embed.** Fine as a stopgap.
2. **Drop the file in as a page/route.** It's one static file. Every CSS
   class is `gm-` prefixed and the page paints its own background, so it
   won't fight the dashboard's stylesheet. The fonts fall back to
   system-ui if the dashboard doesn't load Poppins/Inter.
3. **Rebuild natively.** If you do, the part to carry over faithfully is
   the RULES, not the UI — see "the one implementation" below.

## File map (`guardian.html`)

| Section | What's there |
|---|---|
| `<style>` | gm-prefixed styles, sage/white/green language matching the dashboard |
| inlined `plan-config.js` | ALL product configuration. The parts Guardian uses: `WILSON_CONFIG.tempMonitoring` — flag rules (thresholds), compartments, approved pricing tiers, and `failureCauses` (the close-out taxonomy) |
| inlined `temp-monitoring.js` | the evaluation engine: `evaluateFlags` (warn/dispatch/recovery logic), `summarize`, series simulation for demo mode |
| inlined `guardian-module.js` | this page: fleet rendering, the close-out pipeline, live-feed polling, the storage adapter seam |

## The one implementation (please keep this true)

`guardian.html` is **generated** from the Wilson maintenance-portal repo by
`tools/build_guardian_module.py`, which inlines the same `plan-config.js`
and `temp-monitoring.js` the rest of the project runs. When thresholds or
pricing change, Cayden sends a rebuilt `guardian.html` — please replace the
whole file rather than patching rules inside it, or the dashboard's
thresholds will silently drift from the ones the ingest server alerts on.
(The file's header comment says the same thing.)

## The alert close-out pipeline (business rule, not UI sugar)

A dispatch-tier sensor automatically opens a case (one per sensor per day).
A case moves **open → service call logged → service complete → closed**,
in that order only, and closing REQUIRES picking the cause of failure from
the fixed list in `WILSON_CONFIG.tempMonitoring.failureCauses`. Free text
is not a cause. This is deliberate: every closed case pairs the alert data
with a verified diagnosis, and that pairing is a dataset Wilson is
building. Don't add a "dismiss" button.

## The Dispatch button → your service request queue (please wire this one)

Cayden's requirement, verbatim: "an admin on the back end hitting this
button would move the call over from guardian directly into our existing
service request queue that already lives on the dashboard and is regularly
monitored and worked."

Every open alert renders a primary **Dispatch service tech** button. It
calls a hook the dashboard defines before the page's scripts run:

```js
window.WILSON_GUARDIAN_DISPATCH = async function (request) {
  const sr = await dashboard.createServiceRequest({
    title: request.summary,              // "Sub-Zero BI-48S — Fresh food above 45°F for an hour"
    priority: "urgent",                  // request.priority === "guardian-dispatch"
    customerRef: request.sensor.detail,  // map to your customer record
    notes: request.notes,
    source: "Guardian",
    externalId: request.caseId
  });
  return { ok: true, ref: sr.number };   // or just the ref string
};
```

The request object: `{ source: "wilson-guardian", caseId, priority,
summary, sensor: {id, label, detail, kind}, readingF, alertAt,
requestedAt, notes }`. Return `{ok:true, ref}` (or a Promise of it, or the
ref string alone); return `{ok:false, message}` to keep the alert open
with your message shown to the admin.

On success the case advances to "In the service request queue · <ref>" —
and the REQUIRED close-out still applies: after your queue works the call,
someone marks it Service complete in Guardian and records the cause of
failure. Dispatching replaces the "log a call" step, never the close-out.
With the hook undefined, the button still advances the case under a
generated `GRD-` reference and tells the admin the queue is not wired yet
— so nothing in the demo dead-ends, and integration is one function.

## Data model / persistence seam

Case state persists to `localStorage` key `wilson-guardian-module-v1` by
default — fine for evaluation, wrong for production. To wire the
dashboard's real database, define before the page's scripts run:

```js
window.WILSON_GUARDIAN_ADAPTER = {
  load: function ()      { /* return the stored state object or null */ },
  save: function (state) { /* persist it; state is plain JSON */ }
};
```

The state shape is `{ cases: [ { id, key, sensorId, label, flagLabel,
reading, createdAt, status, serviceOrderRef?, scheduledAt?, servicedAt?,
cause?, causeLabel?, signatureMode?, causeNotes?, closedAt? } ] }`.
`window.WILSON_GUARDIAN.render()` re-renders after async hydration.

## The customer view (`guardian-customer.html`)

The second file is the public-facing half: a customer opens it on Wilson's
site and sees THEIR refrigeration — current temps, 48-hour charts, a
plain-language status — nothing else. Same drop-in shape, same generated
single file, same engine inlined.

**How access works.** There are no accounts. Each Guardian customer gets a
long random key (`openssl rand -hex 24`), stored only in the ingest
server's sensor registry with the channels it may see. The page takes the
key from a `?key=...` link Wilson sends ("bookmark this"), from a paste-in
field, or from the browser's memory of a prior visit. The ingest server
answers `GET /customer.json?key=...` with that household's sensors in
customer-facing shape — and answers every wrong key with an identical bare
404 (nothing to enumerate). The customer payload carries readings and
plain-language status ONLY: no internal alert vocabulary, no thresholds
tables, no incident log, no sign other households exist. Please keep it
that way if you touch the rendering.

`?key=demo` renders a simulated household with no backend, for your
integration work and the showroom floor. On deploy, set
`GUARDIAN_FEED_URL` at the top of the page's last script block to the
Guardian server's public URL (until then, `?feed=` works for testing).
Note the pilot server binds to the office LAN — the customer page can only
go truly public once ingest is hosted somewhere reachable; the page and
the endpoint are ready for that day.

## The analysis surface (v1.5) — and how to extend the data side

The office module carries a fold-away **Analyze temperature history**
panel: pick a sensor, pick a window (6h / 24h / 48h / 7d / 30d / all),
drag across the plot to zoom into a span, wheel to zoom around the
pointer, shift-drag or ◀ ▶ to pan, and move the cursor to read any
moment exactly (temperature, timestamp, distance from set point, and
standing against that band's warn/dispatch lines). Keyboard reaches the
same readings: ← → step, Home/End jump, Esc resets. There is a table view
and a CSV of the raw window, because a value must never be reachable only
by hovering.

**Two invariants worth preserving if you touch this:**

1. **Statistics describe FULL resolution, never the drawn line.** The
   server thins points for drawing, but each bucket contributes its own
   minimum and maximum, and the summary is computed over every reading.
   So the peak on the stat strip is the true peak at any zoom level. A
   chart that reports a different maximum when you zoom out is a chart
   that loses alerts.
2. **Thresholds are never redefined in the chart.** Every line drawn and
   every judgement printed comes from the band's rule in config.

**The data side is the extension point.** The ingest server gained an
append-only history archive (`guardian-pilot-history.jsonl`) and two
endpoints the panel reads:

- `GET /history.json?channel=&from=&to=&maxPoints=` → `{label, kind,
  rule, from, to, rawCount, downsampled, points:[{t,f}], stats}`. Times
  accept ISO or epoch ms; the window defaults to 48 hours.
- `GET /history.csv?channel=&from=&to=` → the same window at full
  resolution, as a download.

At pilot volume a JSONL file with an in-memory index is the right
storage — nothing to install on a shop machine. When volume outgrows it,
**replace the storage, not the contract**: keep those two endpoints and
the panel, the stats, and anything else built on them keep working. That
is why the range/thinning/summary logic lives behind the endpoint rather
than inside the page.

## The install desk (v1.4)

The office module's fold-away **Install a sensor** panel is how a sensor
gets bound to a compartment, a label, and a household at install time. In
live mode it drives two token-gated endpoints on the ingest server:

- `GET /admin/customers` — household picker (ids and names, NEVER keys)
- `POST /admin/install` — `{channelId (the DevEUI), kind, label,
  householdId | householdName, contactEmail?, contactPhone?}` — upserts
  the sensor, binds it to the household, and for a NEW household mints its
  access key server-side and returns it in that response ONLY. The panel
  displays it once with the customer's charts link; it is never
  retrievable again (re-issue by editing the registry if lost). A sensor
  already bound to a different household is refused with a 409.

Auth is one shared secret: set `GUARDIAN_ADMIN_TOKEN` in the server's
environment (endpoints are OFF without it); requests carry it in the
`x-guardian-admin` header. The panel remembers the token in the browser.
Demo mode registers a simulated sensor locally so the flow can be walked
with no backend.

## Burn-in: the fourth tier (v1.6) — please do not "fix" it

A sensor bound through the install desk carries an `installedAt`, and for
the window in `plan-config.js` → `tempMonitoring.commissioning.hours`
(currently 24) it reads tier **`burnin`**. Everything about it is
deliberate, and a reasonable person would otherwise read it as a bug:

- it charts and it is visible, so an installer can watch the reading fall
  toward set point before leaving the house;
- it does **not** alert, does **not** open an alert case, and does **not**
  count as protecting anything;
- the customer's own page says *Getting settled*, never *Protected*;
- the office card still shows what the rules WOULD have said
  (`underlyingTier`), because suppressing a page is not the same as being
  blind.

Why: a sensor out of the box is at room temperature in a glycol vial that
has not equilibrated. It will read over the fresh-food line and the rules
will be right to say so — and if that pages the office at 2am on the night
of an install, the first thing Guardian ever does is cry wolf.

Two exceptions, both because they are not false alarms: **OFFLINE and
WAITING still outrank burn-in.** A sensor that joined and then went silent
is a failed install, and a failed install that stays quiet for a day is a
customer paying for nothing.

If you implement your own persistence or your own status mapping, the rules
that must survive: `burnin` never opens a case; `settling` is never toned
as OK on a customer surface; a sensor with **no** `installedAt` (a fleet
that predates the install desk) is never treated as burning in. All three
are asserted in `_qa/verify-guardian-module.js` and
`_qa/verify-pilot-server.py`.

The window is one number in config. Changing it is a config change, not a
code change.

## Sensor health: battery and radio (v1.6)

`/status.json` rows now carry two extra objects when the feed knows them:

```
battery: { known, level: "ok"|"replace"|"critical"|"unknown", volts, note }
radio:   { rssi, snr, dr, at }
```

Battery levels come from `tempMonitoring.battery` in config (Dragino's own
numbers: replace at 2.6 V, minimum working voltage 2.5 V). A low cell logs
an incident with `tier: "battery"` and pings the office webhook **once per
level crossing** — and never notifies the customer. That is a deliberate
line: a battery is Wilson's errand, not the customer's alarm.

A flat cell is an offline sensor with an explanation, and the difference
between those two sentences is a truck roll.

## Customer alerting (v1.4)

On a DISPATCH or OFFLINE transition for a channel bound to a household —
and on the all-clear when it recovers — the ingest server writes a
customer-voiced message (subject + text, no internal vocabulary) to its
notification outbox (`guardian-pilot-notifications.jsonl`) and, when
`CUSTOMER_ALERT_WEBHOOK_URL` is set, POSTs the same JSON there:
`{at, customerId, name, to: {email?, phone?}, tier, sensorLabel, subject,
text}`. Point that webhook at the real sender (the dashboard's mailer,
SendGrid, Twilio) and customer alerting is live — the trigger, the copy,
and the once-per-transition dedupe are already proven by QA. WARN never
notifies a customer by design: warns are the office watching closely, and
a customer paged for every warm-up learns to ignore the page that
matters.

## Phones: home screen and widgets

Three rungs, two of which ship in this package:

1. **Installable page (ships now).** `guardian-customer.html` carries
   standalone-app metas and relative links to
   `guardian-customer.webmanifest` + `guardian-icon-*.png` — those files
   are in `tools/guardian-pwa/`; deploy them BESIDE the page (links fail
   soft if you don't). "Add to Home Screen" then installs it like an app:
   Wilson icon, no browser chrome, opens straight to the charts with the
   key remembered. The page shows customers a one-line hint about this,
   and hides it once it detects it is running installed. Swap the
   placeholder icons for the real brand asset when you have it.
2. **True live widget, no app store (ships now, concierge setup).**
   `tools/guardian-widget-scriptable.js` renders a real iOS home-screen
   widget through the free Scriptable app: per-compartment temps with
   status dots, refreshed on iOS's widget schedule, tapping opens the
   charts page. Setup is two minutes on the customer's phone (paste
   script, fill in their key and the feed URL) — instructions are in the
   file header. Wilson's technician does this at install; it is a
   concierge move, not a mass-distribution channel. No Android
   equivalent ships; Android customers get rung 1.
3. **Native app (later, at fleet scale).** Real WidgetKit/App-Widget
   widgets and — more valuable — push notifications ("your freezer is
   warming") need a native app. When Guardian's subscriber count
   justifies it, `/customer.json` is already the API that app consumes.

## The backend (in `tools/`, runs at Wilson)

- `guardian-pilot-server.js` — the ingest/alerting server (Node, zero
  dependencies). Receives sensor readings, judges them with the same rules
  this page displays, logs incidents, serves `/status.json` — which is the
  live feed this page polls (CORS enabled for that; the server itself
  binds the office LAN only and must never be exposed to the internet).
- `guardian-chirpstack/` — Docker compose stack: the private LoRaWAN
  server the physical sensors report through.
- `guardian-lora-bridge.js` — pipes ChirpStack uplinks into the ingest
  server, forwarding battery voltage and RSSI/SNR alongside each reading.
- `guardian-pilot-sensors.example.json` — sensor registry template.

Two endpoints added in v1.6, both office-side:

- `GET /prequal.json[?channel=&from=&to=]` — the RF pre-qualification
  report: packet delivery ratio, longest radio gap, RSSI/SNR spread and
  battery drift, each graded against criteria that live in
  `tempMonitoring.prequal`. This is the go/no-go instrument for a fleet
  hardware order, not a dashboard widget.
- `GET /history.csv` now carries `battery_v,rssi,snr` columns beside the
  temperature, so one export is the whole instrument.

Channel ids are matched **case-insensitively**. ChirpStack's JSON reports
DevEUIs in lowercase while its web UI displays them uppercase, and a
hand-copied registry entry that silently matched nothing was worth
preventing structurally.

`docs/GUARDIAN_BRINGUP.md` is the layer-by-layer bring-up runbook for the
physical hardware — useful context for why the seams are where they are,
though it is Wilson-side, not dashboard-side.

These stay on Wilson's machine for the pilot. If ingest later moves to
dashboard infrastructure, the pilot server is the reference
implementation — it and this page already share one rules engine.

## Testing your integration without waiting for a fridge (v1.7)

You will need a feed that dispatches on demand to build the service-request
hook against, and waiting for a real refrigerator to fail is a poor
development loop. `tools/guardian-fake-node.js` is that feed:

```bash
# terminal 1 — the ingest server, in rehearsal mode
GUARDIAN_REHEARSAL=1 GUARDIAN_ADMIN_TOKEN=dev node tools/guardian-pilot-server.js
# terminal 2 — a fridge that stops cooling
node tools/guardian-fake-node.js --profile no_cool --via http
```

Then point the module at it (`?feed=http://127.0.0.1:8091`) and a dispatch
arrives within a minute or two. `--list` shows the other stories: a door
blip that must NOT dispatch, a slow sealed-system decline, a dying battery,
a patchy radio. `--backfill 7 --catch-up` loads a week of history so the
analysis panel has something to zoom around in. No Docker needed on the
`--via http` path.

Two things to know:

- The server refuses invented readings unless `GUARDIAN_REHEARSAL=1`, and
  in that mode it sandboxes its data files and stamps every incident
  `rehearsal: true`. `/status.json` carries a top-level `rehearsal` boolean
  — **if you surface a "demo/live" indicator anywhere, read that field.**
- Everything the rig emits is invented. It is a development and training
  tool, never a data source.

## Sizing / behavior notes

- ~320 KB single file, no external requests (Poppins/Inter are optional
  niceties, not loads — the stacks fall back to system fonts).
- Renders fine standalone on mobile widths; the fleet grid collapses to
  one column.
- The live feed URL can also be baked in: `GUARDIAN_FEED_URL` at the top
  of the module script (last `<script>` block).

## Questions

Business rules, thresholds, pricing, the cause taxonomy: Cayden
(cmayfield@wilsonappliance.com). Those come from the maintenance-portal
project and its QA suites — treat them as spec, not as suggestions.
