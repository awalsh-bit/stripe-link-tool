# The Guardian pilot machine — build it once, step by step

**Do you actually need a dedicated computer? No. Should you have one? Yes.**

ChirpStack plus the ingest server is small — a few hundred MB of RAM and
almost no CPU. It would run fine alongside other things. The argument for
its own box is not capacity, it is this:

> **This machine is the single point of failure for the entire fleet.** If
> a *customer* loses power, their gateway dies, their sensors go quiet, and
> this server flags OFFLINE after three hours — that works, and it is a
> real alert. If *this machine* goes down, every customer goes dark at
> once and **nobody gets an alert at all**, because the thing that raises
> alerts is the thing that is off. The failure is silent, and it looks
> exactly like "everything is fine."

A box that is only ever Guardian can be rebooted, wiped and rebuilt on its
own schedule, by whoever is holding the problem, at 9pm, without asking
anyone whether accounting is in the middle of something. That is worth two
hundred dollars.

It is also the machine that carries this to production, so buying it now
means never migrating later.

---

## Part 1 — What to buy

**A small fanless mini PC.** Target spec, and none of it is demanding:

| | |
|---|---|
| CPU | Intel N100 / N150 (or any recent low-power x86) |
| RAM | 16 GB (8 GB works; 16 GB costs almost nothing and ends the question) |
| Storage | 256–500 GB **SSD or NVMe** |
| Network | **Gigabit Ethernet** — wired, always |
| Price | roughly $150–250 |

**Why x86 rather than a Raspberry Pi:** a Pi 5 with a real SSD does work,
and ChirpStack publishes ARM images. But on x86 every container and every
tool just runs, with no architecture footnotes, and the price difference is
about forty dollars. Spend it and never think about it again.

**Not on an SD card.** If you do use a Pi, it needs an SSD. This machine
writes an append-only history file continuously, forever; SD cards die of
exactly that.

**One thing that is not optional: it goes on the UPS**, along with the
switch it plugs into and the gateway. That is the whole point of the
paragraph at the top.

---

## Part 2 — Install the operating system

**Ubuntu Server 24.04 LTS.** Not the desktop edition — this box has no
monitor once it is running.

1. Download Ubuntu Server 24.04 LTS from ubuntu.com.
2. Write it to a USB stick with [Rufus](https://rufus.ie) (Windows) or
   Balena Etcher.
3. Boot the mini PC from the USB (usually F7, F11 or Del at power-on).
4. Work through the installer. The choices that matter:
   - **Keep the default "Ubuntu Server" (not minimized)** install.
   - **Install OpenSSH server: YES.** This is how you administer it after
     the monitor comes off.
   - Username: something like `wilson`. Set a real password.
   - Everything else: defaults are correct.
5. Reboot, pull the USB, and from your desk: `ssh wilson@<its-ip>`

From here on, everything is typed over SSH.

### Give it a fixed address

**Do this before anything else.** The gateway is going to be configured to
send packets to this machine's IP. If DHCP hands it a different address
next month, every sensor goes quiet and the reason will not be obvious.

Two ways, either is fine:

- **DHCP reservation on your router** (usually easier, and keeps all your
  addressing in one place): find this machine's MAC and pin it to an
  address.
- **Static on the machine itself:** edit `/etc/netplan/50-cloud-init.yaml`,
  then `sudo netplan apply`.

Write the address down in `docs/PILOT_FACTS.md`. Everything downstream
points at it.

---

## Part 3 — Install what it needs

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y nodejs docker.io docker-compose-v2 tcpdump mosquitto-clients unzip
node --version        # must be 18 or newer
docker --version
```

`tcpdump` and `mosquitto-clients` are not decoration — they are the two
tools the bring-up runbook uses to prove the gateway link, and installing
them now saves fumbling later.

### Unattended security updates

```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
```

This box sits on your LAN for years. Let it patch itself.

---

## Part 4 — Lay the files down

Create a service account that owns the software and the data, and nothing
else on the machine:

```bash
sudo useradd --system --create-home --home-dir /opt/guardian --shell /usr/sbin/nologin guardian
```

Copy the release across from your workstation (run this **on your
workstation**, not on the pilot machine):

```bash
scp wilson_maintenance_portal_v0963.zip wilson@<pilot-ip>:/tmp/
```

Then back on the pilot machine:

```bash
cd /tmp && unzip wilson_maintenance_portal_v0963.zip
sudo cp -r wilson_maintenance_portal_v0963/. /opt/guardian/
sudo chown -R guardian:guardian /opt/guardian
```

Add yourself to the `guardian` group so you can read its files without
`sudo` every time (log out and back in for it to take effect):

```bash
sudo usermod -aG guardian $USER
```

### The sensor registry

```bash
sudo -u guardian cp /opt/guardian/tools/guardian-pilot-sensors.example.json \
                    /opt/guardian/guardian-pilot-sensors.json
```

Leave it as the example for now — once the sensors arrive, the install desk
writes to it for you and you should not be hand-editing it.

> **This file becomes the most valuable thing on the machine.** Every
> customer's access key lives in it and nowhere else, because the install
> desk shows each key exactly once. Part 7 backs it up; do not skip Part 7.

---

## Part 5 — The environment file

Every credential lives here, on this machine, in one root-owned file. None
of it goes in the repository — that rule has held for every secret in this
project and it holds here.

```bash
sudo install -d -m 750 /etc/guardian
sudo cp /opt/guardian/tools/systemd/guardian.env.example /etc/guardian/guardian.env
sudo chown root:guardian /etc/guardian/guardian.env
sudo chmod 640 /etc/guardian/guardian.env
openssl rand -hex 16          # copy this
sudo nano /etc/guardian/guardian.env
```

Set at minimum:

- `HOST=0.0.0.0` — reachable from other machines on the shop LAN, which is
  what you want, since the office opens the module on a different computer
- `GUARDIAN_ADMIN_TOKEN=` — paste the string you just generated. Also put
  it in your password manager; the install panel asks for it.

Leave the two webhook URLs blank for now. Customer alerts still get written
to the outbox file, so you can read exactly what a customer *would* have
been sent, without sending it. Fill them in when you are ready to notify
people for real.

---

## Part 6 — Start everything, permanently

### ChirpStack

```bash
cd /opt/guardian/tools/guardian-chirpstack
sudo nano configuration/chirpstack/chirpstack.toml     # change the api secret
sudo docker compose up -d
sudo docker compose ps        # every service should read "running"
```

Then open `http://<pilot-ip>:8080`, log in as `admin`/`admin`, **and change
that password immediately.**

Docker's own restart policy (`restart: unless-stopped`) brings the stack
back after a reboot; nothing further is needed.

### The Guardian services

```bash
sudo cp /opt/guardian/tools/systemd/*.service /etc/systemd/system/
sudo cp /opt/guardian/tools/systemd/*.timer   /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now guardian-pilot-server guardian-lora-bridge
sudo systemctl enable --now guardian-backup.timer
```

Check them:

```bash
systemctl status guardian-pilot-server guardian-lora-bridge
journalctl -u guardian-pilot-server -f        # live log; Ctrl-C to stop
```

**Then reboot the machine and check again.** This is the step people skip,
and it is the whole reason the units exist:

```bash
sudo reboot
# wait a minute, then from your desk:
curl -s http://<pilot-ip>:8091/status.json | head -c 200
```

If that answers after a cold boot with nobody logged in, the pilot is real.
A monitoring system that needs someone to start it is not one.

### Where things now live

| | |
|---|---|
| ChirpStack console | `http://<pilot-ip>:8080` |
| Pilot server + status page | `http://<pilot-ip>:8091` |
| Office module | `http://<pilot-ip>:8091/guardian.html?feed=http://<pilot-ip>:8091` |
| Customer page (test) | `http://<pilot-ip>:8091/guardian-customer.html?key=demo` |

Bookmark the office module URL on every machine in the office.

Note both pages come from the **pilot server itself**, on the same port as
the feed. That is deliberate: opened as a `file://` page instead, the
module has a null origin and the browser may block its own fetch, so it
renders and then sits there claiming the feed is unreachable — a browser
rule that looks exactly like a broken product. Same origin, no question.

---

## Part 7 — Backups (do not skip this)

The timer is already enabled above. Prove it works, now, rather than
discovering in six months that it never ran:

```bash
sudo systemctl start guardian-backup.service
journalctl -u guardian-backup --no-pager | tail -20
ls -l /opt/guardian/backups/
```

**What is in that archive, and why it matters more than it looks:**

- **The sensor registry** — every customer's access key, and each one was
  shown exactly once at install. Lose this and every customer's link stops
  working with no way to recover the old keys: you would re-issue every one
  and phone every household.
- **The labeled failure-drill dataset** — every hour a technician spent
  inducing a fault in a showroom fridge. Not reconstructable from anything.
- **The full reading history** — everything the analysis view, the
  pre-qualification report and the report trends are drawn from.

**Get a copy off the machine.** A backup that lives only on the box it is
backing up is not a backup. A nightly copy to the NAS, or a USB drive
someone swaps weekly, both work:

```bash
sudo -u guardian /opt/guardian/tools/guardian-backup.sh /mnt/nas/guardian
```

That archive contains customer keys and the trade-secret dataset. Keep it
in-house, off any public share, out of any repository or zip. It is written
mode 600 for that reason.

---

## Part 8 — The security posture, unchanged

This has been the rule since the first version of this project and nothing
here relaxes it:

- **Shop LAN only.** No port forwarding, no reverse tunnel, no
  "temporarily" exposing 8091 so someone can check it from home. Everything
  on this machine is customer data.
- **Credentials in `/etc/guardian/guardian.env` and the password manager**,
  never in the repository, never in a chat, never in a photograph.
- A firewall is optional on a trusted LAN, but if you want one:

  ```bash
  sudo ufw allow from 192.168.0.0/16 to any port 22,1700,8080,8091,8092 proto any
  sudo ufw --force enable
  ```

  Adjust the subnet to your own. Note **1700 is UDP** — that is the
  gateway's packet forwarder, and it is the one people forget.

If you later need this reachable from outside the building, the answer is a
VPN into the shop network, not an open port. Ask me and we will do it
properly.

---

## Part 9 — What comes next

The machine is now the thing the rest of the project talks to.

1. **`docs/GUARDIAN_BRINGUP.md`, section "Gateway day"** — point the M2 at
   this machine's IP on UDP 1700, set the sub-band, and prove the link
   three ways. That is the next hour's work.
2. **Rehearse the office workflow** while the sensors are in transit. Do
   this on a *different* machine — your laptop is ideal — because rehearsal
   mode accepts invented readings, and invented readings must never touch
   this box's archive:

   ```bash
   GUARDIAN_REHEARSAL=1 node tools/guardian-pilot-server.js
   node tools/guardian-fake-node.js --profile no_cool --via http
   ```

3. **When the sensors arrive**, work the rest of the bring-up runbook, then
   start the RF pre-qualification week.

---

## If something is wrong

| Symptom | Look here |
|---|---|
| A service will not start | `journalctl -u guardian-pilot-server -n 50` |
| It starts then dies in a loop | Usually the registry file or `/etc/guardian/guardian.env` — check ownership is `guardian` |
| `status.json` unreachable from another machine | `HOST=0.0.0.0` not set in the env file, or a firewall |
| Office module says the feed is unreachable | You opened `guardian.html` as a file instead of from `http://<pilot-ip>:8091/guardian.html` |
| ChirpStack container restart loop | `sudo docker compose logs --tail=50 chirpstack` — usually the API secret placeholder |
| Gateway "never seen" | Runbook layer 2. Check **UDP** 1700 specifically |

Record the addresses, the EUI and the install dates in
`docs/PILOT_FACTS.md` as you go. In three months you will not remember any
of it, and that file is the difference between a five-minute answer and an
afternoon.
