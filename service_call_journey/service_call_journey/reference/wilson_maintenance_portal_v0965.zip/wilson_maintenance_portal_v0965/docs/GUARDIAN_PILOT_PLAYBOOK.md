# Guardian pilot playbook — test the waters before the $5k (v0.9.62)

> **Hardware day:** work **`docs/GUARDIAN_BRINGUP.md`** instead of this
> file. It is the layer-by-layer bring-up sequence — gateway, ChirpStack,
> MQTT, bridge, pilot server, office module — with the exact command,
> expected output and failure fix at each step, plus the RF
> pre-qualification test that gates any fleet order. This playbook remains
> the *drill* protocol: what to break, once the pipe is proven.

Cayden: "Should we start on a more base version of ubibot to test the waters?
I'd like to deploy a few test sensors and force a few failures to see how
everything reacts and if our thresholds catch the fails."

Yes — the pilot runs on UbiBot's FREE public-cloud tier plus the $1/device/
month data-forwarding add-on. Three sensors ≈ **$3/month**. The $5,000
Developer Membership is a post-pilot purchase, made only after this playbook's
drills pass. Every drill below has already been run SYNTHETICALLY against the
pilot server (`_qa/verify-pilot-server.py`, 19 checks green) — the physical
pilot confirms the same behavior with real hardware, real WiFi, and real
compressors.

## THE PLACEMENT RULE (v0.9.52, Cayden): no wires into the cabinet

"i cant have wires running into these fridges from the outside." That kills
the classic layout (sensor body outside, probe cable through the door
gasket) for Wilson's fleet — showroom columns and customer built-ins alike.
Everything must live INSIDE the compartment, which changes the hardware
call:

- **WiFi from inside a fridge is the wrong bet.** The WS1/WS1 Pro are
  2.4GHz only, spec'd to −20°C (a 0°F freezer is −17.8°C — edge of spec, on
  alkalines, unsupported placement, condensing environment), and a
  Sub-Zero/Thermador stainless column is the closest thing to a Faraday
  cage in the category. Every consumer product built for in-fridge use
  (YoLink, Govee, MOCREO) uses sub-GHz radio inside + a gateway outside —
  none of them try WiFi from inside. Neither should Wilson.
- **LoRaWAN is the in-cabinet answer**: 915MHz penetrates the cavity far
  better, cold-chain deployments put nodes directly inside medical fridges,
  and the sensors are rated −40°C with multi-year batteries.

## Shopping list (~$430 for a 3-compartment LoRa pilot, all in-cabinet)

| Item | Qty | ~Cost | Note |
|---|---|---|---|
| Dragino LHT65N-US915 | 3 | ~$45 ea | −40~80°C device rating, built-in 2400mAh lithium (multi-year), lives fully inside the compartment |
| E3 external DS18B20 probe for LHT65N | 1–3 | ~$5 ea | Probe tip in the glycol vial, sensor body beside it — all inside, no wall crossing |
| Dragino LPS8v2 gateway (US915) | 1 | ~$220 | Sits in the showroom; built-in ChirpStack V4 + MQTT — readings go to OUR server, no cloud dependency |
| Glycol vials (60 ml HDPE + PG USP 60:40) | 3–6 | ~$25 total | The buffer IS the false-alarm filter |
| Pre-qualification sensor: 1× YoLink temp sensor + hub, or just the $45 LHT65N first | 1 | ~$22–80 | One week inside the WORST showroom column before buying the fleet — the only real answer to "does RF get out of a Sub-Zero" |

### Where to buy (verified Sep 2026)

Dragino has NO first-party big-distributor channel in the US: Mouser,
Arrow and Newark do not carry them, and the Digi-Key listings are
"Marketplace" fronts for small resellers (Choovio). The legit-feeling
paths, in order:

- **Amazon US** (third-party sellers, A-to-Z buyer protection): LPS8v2
  gateway (ASIN B0CQQX2WFL), LHT65N-E3 bundle (sensor + flat probe,
  e.g. ASIN B0FVXRC5XC), LHT65N 915MHz (B0BL7X7X6C). Right choice for
  the one-sensor RF test and the pilot.
- **Dragino direct** (shop.dragino.com, Shenzhen): fine for the fleet
  order, and the OEM/enclosure-branding conversation happens there
  anyway. Confirm LHT65N/LPS8v2 availability with sales first.
- **US-manufacturer alternates** if the vendor footing matters more
  than the architecture: Monnit (Salt Lake City; first-party at
  Digi-Key/Mouser, ~$112/sensor + $242 gateway + $45/yr API tier — but
  proprietary radio, cloud-first data path, and their fridge design is
  probe-through-the-gasket, which the placement rule forbids) and
  MultiTech/Radio Bridge (Minnesota; standard LoRaWAN sensors ~$60–90
  at Digi-Key/Arrow, gateways $400+ — the strongest fleet-scale pivot).
- **DO NOT order from calchipconnect.com** — the former distributor's
  domain is serving spam content as of Sep 2026 (hijacked or lapsed).

The UbiBot path stays documented below for reference — it remains the right
architecture where a probe-through-gasket install is acceptable (garage
fridges, some freestanding units), and UbiBot's own LoRa line (GW1 gateway
$279 + WS1 Pro-L $94) exists but is cloud-tethered with no self-hosted
server mode, still −20°C-floored, and pricier than Dragino. For owning the
backend, Dragino wins.

Suggested placement: shop fridge (glycol probe), shop freezer (glycol
probe), and a third sensor reading BARE air on purpose — the comparison
unit that shows why the buffered probe earns its jar.

## ORDERED (Sep 2026): 1× SenseCAP M2 Multi-Platform US915 (114992982),
## 3× Dragino LHT65N-E3. Setup for exactly that hardware:

1. **Stand up the private LoRaWAN server** on the shop machine (needs
   Docker Desktop): `cd tools/guardian-chirpstack && docker compose up -d`,
   then open http://127.0.0.1:8080 (admin/admin — change it, and change the
   api secret in configuration/chirpstack/chirpstack.toml). Everything —
   ChirpStack, broker, databases — runs on Wilson's machine; no vendor
   cloud anywhere in the path.
2. **Point the M2 at it**: in the M2's console, packet-forwarder mode,
   server = the shop machine's LAN IP, port 1700 (or Basics Station to
   ws://<shop-machine>:3001). Register the gateway's EUI in ChirpStack.
   Sub-band: US915 channels 8–15 (FSB2) — the LHT65N factory default; if
   uplinks never arrive, check this first.
3. **Create the LHT65N device profile** in ChirpStack (US915, OTAA) and
   paste Dragino's OWN payload decoder into the profile's codec (their
   dragino-end-node-decoder repo on GitHub → LHT65N). The bridge refuses
   to guess at raw bytes — Dragino's decoder is the one implementation.
4. **Join the three sensors** (DevEUI/AppEUI/AppKey are on each unit's
   sticker), long-press the ACT button to activate, confirm decoded TempC
   values appear in the console.
5. **Run the bridge**: `node tools/guardian-lora-bridge.js` (with the
   pilot server already running). Each sensor's channelId in
   guardian-pilot-sensors.json is its DevEUI (lowercase), field "field7",
   unit "C". The bridge prefers the glycol probe reading (TempC_DS),
   falls back to the internal sensor, and treats Dragino's 327.67
   no-probe sentinel as "no probe", never as a temperature.
   From there everything downstream — flag rules, drill labeling,
   incidents, exports — is identical to the UbiBot path
   (_qa/verify-lora-bridge.py proves it end to end, 14 checks).

## Setup (UbiBot forwarding path, kept for gasket-acceptable installs)

1. Onboard the sensors (UbiBot app for WS1s on 2.4GHz WiFi; ChirpStack on
   the LPS8v2 for LHT65Ns). Reading interval 5 min, sync 5–15 min.
2. Probe tips into the glycol jars, jars mid-shelf, sensor bodies inside
   the compartment. Set each channel's temperature unit or note it (server
   converts C→F).
3. On the shop machine (NOT exposed to the internet — office LAN only):
   copy `tools/guardian-pilot-sensors.example.json` to
   `guardian-pilot-sensors.json`, fill in the channel ids and fields
   (external probe = field7), then `node tools/guardian-pilot-server.js`.
4. In UbiBot's console, set each channel's Data Forwarding URL to
   `http://<shop-machine>:8091/ubibot`. The server answers "SUCCESS" the way
   their health check expects.
5. Optional: set `ALERT_WEBHOOK_URL` in the environment to a Slack/Teams
   incoming webhook so incidents buzz a phone. The account key, if the
   poller mode is used instead of forwarding, lives ONLY in the
   `UBIBOT_ACCOUNT_KEY` environment variable — never in a file in this repo.
6. Open `http://<shop-machine>:8091/` — the status page shows every sensor,
   its tier, and the incident log, judged by the exact production flag rules.

## The drills — force the failures, grade the thresholds

Let everything run quietly for 48 hours first (baseline: zero incidents
expected through real defrost cycles and door traffic). Then, one drill at a
time, logging start time and what the server did.

**Label every drill (v0.9.49).** Before inducing anything, tell the server
what you are about to do; end the label only after full recovery:

    curl -X POST http://127.0.0.1:8091/drill \
      -d '{"channelId":"12345","mode":"door_open","note":"showroom unit 3"}'
    ...run the drill, wait for full recovery...
    curl -X POST http://127.0.0.1:8091/drill/end -d '{"channelId":"12345"}'

Every reading that arrives during a labeled drill is written to a durable
training file, incidents fire stamped with the drill mode (detection latency
reads straight off the incident log), and `/export.jsonl` / `/export.csv`
are the labeled dataset the failure-signature work
(docs/GUARDIAN_FAILURE_SIGNATURES.md) starts from. Modes are a fixed list —
`GET /drills` shows them. That export is in-house training data: it stays on
the pilot box, out of the repo, out of marketing, out of anything a
customer sees.

| # | Drill (do this) | Expect | Pass = |
|---|---|---|---|
| 1 | **Baseline 48 h** — normal use, no interference | OK throughout, defrost spikes visible on the air-probe unit only | Zero incidents |
| 2 | **Door test** — prop the fridge door open 15–20 min, then close | Air probe spikes; glycol probe barely moves; both recover | Zero incidents; note recovery time on the chart |
| 3 | **Grocery test** — load a case of room-temp drinks | Slow bump, recovery within hours | Zero incidents |
| 4 | **Cayden's no-cool** — pull the probe+jar out to room temp (simulates the compartment warming), leave ~75 min | WARNING near the 45-min mark once past 41°F; **DISPATCH** once >45°F has held an hour | Both fire, in order, ±10 min |
| 5 | **The slow creep** — jar in a picnic cooler with an ice pack going soft, holding ~42–44°F for 2+ h (never reaching 45°F) | **DISPATCH via the recovery rule** at ~2 h over the line | Fires without ever touching the dispatch temperature |
| 6 | **WiFi kill** — pull the router plug (or block the sensor's MAC) for 3+ h | **OFFLINE** incident at the 3-hour hold | Fires; note it says "no reading", never fakes a temperature |
| 7 | **Recovery** — return each drill to normal | Tier returns to OK, recovery logged with the prior tier named | Recovery lines in the incident log |
| 8 | **Freezer defrost watch** — no interference; find the 2–3 daily defrost spikes on the freezer chart | Spikes visible on air probe, damped in glycol | Zero incidents through every defrost |

Grade sheet: each drill either fired the right tier at roughly the right time
or it didn't. If drill 2 or 8 pages anyone, the buffered numbers are too
tight for that cabinet (or a probe is out of its jar). If drill 4 or 5 is
slow by more than ~20 minutes, tighten `holdMinutes` /
`recoverWithinMinutes` in plan-config's flagRules — the server picks the
change up on restart, because it reads the same config file.

## What the pilot must answer before the $5k

1. Do the thresholds catch the forced failures without false alarms through
   normal use? (Drills above.)
2. How does 2.4GHz onboarding actually feel — minutes per sensor, any captive
   portal / mesh weirdness on the shop network?
3. Does data forwarding arrive reliably at 5–15 min sync, and what happens
   across a WiFi outage (the 300k-reading backfill should refill the chart)?
4. Glycol vs bare-air, side by side: how many would-be false alarms did the
   jar eat? (Compare the comparison unit's chart against the glycol units'.)
5. Battery vs USB: if any sensor must run on AAs, what interval keeps months
   of life?
6. THE RF QUESTION (v0.9.52, decisive for the product): does the radio get
   out of a built-in stainless column with the sensor fully inside? One
   sensor, one week, in the worst column on the floor, before any fleet
   order. If LoRa clears it and WiFi doesn't, the production sensor
   architecture is settled.

Green answers → buy the Developer Membership (with the four contract items in
TEMP_MONITORING_UBIBOT_NOTES.md), point the devices at the production
backend, and the pilot server's evaluation loop — which is already the
product's own rules — becomes the seed of that backend.

## Cost of the whole experiment

~$260 hardware + ~$9 in forwarding fees for a 90-day pilot. Every sensor is
reusable in the first customer installs.
