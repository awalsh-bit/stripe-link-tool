# Guardian pilot — the facts you will need twice a day

Copy this to `docs/PILOT_FACTS.md` and fill it in as you go.
**That copy is gitignored and never packaged**, the same rule as
`guardian-pilot-sensors.json`.

## Rule for this file

Record identifiers here. **Do not record passwords, keys or tokens here** —
they belong in a password manager. Specifically NOT here:

- the M2 console password (printed on the gateway's label)
- `GUARDIAN_ADMIN_TOKEN`
- any customer access key (those live only in the sensor registry, and the
  install desk shows each one exactly once)
- the ChirpStack API secret

If a value in this file leaks, the worst case should be that somebody knows
what hardware Wilson owns.

## The gateway

| | |
|---|---|
| Model / SKU | SenseCAP M2 Multi-Platform, US915 (114992982) |
| Serial | |
| Gateway EUI | (copy from the console's LoRa Network page, not the label) |
| Ethernet MAC | |
| Address on the shop LAN | |
| Console password | **in the password manager** — changed from the label value on ____ |
| Sub-band set to | FSB 2 (= channels 8-15 = our `us915_1`) |
| Physically sited | where / on what date |

## The pilot machine

| | |
|---|---|
| Hostname / LAN IP | |
| ChirpStack console | http://____:8080 |
| Pilot server | http://____:8091 |
| Admin token | **in the password manager** |

## ChirpStack

| | |
|---|---|
| Application name | |
| Device profile name | |
| Codec file pasted | `LHT65N ... Chirpstack 4.0 ...` — confirm it defines `decodeUplink` |
| Region chosen | US915 (channels 8-15 + 65) |

## The sensors

| Label | DevEUI | Compartment | Where installed | Installed on |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## Pre-qualification run

| | |
|---|---|
| Sensor used | |
| Column / location | |
| Gateway position during the test | |
| Started | |
| Verdict at day 7 | pass / fail / running |
| Longest gap | |
| Delivery ratio | |
| Battery start → end | |
