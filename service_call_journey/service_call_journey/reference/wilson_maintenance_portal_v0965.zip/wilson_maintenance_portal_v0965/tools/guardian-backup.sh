#!/usr/bin/env bash
#
# WILSON GUARDIAN — back up the files that cannot be regenerated.
#
#   ./tools/guardian-backup.sh [destination-directory]
#
# Run nightly by guardian-backup.timer; safe to run by hand any time.
#
# WHAT IS ACTUALLY AT RISK, and why this is not optional housekeeping:
#
#   guardian-pilot-sensors.json   THE REGISTRY. Every customer's access key
#                                 lives here and NOWHERE ELSE -- the install
#                                 desk shows each key exactly once, on the
#                                 screen that mints it, and then never
#                                 again. Lose this file and every customer's
#                                 charts link stops working, with no way to
#                                 recover the old keys: you would have to
#                                 re-issue every one and contact every
#                                 household. It also holds which sensor is
#                                 bound to which home, and their contacts.
#
#   guardian-pilot-training.jsonl THE LABELED FAILURE-DRILL DATASET. Every
#                                 hour a technician spent inducing a fault
#                                 in a showroom fridge is in here. It cannot
#                                 be reconstructed from anything. It is also
#                                 the trade secret this whole product line
#                                 leans on.
#
#   guardian-pilot-history.jsonl  Every reading ever taken. The analysis
#                                 view, the pre-qualification report and the
#                                 report trends all read it.
#
#   guardian-pilot-drills.json    Which drill ran when, so the training rows
#                                 above mean something.
#   guardian-pilot-incidents.jsonl   What was flagged, and when.
#   guardian-pilot-notifications.jsonl  What customers were actually told.
#
# NOT backed up: guardian-pilot-data.json. It is a rolling 48-hour working
# window and rebuilds itself from the next readings.
#
# ============================ HANDLE WITH CARE ============================
# The archive this writes contains CUSTOMER ACCESS KEYS and the trade-secret
# training set. It is written mode 600. If you copy it to a NAS, a USB stick
# or anywhere else, that copy carries the same weight -- keep it in-house,
# off any public share, and out of any repository or zip.
# ==========================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${1:-${GUARDIAN_BACKUP_DIR:-$ROOT/backups}}"
KEEP_DAYS="${GUARDIAN_BACKUP_KEEP_DAYS:-30}"

FILES=(
  guardian-pilot-sensors.json
  guardian-pilot-training.jsonl
  guardian-pilot-history.jsonl
  guardian-pilot-drills.json
  guardian-pilot-incidents.jsonl
  guardian-pilot-notifications.jsonl
)

mkdir -p "$DEST"
chmod 700 "$DEST"

stamp="$(date -u +%Y%m%dT%H%M%SZ)"
archive="$DEST/guardian-$stamp.tar.gz"

present=()
for f in "${FILES[@]}"; do
  [ -f "$ROOT/$f" ] && present+=("$f")
done

if [ ${#present[@]} -eq 0 ]; then
  echo "guardian-backup: nothing to back up yet in $ROOT (no pilot data files)."
  exit 0
fi

tar -czf "$archive" -C "$ROOT" "${present[@]}"
chmod 600 "$archive"

# A backup nobody checked is a backup nobody has. Fail loudly rather than
# leaving a zero-byte file that looks like success.
if [ ! -s "$archive" ]; then
  echo "guardian-backup: FAILED, archive is empty: $archive" >&2
  exit 1
fi

size="$(du -h "$archive" | cut -f1)"
echo "guardian-backup: wrote $archive ($size) containing ${#present[@]} file(s):"
printf '    %s\n' "${present[@]}"

# The registry is the one whose absence would be a quiet disaster, so it is
# called out by name rather than counted.
if [ ! -f "$ROOT/guardian-pilot-sensors.json" ]; then
  echo "guardian-backup: WARNING — no sensor registry found. If sensors are installed, something is wrong." >&2
fi

deleted="$(find "$DEST" -maxdepth 1 -name 'guardian-*.tar.gz' -mtime "+$KEEP_DAYS" -print -delete | wc -l)"
[ "$deleted" -gt 0 ] && echo "guardian-backup: pruned $deleted archive(s) older than $KEEP_DAYS days."

exit 0
