#!/usr/bin/env node
/*
 * WILSON GUARDIAN — SYNTHETIC NODE (rehearsal only)              (v0.9.63)
 *
 * Cayden: "I have received the gateway. Can we do anything before sensors
 * are here?"
 *
 * Yes. The gateway proves the top of the pipe; this proves the rest of it.
 * It publishes REAL ChirpStack-shaped uplink events onto the REAL MQTT
 * broker, so everything below the radio runs for real with no sensor in
 * the building:
 *
 *   this tool → mosquitto → guardian-lora-bridge → pilot server → rules
 *             → incidents → office module → customer page → phone widget
 *
 * That is five of the six bring-up layers, exercised end to end, days
 * before a sensor exists. What it does NOT prove is the one thing only
 * hardware can answer: whether a 915 MHz packet gets out of a stainless
 * column. Nothing here is a substitute for the RF pre-qualification test.
 *
 * WHAT IT IS FOR
 *   1. Proving the plumbing before the sensors land, so hardware day is
 *      about radios and not about Docker.
 *   2. REHEARSING THE OFFICE WORKFLOW with real staff on a real screen:
 *      install a sensor, watch burn-in, take a dispatch, run it through
 *      the close-out pipeline, record a cause of failure. Ten technicians
 *      and an office team can learn the product this week.
 *   3. Dry-running /prequal.json, so the go/no-go report is familiar —
 *      and its FAILURE shape is familiar — before it is deciding a
 *      hardware order.
 *
 * ==========================================================================
 *  THIS IS NOT A SENSOR. Everything it emits is invented.
 * ==========================================================================
 *
 * Two structural guards, because synthetic readings in the real archive
 * would quietly poison the labeled failure-drill dataset — the one asset
 * here that cannot be regenerated:
 *
 *   1. Every DevEUI it can produce begins `f0f0f0`, a reserved prefix that
 *      is not a real Dragino OUI. Synthetic rows stay identifiable in the
 *      archive forever.
 *   2. The PILOT SERVER refuses readings from that prefix unless it was
 *      started with GUARDIAN_REHEARSAL=1 — and rehearsal mode redirects
 *      every data file into rehearsal/ automatically. The guard lives on
 *      the server because the server owns the files; this tool cannot
 *      talk its way past it.
 *
 * USAGE
 *   node tools/guardian-fake-node.js --profile no_cool
 *   node tools/guardian-fake-node.js --profile healthy --kind freezer
 *   node tools/guardian-fake-node.js --profile patchy_radio --backfill 7
 *   node tools/guardian-fake-node.js --list
 *
 *   --profile <name>   the story to tell (see --list). Default: healthy.
 *   --kind <k>         fresh_food | freezer | wine. Default: fresh_food.
 *   --deveui <hex>     reuse a specific node. Must start f0f0f0.
 *   --backfill <days>  emit N days of history first, as fast as it can,
 *                      then continue live. This is how you fill the
 *                      analysis chart and /prequal.json in one go.
 *                      Expect the sensor to read OFFLINE for the first few
 *                      seconds of a backfill: until the replay catches up,
 *                      the newest reading really IS a day old, and the
 *                      offline rule is right to say so. It clears itself.
 *   --speed <n>        replay faster than real time: 60 means a
 *                      twenty-minute cadence arrives every twenty seconds
 *                      (timestamps stay correctly spaced — the simulated
 *                      clock starts in the past and catches up).
 *   --cadence <min>    reporting interval. Default 20, the LHT65N default.
 *   --via mqtt|http    mqtt (default) publishes to the broker and proves
 *                      the bridge. http POSTs the pilot server directly —
 *                      for rehearsing the office workflow on a laptop with
 *                      no Docker.
 *   --install          bind the node through the install desk first
 *                      (needs GUARDIAN_ADMIN_TOKEN). Exercises the install
 *                      panel and puts the sensor in BURN-IN, which is what
 *                      you want when rehearsing an install — and NOT what
 *                      you want when rehearsing a dispatch, since burn-in
 *                      suppresses alerts for its first day.
 *   --catch-up         with --backfill, stop as soon as the replay reaches
 *                      the present instead of continuing to stream. This
 *                      is the one to use for loading a week of history and
 *                      getting your prompt back.
 *   --once             emit a single reading and exit.
 *
 * CONFIG (environment)
 *   GUARDIAN_MQTT_HOST / GUARDIAN_MQTT_PORT   default 127.0.0.1:1883
 *   GUARDIAN_PILOT_URL                        default http://127.0.0.1:8091/ubibot
 *   GUARDIAN_ADMIN_TOKEN                      only needed for --install
 */
"use strict";

const net = require("net");
const http = require("http");
const crypto = require("crypto");
const mqtt = require("./guardian-mqtt-framing.js");

/* Not a real Dragino OUI. Synthetic data stays identifiable forever. */
const RESERVED_PREFIX = "f0f0f0";

const MQTT_HOST = process.env.GUARDIAN_MQTT_HOST || "127.0.0.1";
const MQTT_PORT = Number(process.env.GUARDIAN_MQTT_PORT || 1883);
const PILOT_URL = process.env.GUARDIAN_PILOT_URL || "http://127.0.0.1:8091/ubibot";
const ADMIN_TOKEN = process.env.GUARDIAN_ADMIN_TOKEN || "";

function arg(name, fallback) {
  const i = process.argv.indexOf("--" + name);
  return i > -1 && process.argv[i + 1] && process.argv[i + 1].indexOf("--") !== 0
    ? process.argv[i + 1] : fallback;
}
function flag(name) { return process.argv.indexOf("--" + name) > -1; }
function log(line) { console.log(new Date().toISOString() + "  " + line); }

/* ---- the stories -----------------------------------------------------------
 * Each profile answers: at T minutes into the story, what does this
 * compartment read, what is the cell at, and did the packet get through?
 *
 * `setpoint` is the band's own set point, handed in so one profile works
 * for a fridge, a freezer and a wine cabinet without three copies of it.
 * Profile names deliberately echo the drill taxonomy in
 * docs/GUARDIAN_FAILURE_SIGNATURES.md, so a rehearsal and a real showroom
 * drill are talking about the same thing.
 */
const PROFILES = {
  healthy: {
    note: "Ordinary life: a sawtooth around set point with occasional door blips. Should never flag.",
    at: function (minutes, setpoint, rand) {
      const cycle = Math.sin(minutes / 37) * 1.1;
      const door = rand() > 0.97 ? 3 + rand() * 3 : 0;
      return { f: setpoint + cycle + (rand() - 0.5) * 0.9 + door };
    }
  },
  door_open: {
    note: "One door left open for 25 minutes, then recovery. Should WARN at most, never dispatch.",
    at: function (minutes, setpoint, rand) {
      const inEvent = minutes >= 60 && minutes < 85;
      const recovering = minutes >= 85 && minutes < 115;
      const base = setpoint + (rand() - 0.5) * 0.9;
      if (inEvent) return { f: base + 6 + (minutes - 60) * 0.35 };
      if (recovering) return { f: base + 14 * (1 - (minutes - 85) / 30) };
      return { f: base };
    }
  },
  no_cool: {
    note: "Cayden's own example: a box that stops cooling and climbs past the dispatch line and stays. DISPATCHES.",
    at: function (minutes, setpoint, rand) {
      const climb = minutes < 30 ? 0 : Math.min(16, (minutes - 30) * 0.14);
      return { f: setpoint + climb + (rand() - 0.5) * 0.7 };
    }
  },
  slow_decline: {
    note: "The sealed-system creep: ~1°F/hr, never reaching the dispatch line. Caught by the recovery rule, not the dispatch line.",
    at: function (minutes, setpoint, rand) {
      return { f: setpoint + Math.min(7, minutes * 0.017) + (rand() - 0.5) * 0.6 };
    }
  },
  failed_defrost: {
    note: "A multi-day defrost failure: a slow climb with a widening daily sawtooth. Use with --backfill 3.",
    at: function (minutes, setpoint, rand) {
      const days = minutes / 1440;
      const saw = Math.sin(minutes / 180) * (1 + days * 1.6);
      return { f: setpoint + days * 3.2 + saw + (rand() - 0.5) * 0.8 };
    }
  },
  gasket_leak: {
    note: "Running a few degrees warm and noisier than it should — the unit the office should EYE, not dispatch.",
    at: function (minutes, setpoint, rand) {
      return { f: setpoint + 2.6 + Math.sin(minutes / 24) * 1.4 + (rand() - 0.5) * 1.4 };
    }
  },
  power_loss: {
    note: "Unplugged: a steady climb, then the sensor's own silence. Ends in an OFFLINE flag.",
    at: function (minutes, setpoint, rand) {
      if (minutes > 240) return { drop: true };
      return { f: setpoint + Math.min(25, minutes * 0.11) + (rand() - 0.5) * 0.5 };
    }
  },
  battery_decline: {
    note: "Temperatures fine, cell walking down through the 2.6V replace line and the 2.5V floor. Exercises the battery notice.",
    at: function (minutes, setpoint, rand) {
      return {
        f: setpoint + (rand() - 0.5) * 1.1,
        /* 3.05 V down to ~2.4 V over about a day of story time. */
        batV: Math.max(2.35, 3.05 - minutes * 0.00046)
      };
    }
  },
  patchy_radio: {
    note: "Healthy temperatures, unhealthy radio: scattered loss plus one long hole. Makes /prequal.json FAIL. Use with --backfill 7.",
    at: function (minutes, setpoint, rand) {
      /* A three-hour hole two days in — clustered loss, which is the kind
         that can hide a real event and the reason the gap criterion has no
         tolerance. */
      const inHole = minutes > 2880 && minutes < 3060;
      if (inHole || rand() > 0.88) return { drop: true };
      return {
        f: setpoint + Math.sin(minutes / 41) * 1.2 + (rand() - 0.5) * 0.9,
        rssi: -116 - Math.round(rand() * 6),
        snr: -8 - Math.round(rand() * 4)
      };
    }
  }
};

const KIND_SETPOINT = { fresh_food: 37, freezer: 0, wine: 55 };

/* ---- deterministic noise ---------------------------------------------------
 * Seeded from the DevEUI so a rehearsal can be run twice and tell the same
 * story — the same reason the prototype's simulator is seeded. A demo
 * nobody can repeat is a demo nobody can debug.
 */
function seeded(text) {
  let h = 2166136261;
  String(text).split("").forEach(function (ch) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  });
  return function () {
    h ^= h << 13; h ^= h >>> 17; h ^= h << 5;
    return ((h >>> 0) % 100000) / 100000;
  };
}

/* ---- the event ChirpStack would have published ----------------------------- */
function uplinkEvent(devEui, at, celsius, batV, rssi, snr) {
  return {
    deduplicationId: crypto.randomUUID ? crypto.randomUUID() : String(Math.random()),
    time: new Date(at).toISOString(),
    deviceInfo: {
      tenantName: "Wilson",
      applicationName: "wilson-guardian-rehearsal",
      deviceProfileName: "Dragino LHT65N",
      deviceName: "rehearsal-" + devEui.slice(-4),
      /* Lowercase, as ChirpStack's Rust EUI64 Display impl emits it. */
      devEui: devEui
    },
    devAddr: "01020304",
    dr: 3,
    fPort: 2,
    /* `data` is the raw payload ChirpStack also publishes; the bridge
       ignores it and reads `object`, exactly as it does in production. */
    data: Buffer.from([0xcb, 0xa4]).toString("base64"),
    /* The decoded object as Dragino's Chirpstack 4.0 codec emits it, with
       ChirpStack's single `data` unwrap already applied. Field names are
       the ones _qa/fixtures/dragino asserts against. */
    object: {
      BatV: Math.round(batV * 100) / 100,
      Bat_status: batV > 2.65 ? 3 : batV > 2.55 ? 2 : batV > 2.5 ? 1 : 0,
      TempC_SHT: Math.round((celsius + 8) * 100) / 100,
      Hum_SHT: 41.2,
      Ext_sensor: "Temperature Sensor",
      TempC_DS: Math.round(celsius * 100) / 100,
      Node_type: "LHT65N"
    },
    rxInfo: [{
      gatewayId: "f0f0f0fffe000001",
      uplinkId: Math.floor(Math.random() * 4294967295),
      rssi: rssi,
      snr: snr,
      context: "AAAAAA==",
      metadata: { region_name: "us915_1", region_common_name: "US915" }
    }],
    txInfo: {
      frequency: 904300000,
      modulation: { lora: { bandwidth: 125000, spreadingFactor: 10, codeRate: "CR_4_5" } }
    }
  };
}

/* ---- transports ------------------------------------------------------------- */
function httpPost(url, body, headers, done) {
  const target = new URL(url);
  const payload = JSON.stringify(body);
  const req = http.request(target, {
    method: "POST",
    headers: Object.assign({
      "Content-Type": "application/json",
      "Content-Length": Buffer.byteLength(payload)
    }, headers || {})
  }, function (res) {
    let text = "";
    res.on("data", function (c) { text += c; });
    res.on("end", function () { done(null, { status: res.statusCode, body: text }); });
  });
  req.on("error", function (err) { done(err); });
  req.end(payload);
}

function MqttPublisher(onReady) {
  const socket = net.connect(MQTT_PORT, MQTT_HOST);
  let buffer = Buffer.alloc(0);
  let ready = false;
  socket.on("connect", function () {
    socket.write(mqtt.connectPacket("wilson-guardian-fake-" + Math.random().toString(16).slice(2, 8), 60));
  });
  socket.on("data", function (chunk) {
    const read = mqtt.readPackets(Buffer.concat([buffer, chunk]));
    buffer = read.rest;
    read.packets.forEach(function (frame) {
      if (frame.type === 2 && !ready) { /* CONNACK */
        ready = true;
        setInterval(function () { socket.write(mqtt.PINGREQ); }, 30000).unref();
        onReady();
      }
    });
  });
  socket.on("error", function (err) {
    console.error("\nCannot reach the broker at mqtt://" + MQTT_HOST + ":" + MQTT_PORT +
      " (" + err.message + ").\nIs the ChirpStack stack up?  cd tools/guardian-chirpstack && docker compose up -d" +
      "\nOr rehearse without Docker:  --via http\n");
    process.exit(1);
  });
  this.publish = function (topic, payload) {
    socket.write(mqtt.publishPacket(topic, JSON.stringify(payload)));
  };
  this.end = function () { try { socket.write(mqtt.DISCONNECT); socket.end(); } catch (e) { /* closing anyway */ } };
}

/* ---- main -------------------------------------------------------------------- */
function listProfiles() {
  console.log("\nProfiles:\n");
  Object.keys(PROFILES).forEach(function (name) {
    console.log("  " + name.padEnd(17) + PROFILES[name].note);
  });
  console.log("\nCompartments: fresh_food (37°F) · freezer (0°F) · wine (55°F)\n");
}

function main() {
  if (flag("list") || flag("help")) { listProfiles(); return; }

  const profileName = String(arg("profile", "healthy"));
  const profile = PROFILES[profileName];
  if (!profile) {
    console.error("Unknown profile '" + profileName + "'. Run with --list.");
    process.exit(2);
  }
  const kind = String(arg("kind", "fresh_food"));
  if (!KIND_SETPOINT[kind]) {
    console.error("--kind must be fresh_food, freezer or wine.");
    process.exit(2);
  }

  let devEui = String(arg("deveui", "")).toLowerCase();
  if (devEui) {
    if (devEui.indexOf(RESERVED_PREFIX) !== 0 || !/^[0-9a-f]{16}$/.test(devEui)) {
      console.error("A --deveui for a synthetic node must be 16 hex characters beginning '" +
        RESERVED_PREFIX + "'.\nThat prefix is what keeps invented readings identifiable in the archive,\n" +
        "and the pilot server refuses it outside rehearsal mode. Pick another.");
      process.exit(2);
    }
  } else {
    devEui = RESERVED_PREFIX + crypto.randomBytes(5).toString("hex");
  }

  const cadence = Math.max(1, Number(arg("cadence", 20)));
  const backfillDays = Number(arg("backfill", 0)) || 0;
  const once = flag("once");
  const via = String(arg("via", "mqtt"));
  if (via !== "mqtt" && via !== "http") {
    console.error("--via must be mqtt or http.");
    process.exit(2);
  }
  /* Backfill dumps as fast as the transport allows, then settles to the
     requested speed for the live tail. */
  const liveSpeed = Math.max(1, Number(arg("speed", 1)));
  const setpoint = KIND_SETPOINT[kind];
  const rand = seeded(devEui + profileName);

  const startedAt = Date.now() - backfillDays * 1440 * 60000;
  let simulatedNow = startedAt;
  let emitted = 0, dropped = 0;

  console.log("");
  console.log("  ┌──────────────────────────────────────────────────────────────┐");
  console.log("  │  SYNTHETIC NODE — every reading below is invented.           │");
  console.log("  │  Not a sensor. Not evidence. Rehearsal only.                 │");
  console.log("  └──────────────────────────────────────────────────────────────┘");
  console.log("");
  log("node " + devEui + "  " + kind + " (set " + setpoint + "°F)  profile '" + profileName + "'");
  log(profile.note);
  log("via " + via + (via === "mqtt" ? "  mqtt://" + MQTT_HOST + ":" + MQTT_PORT : "  " + PILOT_URL) +
    "  ·  cadence " + cadence + " min" + (backfillDays ? "  ·  backfilling " + backfillDays + " days" : ""));
  console.log("");


  const topic = "application/rehearsal/device/" + devEui + "/event/up";
  let publisher = null;

  function emitOne(done) {
    const minutes = (simulatedNow - startedAt) / 60000;
    const point = profile.at(minutes, setpoint, rand) || {};
    simulatedNow += cadence * 60000;
    if (point.drop) {
      dropped += 1;
      if (done) done();
      return;
    }
    const fahrenheit = point.f;
    const celsius = (fahrenheit - 32) * 5 / 9;
    const batV = point.batV !== undefined ? point.batV : 3.02;
    const rssi = point.rssi !== undefined ? point.rssi : -100 - Math.round(rand() * 12);
    const snr = point.snr !== undefined ? point.snr : Math.round((6 - rand() * 8) * 10) / 10;
    const at = Math.min(simulatedNow - cadence * 60000, Date.now());
    const event = uplinkEvent(devEui, at, celsius, batV, rssi, snr);
    emitted += 1;
    /* Quiet during a backfill dump; every reading during a live tail. */
    const loud = !backfillDays || simulatedNow >= Date.now() - cadence * 60000;
    if (loud) {
      log(Math.round(fahrenheit * 10) / 10 + "°F  bat " + (Math.round(batV * 100) / 100) +
        "V  rssi " + rssi + "  snr " + snr);
    }
    if (via === "mqtt") {
      publisher.publish(topic, event);
      if (done) done();
    } else {
      /* The bridge is bypassed in http mode, so build the payload it would
         have built. One shape, defined in the bridge; restated here only
         because this path deliberately skips the bridge. */
      httpPost(PILOT_URL, {
        channel_id: devEui,
        feeds: [{ created_at: new Date(at).toISOString(), field7: { value: Math.round(celsius * 100) / 100 } }],
        battery: { volts: Math.round(batV * 100) / 100, status: null },
        radio: { rssi: rssi, snr: snr, dr: 3 }
      }, null, function (err, res) {
        if (err) {
          console.error("pilot server unreachable (" + err.message + ")");
          process.exit(1);
        }
        if (res.status !== 200) {
          console.error("\nThe pilot server refused this reading (" + res.status + " " + String(res.body).trim() + ").");
          console.error("If it says the channel is unknown, add the registry line printed above and restart it.");
          console.error("If it mentions rehearsal mode, start the server with GUARDIAN_REHEARSAL=1.\n");
          process.exit(1);
        }
        if (done) done();
      });
    }
  }

  function finishSummary() {
    console.log("");
    log("emitted " + emitted + " readings, dropped " + dropped +
      (dropped ? " (that is the profile's packet loss, not a bug)" : ""));
  }

  function run() {
    if (once) {
      emitOne(function () { finishSummary(); setTimeout(function () { process.exit(0); }, 200); });
      return;
    }
    const catchUpOnly = flag("catch-up");
    const step = function () {
      const catchingUp = simulatedNow < Date.now() - cadence * 60000;
      if (!catchingUp && catchUpOnly) {
        finishSummary();
        log("caught up to now — stopping, as --catch-up asked.");
        if (publisher) publisher.end();
        /* A beat for the last MQTT write to leave the socket. */
        setTimeout(function () { process.exit(0); }, 300);
        return;
      }
      emitOne(function () {
        /* Backfill runs flat out; the live tail runs at the requested
           speed, which is real time unless --speed says otherwise. */
        const delay = catchingUp ? 4 : Math.max(200, (cadence * 60000) / liveSpeed);
        setTimeout(step, delay);
      });
    };
    step();
  }

  /*
   * Register with the server before publishing. In rehearsal mode the
   * server self-provisions any channel on the reserved prefix, so nobody
   * has to hand-edit a registry before an office can practise — the
   * friction that would otherwise mean the rehearsal never happens.
   *
   * If the server refuses, it is almost always because it was not started
   * with GUARDIAN_REHEARSAL=1, and the message says so.
   */
  function register(next) {
    const base = PILOT_URL.replace(/\/ubibot\/?$/, "");
    httpPost(base + "/rehearsal/register", {
      channelId: devEui, kind: kind,
      label: "Rehearsal — " + profileName.replace(/_/g, " ")
    }, null, function (err, res) {
      if (err) {
        console.error("\nCannot reach the pilot server at " + base + " (" + err.message + ").");
        console.error("Start it first:  GUARDIAN_REHEARSAL=1 node tools/guardian-pilot-server.js\n");
        process.exit(1);
      }
      if (res.status === 403) {
        console.error("\nThe pilot server is NOT in rehearsal mode, so it will not accept invented readings.");
        console.error("Restart it with:  GUARDIAN_REHEARSAL=1 node tools/guardian-pilot-server.js");
        console.error("(that also sandboxes every data file under rehearsal/, so the real archive is untouched)\n");
        process.exit(1);
      }
      if (res.status !== 200) {
        console.error("registration refused: " + res.status + " " + String(res.body).trim());
        process.exit(1);
      }
      log("registered with the pilot server as a rehearsal sensor.");
      next();
    });
  }

  function maybeInstall(next) {
    if (!flag("install")) { next(); return; }
    if (!ADMIN_TOKEN) {
      console.error("--install needs GUARDIAN_ADMIN_TOKEN in the environment (the same token the server was started with).");
      process.exit(2);
    }
    const base = PILOT_URL.replace(/\/ubibot\/?$/, "");
    httpPost(base + "/admin/install", {
      channelId: devEui,
      kind: kind,
      label: "Rehearsal — " + profileName.replace(/_/g, " "),
      householdName: "Rehearsal Household " + devEui.slice(-4)
    }, { "x-guardian-admin": ADMIN_TOKEN }, function (err, res) {
      if (err || res.status !== 200) {
        console.error("install failed: " + (err ? err.message : res.status + " " + res.body));
        process.exit(1);
      }
      const out = JSON.parse(res.body);
      log("installed through the desk — the sensor is now in BURN-IN, so it will chart but not alert.");
      if (out.key) log("customer key (shown once): guardian-customer.html?key=" + out.key);
      console.log("");
      next();
    });
  }

  process.on("SIGINT", function () {
    finishSummary();
    if (publisher) publisher.end();
    process.exit(0);
  });

  if (via === "mqtt") {
    publisher = new MqttPublisher(function () {
      log("connected to the broker — publishing " + topic);
      register(function () { maybeInstall(run); });
    });
  } else {
    register(function () { maybeInstall(run); });
  }
}

main();
