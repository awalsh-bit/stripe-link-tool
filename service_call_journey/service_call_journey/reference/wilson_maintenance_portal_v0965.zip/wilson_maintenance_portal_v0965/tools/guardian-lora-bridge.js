#!/usr/bin/env node
/*
 * WILSON GUARDIAN — LoRa → pilot-server bridge                   (v0.9.62)
 *
 * The missing inch of pipe between ChirpStack (tools/guardian-chirpstack)
 * and the pilot server (tools/guardian-pilot-server.js). It subscribes to
 * ChirpStack's MQTT uplink events, reads each LHT65N reading, and POSTs it
 * to the pilot server in the same shape UbiBot forwarding uses — so the
 * pilot server, its flag rules, its drill labeling and its incident log
 * run UNCHANGED whichever radio the reading rode in on.
 *
 *   M2 gateway → ChirpStack → MQTT → this bridge → POST /ubibot → rules
 *
 * SETUP  (the step-by-step version, with the expected output at each
 *         layer, is docs/GUARDIAN_BRINGUP.md — read that on hardware day)
 *   1. In ChirpStack (http://127.0.0.1:8080): create a device profile for
 *      the LHT65N, region US915, and PASTE DRAGINO'S OWN JS CODEC into the
 *      profile's payload codec. This bridge deliberately does NOT decode
 *      raw bytes itself — Dragino's decoder is the authoritative one, and a
 *      home-grown copy of it would be a second implementation waiting to
 *      disagree.
 *
 *      THE FILE MATTERS. Dragino's repo
 *      (github.com/dragino/dragino-end-node-decoder → LHT65N/) contains
 *      several. Use one whose name says Chirpstack 4.0 or ChirpstackV4 —
 *      they define `decodeUplink`. The file named
 *      "LHT65N-chirpstack decoder.txt" is the ChirpStack **v3** style
 *      codec: it defines only `Decode()`, and ChirpStack 4 throws a
 *      ReferenceError on it and publishes the uplink with NO decoded
 *      object. From this bridge's side that is indistinguishable from
 *      never having pasted a codec at all — which is why the skip message
 *      below names both possibilities.
 *   2. Register the three sensors (DevEUI/AppKey off each unit's sticker),
 *      join them, confirm the console shows decoded TempC values.
 *   3. In guardian-pilot-sensors.json, each sensor's channelId is its
 *      DevEUI, field "field7", unit "C". Case does not matter: ChirpStack's
 *      JSON reports DevEUIs in lowercase while its WEB UI displays them
 *      uppercase, so the pilot server matches channel ids case-insensitively
 *      rather than making a copy-paste silently drop every reading.
 *   4. node tools/guardian-lora-bridge.js
 *
 * CONFIG (environment)
 *   GUARDIAN_MQTT_HOST   default 127.0.0.1
 *   GUARDIAN_MQTT_PORT   default 1883
 *   GUARDIAN_PILOT_URL   default http://127.0.0.1:8091/ubibot
 *
 * Readings: the glycol-buffered external probe (TempC_DS) is the truth
 * when present; the sensor's internal SHT reading is the fallback. Dragino
 * reports 327.67 for "no probe attached" — that is a sentinel, never a
 * temperature, and it is dropped, not forwarded.
 *
 * BATTERY AND RADIO RIDE ALONG.                                  (v0.9.62)
 * The RF pre-qualification test asks two questions no temperature can
 * answer: did the packets get out of the stainless column, and did the
 * battery hold. Both arrive in every uplink anyway — BatV from the
 * decoder, RSSI/SNR from ChirpStack's gateway metadata — so the bridge
 * forwards them instead of logging them and throwing them away. The pilot
 * server records them beside the reading; /prequal.json turns them into
 * the go/no-go numbers.
 *
 * The MQTT client below is deliberately minimal (QoS 0 subscribe, ping,
 * reconnect) and dependency-free, matching the pilot server's zero-install
 * rule: the shop machine runs `node`, nothing else.
 *
 * QA: --stdin mode reads one uplink-event JSON per line and exits — the
 * harness (_qa/verify-lora-bridge.py) pipes fixtures through the same
 * handleEvent() the MQTT path uses, including fixtures produced by running
 * Dragino's REAL decoder over real payload bytes.
 */
"use strict";

const net = require("net");
const http = require("http");
const mqtt = require("./guardian-mqtt-framing.js");

const MQTT_HOST = process.env.GUARDIAN_MQTT_HOST || "127.0.0.1";
const MQTT_PORT = Number(process.env.GUARDIAN_MQTT_PORT || 1883);
const PILOT_URL = process.env.GUARDIAN_PILOT_URL || "http://127.0.0.1:8091/ubibot";
const TOPIC = "application/+/device/+/event/up";
const STDIN_MODE = process.argv.indexOf("--stdin") > -1;

/* Dragino's no-probe sentinel: 0x7FFF / 100. Anything within a whisker of
   it is "no probe", not "the freezer is on fire". */
const NO_PROBE_C = 327.67;

function log(line) { console.log(new Date().toISOString() + "  " + line); }

/* ---- reading extraction --------------------------------------------------
 * ChirpStack v4 uplink event (JSON marshaler): deviceInfo.devEui, time,
 * fPort, object (present only when the device profile has a working codec),
 * rxInfo[] with rssi/snr per receiving gateway, dr.
 *
 * Two shapes of the same event are worth remembering, because the JSON
 * marshaler omits protobuf defaults: `fPort` is ABSENT when it is 0, `dr`
 * absent when 0, `fCnt` absent on the first uplink. So nothing here may be
 * read as a required field.
 */

/*
 * ONE LEVEL OF `data`, DEFENSIVELY.
 *
 * ChirpStack's JS codec contract is `decodeUplink()` returns {data: {...}},
 * and ChirpStack unwraps exactly that one level before publishing `object`
 * — verified in chirpstack/src/codec/js/mod.rs. So in the normal case the
 * fields are already at the top of `object` and this is a no-op.
 *
 * It is not always the normal case. Dragino's 1.5.6 decoder returns
 * {data:{data:{...}}} on a retransmission/datalog frame, and ChirpStack
 * strips only the outer one — leaving `object` as {data:{...}}. Rather than
 * skip a perfectly good reading over someone else's double wrapper, look
 * one level in. Bounded to one step on purpose: unbounded unwrapping would
 * start guessing at payload structure, which is the decoder's job.
 */
function decodedFields(object) {
  if (!object || typeof object !== "object") return null;
  const hasTemp = object.TempC_DS !== undefined || object.TempC_SHT !== undefined;
  if (!hasTemp && object.data && typeof object.data === "object") return object.data;
  return object;
}

function extractReading(event) {
  const devEui = String(((event || {}).deviceInfo || {}).devEui || "").toLowerCase();
  if (!devEui) return { ok: false, reason: "no devEui on the event" };
  const object = decodedFields(event.object);
  if (!object) {
    return {
      ok: false, devEui: devEui,
      reason: "no decoded object — either the ChirpStack device profile has no payload codec yet, " +
        "or it has the ChirpStack v3 file (which defines Decode() instead of decodeUplink() and fails silently on v4). " +
        "Paste Dragino's 'Chirpstack 4.0' LHT65N decoder (step 1 in this file's header; docs/GUARDIAN_BRINGUP.md walks it)"
    };
  }
  /*
   * Dragino's field names, confirmed across every published decoder version
   * from v1.3.3 to v1.5.6: the external probe is `TempC_DS`. There is no
   * `TempC_DS18B20` in any version — an earlier draft of this file read that
   * name as a fallback, which would never have matched anything.
   * `_qa/fixtures/dragino/` holds the real decoders and the suite runs them,
   * so a future rename fails a test instead of a fridge.
   *
   * Values arrive as numbers or numeric strings depending on version, so
   * Number() both.
   */
  const ext = Number(object.TempC_DS);
  const internal = Number(object.TempC_SHT);
  const extValid = Number.isFinite(ext) && Math.abs(ext - NO_PROBE_C) > 0.5 && Math.abs(ext) < 200;
  const internalValid = Number.isFinite(internal) && Math.abs(internal) < 200;
  if (!extValid && !internalValid) {
    /* Name the two cases that actually happen, because they mean different
       things at the fridge: a datalog/retransmission frame carries no live
       reading at all and is nothing to worry about; a probe reading of
       327.67 with no internal reading means the E3 cable is unplugged. */
    const sentinel = Number.isFinite(ext) && Math.abs(ext - NO_PROBE_C) <= 0.5;
    return {
      ok: false, devEui: devEui,
      reason: sentinel
        ? "probe reports 327.67°C (no probe attached) and no internal reading either — check the E3 cable at the sensor"
        : "no usable temperature in decoded object" +
          (object.DATALOG || object.retransmission_message ? " (datalog/retransmission frame, not a live reading)" : "")
    };
  }
  const t = Date.parse(event.time || "");
  /*
   * The BEST gateway heard it. rxInfo lists one entry per receiving
   * gateway; the pre-qual question is "did the packet get out", so the
   * strongest copy is the honest one to record. One gateway in the pilot
   * makes this a formality — it stops being one the day a second gateway
   * goes in a detached garage.
   */
  let rssi = null, snr = null;
  (Array.isArray(event.rxInfo) ? event.rxInfo : []).forEach(function (rx) {
    const r = Number((rx || {}).rssi);
    const s = Number((rx || {}).snr);
    if (Number.isFinite(r) && (rssi === null || r > rssi)) rssi = r;
    if (Number.isFinite(s) && (snr === null || s > snr)) snr = s;
  });
  return {
    ok: true,
    devEui: devEui,
    celsius: extValid ? ext : internal,
    source: extValid ? "probe" : "internal",
    at: Number.isFinite(t) ? new Date(t).toISOString() : new Date().toISOString(),
    /*
     * BatV is volts and is stable in every decoder version. Bat_status is
     * NOT: it is a number 0-3 up to v1.5.0 and the strings "Good"/"OK"/
     * "Low"/"Ultra Low" in v1.5.6. So it travels as an opaque label for a
     * human to read, and every threshold decision is made on the volts.
     * Ext=9 (probe + timestamp mode) omits BatV entirely — hence the
     * finite check rather than an assumption.
     */
    batV: Number.isFinite(Number(object.BatV)) ? Number(object.BatV) : null,
    batStatus: object.Bat_status === undefined ? null : String(object.Bat_status),
    rssi: rssi,
    snr: snr,
    dr: Number.isFinite(Number(event.dr)) ? Number(event.dr) : null
  };
}

/*
 * The exact payload shape guardian-pilot-server.js already ingests, plus
 * two optional siblings it now reads. A UbiBot forward carries neither, so
 * both paths stay valid on one endpoint.
 */
function toPilotPayload(reading) {
  const payload = {
    channel_id: reading.devEui,
    feeds: [{ created_at: reading.at, field7: { value: reading.celsius } }]
  };
  if (reading.batV !== null || reading.batStatus !== null) {
    payload.battery = { volts: reading.batV, status: reading.batStatus };
  }
  if (reading.rssi !== null || reading.snr !== null || reading.dr !== null) {
    payload.radio = { rssi: reading.rssi, snr: reading.snr, dr: reading.dr };
  }
  return payload;
}

function postToPilot(reading, done) {
  const body = JSON.stringify(toPilotPayload(reading));
  const url = new URL(PILOT_URL);
  const req = http.request(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
  }, function (res) {
    let text = "";
    res.on("data", function (c) { text += c; });
    res.on("end", function () {
      if (done) done(null, { status: res.statusCode, body: text });
    });
  });
  req.on("error", function (err) { if (done) done(err); });
  req.end(body);
}

function handleEvent(event, done) {
  const reading = extractReading(event);
  if (!reading.ok) {
    log("skipped " + (reading.devEui || "unknown device") + ": " + reading.reason);
    if (done) done(null, { skipped: true, reason: reading.reason });
    return;
  }
  postToPilot(reading, function (err, res) {
    if (err) {
      log("pilot server unreachable (" + err.message + ") — reading from " + reading.devEui + " dropped; the sensor's next uplink retries naturally");
    } else {
      log(reading.devEui + "  " + reading.celsius + "°C (" + reading.source + ")" +
        (reading.batV !== null ? "  bat " + reading.batV + "V" : "") +
        (reading.rssi !== null ? "  rssi " + reading.rssi : "") +
        (reading.snr !== null ? "  snr " + reading.snr : "") +
        "  → pilot " + res.status + " " + String(res.body).trim());
    }
    if (done) done(err, res);
  });
}

/* ---- minimal MQTT 3.1.1 client (QoS 0) -----------------------------------
 * The wire format lives in guardian-mqtt-framing.js, shared with
 * guardian-fake-node.js — one implementation of the packet layout, since
 * two tools now speak it in opposite directions.
 */
function connectMqtt() {
  const socket = net.connect(MQTT_PORT, MQTT_HOST);
  let buffer = Buffer.alloc(0);
  let pinger = null;

  socket.on("connect", function () {
    const clientId = "wilson-guardian-bridge-" + Math.random().toString(16).slice(2, 8);
    socket.write(mqtt.connectPacket(clientId, 60));
  });

  socket.on("data", function (chunk) {
    const read = mqtt.readPackets(Buffer.concat([buffer, chunk]));
    buffer = read.rest;
    read.packets.forEach(function (frame) {
      if (frame.type === 2) { /* CONNACK */
        log("connected to mqtt://" + MQTT_HOST + ":" + MQTT_PORT + " — subscribing " + TOPIC);
        socket.write(mqtt.subscribePacket(TOPIC, 1));
        pinger = setInterval(function () { socket.write(mqtt.PINGREQ); }, 30000);
      } else if (frame.type === 3) { /* PUBLISH (QoS 0 — no packet id) */
        const message = mqtt.readPublish(frame.body);
        try { handleEvent(JSON.parse(message.payload.toString("utf8"))); }
        catch (e) { log("unparseable uplink event: " + e.message); }
      }
      /* SUBACK (9) and PINGRESP (13) need no action. */
    });
  });

  const retry = function (why) {
    if (pinger) { clearInterval(pinger); pinger = null; }
    log(why + " — reconnecting in 10s");
    setTimeout(connectMqtt, 10000);
  };
  socket.on("error", function (err) { socket.destroy(); retry("mqtt error: " + err.message); });
  socket.on("close", function () { retry("mqtt connection closed"); });
}

/* ---- entry ---------------------------------------------------------------- */
if (STDIN_MODE) {
  /* One event JSON per line; exits when stdin ends. */
  let pending = 0, ended = false;
  const finish = function () { if (ended && pending === 0) process.exit(0); };
  let carry = "";
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", function (chunk) {
    const lines = (carry + chunk).split("\n");
    carry = lines.pop();
    lines.forEach(function (line) {
      if (!line.trim()) return;
      let event;
      try { event = JSON.parse(line); } catch (e) { log("unparseable line: " + e.message); return; }
      pending += 1;
      handleEvent(event, function () { pending -= 1; finish(); });
    });
  });
  process.stdin.on("end", function () {
    if (carry.trim()) {
      try { pending += 1; handleEvent(JSON.parse(carry), function () { pending -= 1; finish(); }); }
      catch (e) { log("unparseable line: " + e.message); }
    }
    ended = true; finish();
  });
} else {
  log("Guardian LoRa bridge: mqtt://" + MQTT_HOST + ":" + MQTT_PORT + "  →  " + PILOT_URL);
  connectMqtt();
}

/* Exported for completeness if ever required from another tool. */
module.exports = {
  extractReading: extractReading,
  toPilotPayload: toPilotPayload,
  decodedFields: decodedFields
};
