/*
 * MQTT 3.1.1 WIRE FORMAT — the encoders, shared.               (v0.9.63)
 *
 * The pilot machine runs `node` and nothing else: no npm install, no
 * package.json, no dependency to audit or update on a shop computer that
 * nobody administers. That rule is why this project speaks MQTT by hand.
 *
 * Two tools now need it — guardian-lora-bridge.js (subscribe) and
 * guardian-fake-node.js (publish) — so the byte-level encoding lives here
 * once. There is nothing clever in it; it is the packet layout out of the
 * MQTT 3.1.1 spec, and the only reason to read this file is to check it
 * against that spec.
 *
 * Deliberately NOT a general MQTT client: no QoS 1/2, no retained
 * messages, no will, no session state. Everything Guardian sends is a
 * fire-and-forget sensor reading, and the reconnect loops in the callers
 * handle the rest.
 */
"use strict";

/* A UTF-8 string, length-prefixed with two big-endian bytes. */
function encodeString(text) {
  const body = Buffer.from(text, "utf8");
  return Buffer.concat([Buffer.from([body.length >> 8, body.length & 0xff]), body]);
}

/*
 * MQTT's variable-length integer: seven bits per byte, high bit set on
 * every byte but the last. Four bytes maximum, which caps a packet at
 * 256 MB — irrelevant here, where the largest thing sent is one JSON
 * uplink event.
 */
function encodeLength(value) {
  const out = [];
  let remaining = value;
  do {
    let byte = remaining % 128;
    remaining = Math.floor(remaining / 128);
    if (remaining > 0) byte |= 0x80;
    out.push(byte);
  } while (remaining > 0);
  return Buffer.from(out);
}

/* type: 1 CONNECT, 3 PUBLISH, 8 SUBSCRIBE, 12 PINGREQ, 14 DISCONNECT. */
function packet(type, flags, payload) {
  return Buffer.concat([
    Buffer.from([(type << 4) | flags]),
    encodeLength(payload.length),
    payload
  ]);
}

/* CONNECT with a clean session and no credentials — the broker in
   tools/guardian-chirpstack allows anonymous on the office LAN only. */
function connectPacket(clientId, keepaliveSeconds) {
  const variable = Buffer.concat([
    encodeString("MQTT"),
    Buffer.from([
      4,                                   /* protocol level 4 = 3.1.1 */
      0x02,                                /* clean session */
      (keepaliveSeconds >> 8) & 0xff, keepaliveSeconds & 0xff
    ])
  ]);
  return packet(1, 0, Buffer.concat([variable, encodeString(clientId)]));
}

/* SUBSCRIBE at QoS 0. Flags 0x02 is mandatory on SUBSCRIBE. */
function subscribePacket(topic, packetId) {
  const id = Buffer.from([(packetId >> 8) & 0xff, packetId & 0xff]);
  return packet(8, 2, Buffer.concat([id, encodeString(topic), Buffer.from([0])]));
}

/* PUBLISH at QoS 0 — no packet id, no acknowledgement. */
function publishPacket(topic, payload) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), "utf8");
  return packet(3, 0, Buffer.concat([encodeString(topic), body]));
}

const PINGREQ = Buffer.from([0xc0, 0x00]);
const DISCONNECT = Buffer.from([0xe0, 0x00]);

/*
 * Pull whole packets out of a growing byte stream. Returns the packets it
 * could complete and the remainder to keep for next time — a TCP read
 * boundary lands wherever it likes, and a half-arrived packet must wait
 * rather than be parsed.
 */
function readPackets(buffer) {
  const packets = [];
  let rest = buffer;
  for (;;) {
    if (rest.length < 2) break;
    let length = 0, multiplier = 1, offset = 1;
    let complete = false;
    for (;;) {
      if (offset >= rest.length) break;
      const byte = rest[offset];
      length += (byte & 0x7f) * multiplier;
      multiplier *= 128;
      offset += 1;
      if ((byte & 0x80) === 0) { complete = true; break; }
    }
    if (!complete || rest.length < offset + length) break;
    packets.push({ type: rest[0] >> 4, body: rest.slice(offset, offset + length) });
    rest = rest.slice(offset + length);
  }
  return { packets: packets, rest: rest };
}

/* The topic and payload of a QoS 0 PUBLISH body. */
function readPublish(body) {
  const topicLength = (body[0] << 8) | body[1];
  return {
    topic: body.slice(2, 2 + topicLength).toString("utf8"),
    payload: body.slice(2 + topicLength)
  };
}

module.exports = {
  encodeString: encodeString,
  encodeLength: encodeLength,
  packet: packet,
  connectPacket: connectPacket,
  subscribePacket: subscribePacket,
  publishPacket: publishPacket,
  readPackets: readPackets,
  readPublish: readPublish,
  PINGREQ: PINGREQ,
  DISCONNECT: DISCONNECT
};
