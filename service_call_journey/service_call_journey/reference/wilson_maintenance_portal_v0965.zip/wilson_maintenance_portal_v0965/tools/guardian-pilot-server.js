#!/usr/bin/env node
/*
 * WILSON GUARDIAN — PILOT INGEST SERVER                           (v0.9.62)
 *
 * Cayden: "I'd like to deploy a few test sensors and force a few failures to
 * see how everything reacts and if our thresholds catch the fails."
 *
 * This is the smallest real backend that makes that test honest: it receives
 * ACTUAL UbiBot readings and judges them with the EXACT same code and config
 * the prototype uses -- it loads assets/plan-config.js (the researched
 * flagRules) and assets/temp-monitoring.js (evaluateFlags) into a sandbox, so
 * there is one implementation of the rules and the pilot exercises it.
 *
 * WHAT IT DOES
 *   - POST /ubibot           UbiBot Data Forwarding endpoint. Point each test
 *                            channel's forwarding at http://<this box>/ubibot.
 *                            Replies "SUCCESS" the way UbiBot expects.
 *   - optional REST poller   --poll with UBIBOT_ACCOUNT_KEY set pulls the
 *                            channel list instead, for a pilot too small to
 *                            bother with forwarding. Stays far inside
 *                            UbiBot's limits (one poll per 90s for the whole
 *                            account; their cap is 6 calls/account/minute).
 *   - every 30s              re-evaluates every sensor against the flag
 *                            rules; logs WARNING / DISPATCH / OFFLINE
 *                            transitions to the console and to
 *                            guardian-pilot-incidents.jsonl; optionally POSTs
 *                            each incident to ALERT_WEBHOOK_URL (Slack-style
 *                            {text} payload) so the office phone buzzes.
 *   - GET /                  a status page: every sensor, latest reading,
 *                            tier, over-for, radio/battery, and the
 *                            incident log.
 *   - GET /status.json       the same as data, for QA and curl.
 *   - GET /guardian.html     the office module, and /guardian-customer.html
 *                            the customer view, served from THIS origin so
 *                            the browser never blocks their own feed.
 *   - GET /prequal.json      the RF PRE-QUALIFICATION report (v0.9.62):
 *                            packet delivery ratio, longest radio gap,
 *                            RSSI/SNR spread and battery drift, each
 *                            graded against the pass criteria in
 *                            plan-config tempMonitoring.prequal. This is
 *                            the instrument for the go/no-go on a fleet
 *                            order: one sensor, one week, inside the worst
 *                            stainless column, gateway where a customer's
 *                            would live.
 *
 * BURN-IN (v0.9.62): a sensor installed through /admin/install carries an
 * `installedAt`, and for the configured window (tempMonitoring.
 * commissioning.hours) it reads tier `burnin` -- it charts, it is visible,
 * an installer can watch it fall to set point, and it does NOT alert,
 * open a case or count as protecting anything. A sensor out of the box is
 * at room temperature in a glycol vial that has not equilibrated; letting
 * that page the office would make the first thing Guardian ever does a
 * false alarm. OFFLINE and WAITING still outrank burn-in, because a failed
 * install is not a settling one.
 *
 * DRILL LABELING (the training set for failure-mode trends)
 *   Cayden: "once we have the temp loggers installed in our showroom as a
 *   test, i can force different kinds of failures and get the data so we can
 *   start programming trends." The taxonomy and drill protocol live in
 *   docs/GUARDIAN_FAILURE_SIGNATURES.md. The server is the lab notebook:
 *
 *   - POST /drill            {"channelId":"1001","mode":"no_evap_fan","note":"..."}
 *                            starts a labeled drill on that sensor. Start the
 *                            label BEFORE inducing the failure.
 *   - POST /drill/end        {"channelId":"1001"} ends it — after FULL
 *                            recovery, so the recovery curve is labeled too.
 *   - GET  /drills           active + completed drills.
 *   - GET  /export.jsonl     every stored reading, one JSON line each, with
 *   - GET  /export.csv       its drill label ("healthy" outside any drill).
 *                            This export IS the labeled dataset the trend
 *                            programming starts from. It is a trade secret:
 *                            keep it in-house, never in marketing, never in
 *                            anything customer-visible.
 *
 *   Incidents that fire during a drill carry the drill mode, so the drill
 *   sheet can read detection latency straight off the incident log.
 *
 * SETUP
 *   1. Copy guardian-pilot-sensors.example.json to guardian-pilot-sensors.json
 *      and fill in your channel ids, which field carries the probe (UbiBot
 *      maps external probes to field7-field10; onboard temp is field1), and
 *      what each sensor watches (fresh_food / freezer / wine).
 *   2. node tools/guardian-pilot-server.js            (forwarding mode)
 *      node tools/guardian-pilot-server.js --poll     (poller mode; needs
 *      UBIBOT_ACCOUNT_KEY in the environment -- NEVER in a file in this repo)
 *
 * SECURITY: binds 127.0.0.1 by default (HOST=0.0.0.0 to expose on the shop
 * LAN). Do not put this on public wifi or tunnel it to the internet; the
 * account key lives only in the environment.
 */
"use strict";

const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const crypto = require("crypto");

const ROOT = path.join(__dirname, "..");
const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 8091);
const POLL = process.argv.indexOf("--poll") > -1;

/*
 * REHEARSAL MODE.                                                (v0.9.63)
 *
 * Cayden has the gateway before the sensors, and wants the office to be
 * able to practise on a live system. tools/guardian-fake-node.js can feed
 * this server invented readings — which is genuinely useful and also the
 * single most dangerous thing in this repository, because synthetic rows
 * in guardian-pilot-training.jsonl would quietly poison the labeled
 * failure-drill dataset. That dataset is the one asset here that cannot be
 * regenerated.
 *
 * So the guard lives HERE, on the side that owns the files:
 *
 *   - readings from the reserved synthetic DevEUI prefix are REFUSED
 *     unless this server was started with GUARDIAN_REHEARSAL=1;
 *   - and turning rehearsal on automatically moves every data file into
 *     rehearsal/, so nobody has to remember to redirect them. Forgetting
 *     is the failure mode, so forgetting is designed out.
 *
 * Explicit GUARDIAN_*_FILE env vars still win, because the QA harness sets
 * them to a temp directory and must keep doing so.
 */
const REHEARSAL = process.env.GUARDIAN_REHEARSAL === "1";
/* Not a real Dragino OUI. Must match RESERVED_PREFIX in
   tools/guardian-fake-node.js — _qa/verify-rehearsal.py asserts they are
   the same string, since one runtime cannot import the other's constant. */
const SYNTHETIC_PREFIX = "f0f0f0";
const DATA_DIR = REHEARSAL ? path.join(ROOT, "rehearsal") : ROOT;
if (REHEARSAL) { try { fs.mkdirSync(DATA_DIR, { recursive: true }); } catch (e) { /* already there */ } }
function dataFile(envName, base) {
  return process.env[envName] || path.join(DATA_DIR, base);
}

/* Env overrides exist so the QA harness can run against fixture files
   without touching a real pilot's data. */
const SENSORS_FILE = dataFile("GUARDIAN_SENSORS_FILE", "guardian-pilot-sensors.json");
const DATA_FILE = dataFile("GUARDIAN_DATA_FILE", "guardian-pilot-data.json");
const INCIDENT_FILE = dataFile("GUARDIAN_INCIDENT_FILE", "guardian-pilot-incidents.jsonl");
const DRILL_FILE = dataFile("GUARDIAN_DRILL_FILE", "guardian-pilot-drills.json");
const KEEP_HOURS = 48;
/*
 * THE ANALYSIS HISTORY.                                          (v0.9.60)
 *
 * The live `store` is a 48-hour rolling window — right for judging flags,
 * useless for "what did this fridge do last Tuesday". This file is the
 * append-only record of EVERY reading, and it is what the office's
 * analysis view reads through /history.json.
 *
 * It is deliberately a flat JSONL file with an in-memory index: at pilot
 * volume (a few sensors, one reading per 5-15 min) that is thousands of
 * rows a month, which fits in memory with room to spare and needs no
 * database to install on a shop machine. Production swaps the storage for
 * a real time-series store WITHOUT changing the endpoint contract — that
 * is the point of putting the range/downsample/stats logic behind
 * /history.json rather than in the page.
 */
const HISTORY_FILE = dataFile("GUARDIAN_HISTORY_FILE", "guardian-pilot-history.jsonl");

/*
 * The failure modes a drill may be labeled with — the exact taxonomy of
 * docs/GUARDIAN_FAILURE_SIGNATURES.md. A strict list, not free text, because
 * a training set with "no evap fan", "evap_fan", and "fan dead" as three
 * different labels is a training set someone has to clean by hand later.
 */
const DRILL_MODES = [
  "door_open",          // door left open, one event
  "warm_air_cycling",   // door cycled on a cadence (heavy-use vs fault)
  "gasket_leak",        // taped pencil-gap in the seal
  "no_compressor",      // compressor/start components disabled
  "no_evap_fan",        // evaporator fan disconnected — the divergence drill
  "failed_defrost",     // defrost heater disabled, multi-day
  "condenser_blocked",  // condenser inlet blocked
  "damper_stuck",       // damper forced open or closed
  "power_loss",         // unit unplugged, sensor on battery
  "healthy_baseline"    // explicit healthy stretch between drills
];

/* ---- the one implementation of the rules, loaded, not copied ---------- */
const sandbox = { console: console };
sandbox.window = sandbox;
vm.createContext(sandbox);
["assets/plan-config.js", "assets/temp-monitoring.js"].forEach(function (f) {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), "utf8"), sandbox);
});
const SIM = sandbox.WILSON_TEMPWATCH_SIM;
const TM = sandbox.WILSON_CONFIG.tempMonitoring;
const RULES = TM.flagRules;
/* Burn-in window, battery thresholds and the pre-qualification pass
   criteria all come from config, never from a number typed here -- same
   rule as the flag thresholds. */
const COMMISSIONING = TM.commissioning || {};
const PREQUAL = TM.prequal || {};

/* Sensor kind -> the asset shape bandFor() resolves. */
const KIND_ASSET = {
  fresh_food: { type: "refrigerator", typeLabel: "Refrigerator" },
  freezer: { type: "freezer", typeLabel: "Freezer" },
  wine: { type: "wine_beverage", typeLabel: "Wine Storage" }
};

function loadJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch (e) { return fallback; }
}

const sensors = loadJson(SENSORS_FILE, REHEARSAL ? { sensors: [], customers: [] } : null);
if (!sensors || !Array.isArray(sensors.sensors)) {
  console.error("No " + SENSORS_FILE + " found (or it is not a sensor registry).");
  console.error("Copy tools/guardian-pilot-sensors.example.json there and fill in your channels.");
  process.exit(1);
}
if (!sensors.sensors.length && !REHEARSAL) {
  console.error(SENSORS_FILE + " lists no sensors.");
  console.error("Copy tools/guardian-pilot-sensors.example.json there and fill in your channels.");
  process.exit(1);
}

/*
 * CHANNEL IDS ARE CASE-INSENSITIVE.                              (v0.9.62)
 *
 * A DevEUI is hexadecimal, and the two places a human reads one disagree
 * about its case: ChirpStack's WEB UI displays A84041FFFF123456, while the
 * JSON it publishes to MQTT says a84041ffff123456 (its Rust EUI64 Display
 * impl is hex::encode, which is lowercase). Copying from the screen into
 * the registry therefore produced a registry that matched nothing, and the
 * only symptom was "unknown channel" on every single uplink -- a whole
 * evening's mystery for a shift key.
 *
 * So ids are canonicalized once, here, and every lookup goes through
 * findSensor(). UbiBot's numeric channel ids are unaffected.
 */
function canonicalChannel(id) {
  return String(id === null || id === undefined ? "" : id).trim().toLowerCase();
}

function findSensor(id) {
  const wanted = canonicalChannel(id);
  if (!wanted) return null;
  return sensors.sensors.find(function (s) { return canonicalChannel(s.channelId) === wanted; }) || null;
}

(function normalizeChannelIds() {
  let changed = 0;
  sensors.sensors.forEach(function (s) {
    const canonical = canonicalChannel(s.channelId);
    if (String(s.channelId) !== canonical) { s.channelId = canonical; changed += 1; }
    else { s.channelId = canonical; }
  });
  (sensors.customers || []).forEach(function (c) {
    c.channelIds = (c.channelIds || []).map(function (id) {
      const canonical = canonicalChannel(id);
      if (String(id) !== canonical) changed += 1;
      return canonical;
    });
  });
  if (changed) {
    /* Said out loud rather than fixed in silence: the operator should know
       their file has mixed-case ids, so the next hand edit matches. */
    console.log("Note: " + changed + " channel id(s) in " + path.basename(SENSORS_FILE) +
      " were upper- or mixed-case; matching is case-insensitive, so they were read as lowercase.");
  }
})();

sensors.sensors.forEach(function (s) {
  if (!KIND_ASSET[s.kind]) {
    console.error("Sensor " + s.channelId + " has kind '" + s.kind + "' — must be fresh_food, freezer or wine.");
    process.exit(1);
  }
});

/*
 * CUSTOMER ACCESS KEYS.                                           (v0.9.56)
 *
 * Cayden: "if they have a key they can access the tool on our site and
 * connect." The sensors file may carry a `customers` list:
 *
 *   "customers": [
 *     { "key": "<32+ random chars — openssl rand -hex 24>",
 *       "name": "The Davenport Residence",
 *       "channelIds": ["1001", "1002"] }
 *   ]
 *
 * GET /customer.json?key=<key> returns THAT customer's sensors only, in
 * customer-facing shape. Rules of the door:
 *   - the key is the whole credential, so it must be long and random —
 *     short keys are refused at STARTUP, not discovered at breach time;
 *   - a wrong key gets a bare 404, identical for "no such key" and
 *     "malformed key": nothing to enumerate;
 *   - the payload carries readings and plain-language status ONLY — no
 *     incident log, no drill state, no other household's existence, none
 *     of the internal reason strings.
 * Keys live in guardian-pilot-sensors.json, which is gitignored — the
 * same rule as every other credential in this project.
 */
if (!Array.isArray(sensors.customers)) sensors.customers = [];
const customers = sensors.customers;
/* Older registries predate ids; give every household one so the install
   endpoint can address them without guessing by name. */
customers.forEach(function (c) { if (!c.id) c.id = "cust_" + crypto.randomBytes(6).toString("hex"); });

function saveRegistry() {
  fs.writeFileSync(SENSORS_FILE, JSON.stringify(sensors, null, 2));
}
customers.forEach(function (c) {
  if (!c.key || String(c.key).length < 24) {
    console.error("Customer '" + (c.name || "?") + "' has a key shorter than 24 characters. Generate one with: openssl rand -hex 24");
    process.exit(1);
  }
  (c.channelIds || []).forEach(function (id) {
    if (!findSensor(id)) {
      console.error("Customer '" + (c.name || "?") + "' lists channel " + id + " which is not in the sensor list.");
      process.exit(1);
    }
  });
});

/* What the customer is told, per tier. Honest, plain, and free of the
   office's internal vocabulary. */
const CUSTOMER_STATUS = {
  ok: { code: "protected", label: "Protected", note: "Temperatures are holding where they should." },
  /* Burn-in is a real state with its own honest sentence. It deliberately
     does NOT say "Protected" -- during burn-in the sensor is not yet
     alerting, and telling a customer they are covered when they are not is
     the one claim this product cannot make. Copy lives in config. */
  burnin: {
    code: "settling",
    label: COMMISSIONING.customerLabel || "Getting settled",
    note: COMMISSIONING.customerNote || "This sensor was just installed and is settling into place."
  },
  warn: { code: "watching", label: "Watching closely", note: "A temperature is running warmer than usual. Most of these settle on their own — Wilson is watching it." },
  dispatch: { code: "responding", label: "Wilson alerted", note: "A sustained temperature problem was detected. Wilson has been alerted and is responding as a priority." },
  offline: { code: "offline", label: "Sensor offline", note: "The sensor has not reported recently — usually home WiFi or power. Wilson has been alerted. While offline it cannot warn anyone." },
  waiting: { code: "waiting", label: "Waiting for first reading", note: "This sensor has not sent its first reading yet." }
};

/* readings: { channelId: [{t: epochMs, value: number}] } newest last */
const store = loadJson(DATA_FILE, {});
/* lastTier per sensor so only TRANSITIONS become incidents. */
const lastTier = {};

/*
 * Drill state. { active: {channelId: {mode, note, startedAt}}, history: [...] }
 * Persisted so a server restart mid-drill (a several-day failed_defrost
 * drill WILL survive a reboot or two) does not lose the label.
 */
const drills = loadJson(DRILL_FILE, { active: {}, history: [] });
drills.active = drills.active || {};
drills.history = drills.history || [];

function saveDrills() {
  fs.writeFileSync(DRILL_FILE, JSON.stringify(drills, null, 2));
}

function activeDrill(channelId) {
  return drills.active[String(channelId)] || null;
}

/*
 * Labeled readings are ALSO appended to a durable training file the moment
 * they arrive. The live store prunes at KEEP_HOURS to stay small; a labeled
 * reading from day one of a five-day defrost drill must not be pruned with
 * it. The training file is append-only and never trimmed — it is the
 * dataset. (Trade secret: stays local, stays out of the repo — .gitignore.)
 */
const TRAINING_FILE = dataFile("GUARDIAN_TRAINING_FILE", "guardian-pilot-training.jsonl");

function appendTraining(channelId, epochMs, value, mode) {
  const sensor = findSensor(channelId);
  fs.appendFileSync(TRAINING_FILE, JSON.stringify({
    t: new Date(epochMs).toISOString(),
    channelId: String(channelId),
    label: sensor ? (sensor.label || sensor.channelId) : String(channelId),
    kind: sensor ? sensor.kind : "",
    f: value,
    mode: mode
  }) + "\n");
}

function saveStore() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(store));
}

/*
 * history: { channelId: [{t, f, b?, r?, s?}] } ascending by time, every
 * reading ever.
 *
 * BATTERY AND RADIO RIDE ON THE ROW.                             (v0.9.62)
 *
 * `b` volts, `r` RSSI, `s` SNR -- all optional, all absent on a UbiBot
 * reading and on every row written before this version. They live on the
 * reading rather than in a table of their own for one reason: the two
 * questions the RF pre-qualification test asks ("did the packets get out of
 * the stainless column" and "did the battery hold for a week") are answered
 * by the SAME rows the temperature chart is drawn from, so /history.csv is
 * the whole instrument and there is nothing to join.
 */
const history = {};
(function loadHistory() {
  let text = "";
  try { text = fs.readFileSync(HISTORY_FILE, "utf8"); } catch (e) { return; }
  text.split("\n").forEach(function (line) {
    if (!line) return;
    try {
      const row = JSON.parse(line);
      if (!row || !row.c || !Number.isFinite(row.t) || !Number.isFinite(row.f)) return;
      const kept = { t: row.t, f: row.f };
      if (Number.isFinite(row.b)) kept.b = row.b;
      if (Number.isFinite(row.r)) kept.r = row.r;
      if (Number.isFinite(row.s)) kept.s = row.s;
      (history[canonicalChannel(row.c)] = history[canonicalChannel(row.c)] || []).push(kept);
    } catch (e) { /* a torn line from a crash mid-append; skip it */ }
  });
  Object.keys(history).forEach(function (c) {
    history[c].sort(function (a, b) { return a.t - b.t; });
  });
})();

function recordHistory(channelId, epochMs, value, meta) {
  const key = canonicalChannel(channelId);
  const rows = history[key] = history[key] || [];
  const row = { t: epochMs, f: value };
  if (meta && Number.isFinite(Number(meta.batteryVolts))) row.b = Number(meta.batteryVolts);
  if (meta && Number.isFinite(Number(meta.rssi))) row.r = Number(meta.rssi);
  if (meta && Number.isFinite(Number(meta.snr))) row.s = Number(meta.snr);
  /* Same-timestamp readings are duplicates, not new information. */
  if (rows.length && rows[rows.length - 1].t === epochMs) return;
  if (rows.length && epochMs < rows[rows.length - 1].t) {
    if (rows.some(function (r) { return r.t === epochMs; })) return;
    rows.push(row);
    rows.sort(function (a, b) { return a.t - b.t; });
  } else {
    rows.push(row);
  }
  fs.appendFileSync(HISTORY_FILE, JSON.stringify(Object.assign({ c: key }, row)) + "\n");
}

/*
 * SENSOR HEALTH, latest-known, in memory.
 *
 * Rebuilt from history at boot rather than persisted separately -- one
 * source of truth, and a file that cannot go stale against it. `status` is
 * the decoder's own battery label, carried verbatim for a human to read:
 * Dragino changed its type between decoder versions (a 0-3 number, then a
 * "Good"/"OK"/"Low" string), so nothing branches on it.
 */
const health = {};
const HEALTH_FIELDS = ["batteryVolts", "batteryStatus", "rssi", "snr", "dr"];

function noteHealth(channelId, epochMs, meta) {
  if (!meta) return;
  /*
   * An empty meta is not health information, and must not stamp a
   * timestamp -- a UbiBot reading (which carries no battery or radio at
   * all) would otherwise mark the sensor as "known good as of now" and
   * then, being the newest stamp, suppress the next real LoRa reading's
   * battery voltage as stale. QA caught exactly that.
   */
  const carries = HEALTH_FIELDS.some(function (field) {
    const value = meta[field];
    return value !== null && value !== undefined && value !== "";
  });
  if (!carries) return;
  const key = canonicalChannel(channelId);
  const current = health[key] || {};
  if (current.at && current.at > epochMs) return; /* an older backfill row */
  const next = { at: epochMs };
  HEALTH_FIELDS.forEach(function (field) {
    const value = meta[field];
    if (value !== null && value !== undefined && value !== "") next[field] = value;
    else if (current[field] !== undefined) next[field] = current[field];
  });
  health[key] = next;
}
Object.keys(history).forEach(function (key) {
  /* Newest row that actually carried radio/battery numbers wins. */
  for (let i = history[key].length - 1; i >= 0; i -= 1) {
    const row = history[key][i];
    if (row.b === undefined && row.r === undefined && row.s === undefined) continue;
    noteHealth(key, row.t, { batteryVolts: row.b, rssi: row.r, snr: row.s });
    break;
  }
});

/*
 * DOWNSAMPLING THAT CANNOT HIDE A SPIKE.
 *
 * A chart of six months cannot draw 50,000 points, but "every Nth reading"
 * is the wrong way to thin them: the one 52°F reading that IS the story
 * has an (N-1)/N chance of being the one dropped. So each bucket
 * contributes its MINIMUM and its MAXIMUM, in the order they occurred —
 * the envelope survives at any zoom, and the eye never sees a smooth line
 * where there was an excursion.
 *
 * Statistics are never computed from this: /history.json summarizes the
 * FULL-resolution rows, so the max the chart shows and the max the stats
 * report are the same number at every zoom level.
 */
function downsample(rows, maxPoints) {
  const cap = Math.max(50, Number(maxPoints) || 1200);
  if (rows.length <= cap) return rows.slice();
  /* Two slots are reserved for the window's own first and last readings
     (added below), so the returned count never exceeds the cap the caller
     asked for — a maxPoints that can be quietly exceeded is not a max. */
  const buckets = Math.max(1, Math.floor((cap - 2) / 2));
  const span = rows.length / buckets;
  const out = [];
  for (let b = 0; b < buckets; b += 1) {
    const start = Math.floor(b * span);
    const end = Math.min(rows.length, Math.floor((b + 1) * span));
    if (end <= start) continue;
    let lo = rows[start], hi = rows[start];
    for (let i = start; i < end; i += 1) {
      if (rows[i].f < lo.f) lo = rows[i];
      if (rows[i].f > hi.f) hi = rows[i];
    }
    if (lo.t <= hi.t) { out.push(lo); if (hi !== lo) out.push(hi); }
    else { out.push(hi); out.push(lo); }
  }
  /* The window's own edges always survive, so the line starts and ends
     where the reader asked it to. */
  if (out.length && out[0].t !== rows[0].t) out.unshift(rows[0]);
  if (out.length && out[out.length - 1].t !== rows[rows.length - 1].t) out.push(rows[rows.length - 1]);
  return out;
}

/*
 * The window's numbers, over FULL resolution. Excursion counting comes
 * from the product's own summarize() — one implementation, so the
 * analysis view, the hub and the customer's report can never disagree
 * about how many times a fridge went out of band.
 */
function windowStats(rows, rule, to) {
  if (!rows.length) return null;
  const asPoints = rows.map(function (r) {
    return { minutesAgo: Math.max(0, Math.round((to - r.t) / 60000)), value: r.f };
  });
  const base = SIM.summarize(asPoints, rule) || {};
  let lo = rows[0], hi = rows[0], sum = 0;
  let overWarn = 0, overDispatch = 0;
  for (let i = 0; i < rows.length; i += 1) {
    const r = rows[i];
    if (r.f < lo.f) lo = r;
    if (r.f > hi.f) hi = r;
    sum += r.f;
    /* Time above a line is measured by the gap each reading REPRESENTS —
       the span to the next reading — so a 5-minute cadence and a 15-minute
       cadence report the same hours, not three times the readings. */
    if (i < rows.length - 1) {
      const minutes = Math.min(60, (rows[i + 1].t - r.t) / 60000);
      if (rule && rule.maxF !== undefined && r.f > rule.maxF) overWarn += minutes;
      if (rule && rule.dispatchF !== undefined && r.f > rule.dispatchF) overDispatch += minutes;
    }
  }
  return {
    readings: rows.length,
    min: Math.round(lo.f * 10) / 10, minAt: new Date(lo.t).toISOString(),
    max: Math.round(hi.f * 10) / 10, maxAt: new Date(hi.t).toISOString(),
    avg: Math.round((sum / rows.length) * 10) / 10,
    inBandPct: base.inBandPct !== undefined ? base.inBandPct : null,
    excursions: base.excursions || 0,
    longestExcursionMinutes: base.longestMinutes || base.longest || 0,
    overWarnMinutes: Math.round(overWarn),
    overDispatchMinutes: Math.round(overDispatch),
    firstAt: new Date(rows[0].t).toISOString(),
    lastAt: new Date(rows[rows.length - 1].t).toISOString()
  };
}

function historyRange(channelId, from, to) {
  const rows = history[canonicalChannel(channelId)] || [];
  return rows.filter(function (r) { return r.t >= from && r.t <= to; });
}

function median(values) {
  if (!values.length) return null;
  const sorted = values.slice().sort(function (a, b) { return a - b; });
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : Math.round(((sorted[mid - 1] + sorted[mid]) / 2) * 10) / 10;
}

/*
 * THE RF PRE-QUALIFICATION REPORT.                               (v0.9.62)
 *
 * One sensor, one week, inside the worst stainless column on the showroom
 * floor, with the gateway roughly where a customer's would live. This turns
 * that week into the three numbers the go/no-go decision is actually made
 * on, computed from the same history rows the charts draw.
 *
 * The criteria come from config (tempMonitoring.prequal) rather than from
 * here, so the bar is written down BEFORE the result is known and nobody
 * gets to relitigate it after seeing a marginal week.
 *
 * WHAT EACH NUMBER MEANS, and why it is the one that matters:
 *
 *   LONGEST GAP is the hard criterion. The shortest dispatch window in the
 *   product is fresh food -- 45°F sustained for 60 minutes -- so a radio
 *   gap longer than that can hide the exact event Guardian is sold to
 *   catch. There is no tolerance on this one.
 *
 *   DELIVERY RATIO is the soft one, because every rule fires on SUSTAINED
 *   conditions rather than a single reading: scattered loss is survivable,
 *   and clustered loss is what the gap criterion catches instead.
 *
 *   BATTERY DRIFT over the week is the third question the test answers for
 *   free. Cold plus a high spreading factor is where a ten-year cell
 *   claim goes to die, and a column that only gets packets out at SF12
 *   will eat it.
 *
 * HONESTY ABOUT THE DENOMINATOR: `deliveryPct` is only as good as
 * `expectedIntervalMinutes` matching the sensor's actual reporting
 * interval (Dragino's TDC setting). So the observed median interval is
 * reported beside it -- if those two disagree, the ratio is measuring the
 * config's guess, not the radio, and the report says so rather than
 * quietly grading against the wrong number.
 */
function prequalReport(sensor, from, to) {
  const rows = historyRange(sensor.channelId, from, to);
  const minutes = Math.max(1, (to - from) / 60000);
  const interval = Number(PREQUAL.expectedIntervalMinutes) > 0 ? Number(PREQUAL.expectedIntervalMinutes) : 20;
  const minDeliveryPct = Number(PREQUAL.minDeliveryPct) >= 0 ? Number(PREQUAL.minDeliveryPct) : 90;
  const maxGapMinutes = Number(PREQUAL.maxGapMinutes) > 0 ? Number(PREQUAL.maxGapMinutes) : 60;
  const minDays = Number(PREQUAL.minDays) > 0 ? Number(PREQUAL.minDays) : 7;

  if (rows.length < 2) {
    return {
      channel: sensor.channelId, label: sensor.label || sensor.channelId, kind: sensor.kind,
      from: new Date(from).toISOString(), to: new Date(to).toISOString(),
      criteria: { minDeliveryPct: minDeliveryPct, maxGapMinutes: maxGapMinutes, minDays: minDays,
                  expectedIntervalMinutes: interval },
      readings: rows.length,
      verdict: "no data",
      note: "Fewer than two readings in this window — nothing to measure yet."
    };
  }

  /*
   * Gaps are measured BETWEEN readings, plus the two edges of the window:
   * a sensor that went silent for the last three hours of the test has a
   * three-hour gap even though no reading marks its end. Leaving the edges
   * out is how a test passes while the sensor is dead.
   */
  const gaps = [];
  for (let i = 1; i < rows.length; i += 1) {
    gaps.push({ minutes: (rows[i].t - rows[i - 1].t) / 60000, at: new Date(rows[i - 1].t).toISOString() });
  }
  const leadIn = (rows[0].t - from) / 60000;
  const trailing = (to - rows[rows.length - 1].t) / 60000;
  if (leadIn > interval) gaps.push({ minutes: leadIn, at: new Date(from).toISOString(), edge: "start of window" });
  if (trailing > interval) gaps.push({ minutes: trailing, at: new Date(rows[rows.length - 1].t).toISOString(), edge: "still silent at end of window" });

  const longest = gaps.reduce(function (worst, g) { return !worst || g.minutes > worst.minutes ? g : worst; }, null);
  const breaches = gaps.filter(function (g) { return g.minutes > maxGapMinutes; })
    .sort(function (a, b) { return b.minutes - a.minutes; });

  const expected = Math.max(1, Math.round(minutes / interval));
  /* Capped at 100: a sensor reporting FASTER than the configured interval
     is not 140% reliable, it is differently configured -- and the observed
     median interval below is where that shows up. */
  const deliveryPct = Math.min(100, Math.round((rows.length / expected) * 1000) / 10);

  const rssiValues = rows.filter(function (r) { return Number.isFinite(r.r); }).map(function (r) { return r.r; });
  const snrValues = rows.filter(function (r) { return Number.isFinite(r.s); }).map(function (r) { return r.s; });
  const batteryValues = rows.filter(function (r) { return Number.isFinite(r.b); });
  const weakRssi = Number(PREQUAL.weakRssi);
  const weakSnr = Number(PREQUAL.weakSnr);

  const observedIntervals = [];
  for (let i = 1; i < rows.length; i += 1) observedIntervals.push((rows[i].t - rows[i - 1].t) / 60000);
  const observedMedian = median(observedIntervals);

  const coverageDays = Math.round(((rows[rows.length - 1].t - rows[0].t) / 86400000) * 10) / 10;
  const deliveryPass = deliveryPct >= minDeliveryPct;
  const gapPass = !longest || longest.minutes <= maxGapMinutes;
  const longEnough = coverageDays >= minDays;

  const firstBattery = batteryValues.length ? batteryValues[0].b : null;
  const lastBattery = batteryValues.length ? batteryValues[batteryValues.length - 1].b : null;
  const batteryState = SIM.batteryState(lastBattery);

  return {
    channel: sensor.channelId,
    label: sensor.label || sensor.channelId,
    kind: sensor.kind,
    from: new Date(from).toISOString(),
    to: new Date(to).toISOString(),
    criteria: { minDeliveryPct: minDeliveryPct, maxGapMinutes: maxGapMinutes, minDays: minDays,
                expectedIntervalMinutes: interval, weakRssi: Number.isFinite(weakRssi) ? weakRssi : null,
                weakSnr: Number.isFinite(weakSnr) ? weakSnr : null },
    readings: rows.length,
    expectedReadings: expected,
    deliveryPct: deliveryPct,
    observedMedianIntervalMinutes: observedMedian,
    intervalMatchesConfig: observedMedian === null ? null : Math.abs(observedMedian - interval) <= Math.max(2, interval * 0.25),
    coverageDays: coverageDays,
    longestGapMinutes: longest ? Math.round(longest.minutes) : 0,
    longestGapAt: longest ? longest.at : null,
    gapsOverLimit: breaches.slice(0, 10).map(function (g) {
      return { minutes: Math.round(g.minutes), at: g.at, edge: g.edge || null };
    }),
    gapsOverLimitCount: breaches.length,
    rssi: rssiValues.length
      ? { min: Math.min.apply(null, rssiValues), median: median(rssiValues), max: Math.max.apply(null, rssiValues),
          weakPct: Number.isFinite(weakRssi)
            ? Math.round((rssiValues.filter(function (v) { return v <= weakRssi; }).length / rssiValues.length) * 1000) / 10
            : null }
      : null,
    snr: snrValues.length
      ? { min: Math.min.apply(null, snrValues), median: median(snrValues), max: Math.max.apply(null, snrValues),
          weakPct: Number.isFinite(weakSnr)
            ? Math.round((snrValues.filter(function (v) { return v <= weakSnr; }).length / snrValues.length) * 1000) / 10
            : null }
      : null,
    battery: { first: firstBattery, last: lastBattery,
               deltaVolts: firstBattery !== null && lastBattery !== null
                 ? Math.round((lastBattery - firstBattery) * 1000) / 1000 : null,
               level: batteryState.level },
    checks: {
      delivery: { pass: deliveryPass, got: deliveryPct, want: ">= " + minDeliveryPct + "%" },
      gap: { pass: gapPass, got: longest ? Math.round(longest.minutes) : 0, want: "<= " + maxGapMinutes + " min" },
      duration: { pass: longEnough, got: coverageDays, want: ">= " + minDays + " days" }
    },
    /*
     * A failing criterion is a FAIL even before the week is up -- an hour
     * of silence on day two has already answered the question, and waiting
     * five more days to say so wastes five days. A clean but short run is
     * "running", never "pass": the bar includes the duration.
     */
    verdict: (!deliveryPass || !gapPass) ? "fail" : longEnough ? "pass" : "running",
    note: PREQUAL.note || ""
  };
}

function record(channelId, epochMs, value, meta) {
  if (!Number.isFinite(epochMs) || !Number.isFinite(value)) return;
  channelId = canonicalChannel(channelId);
  const rows = store[channelId] = store[channelId] || [];
  if (rows.length && epochMs <= rows[rows.length - 1].t) {
    /* Backfill or duplicate: insert in order, drop exact-time repeats. */
    if (rows.some(function (r) { return r.t === epochMs; })) return;
    rows.push({ t: epochMs, value: value });
    rows.sort(function (a, b) { return a.t - b.t; });
  } else {
    rows.push({ t: epochMs, value: value });
  }
  /* Accepted (not a duplicate): it belongs in the permanent record before
     anything else — the 48h store is a working window, history is the
     archive the analysis view reads. */
  recordHistory(channelId, epochMs, value, meta);
  noteHealth(channelId, epochMs, meta);
  /* And if a drill is running on this channel, the reading also goes to
     the durable training file with the drill's label. */
  const drill = activeDrill(channelId);
  if (drill && epochMs >= drill.startedAt) {
    appendTraining(channelId, epochMs, value, drill.mode);
  }
  const cutoff = Date.now() - KEEP_HOURS * 3600000;
  while (rows.length && rows[0].t < cutoff) rows.shift();
}

/* ---- evaluation --------------------------------------------------------- */
function pointsFor(channelId, now) {
  return (store[channelId] || []).map(function (r) {
    return { minutesAgo: Math.max(0, Math.round((now - r.t) / 60000)), value: r.value };
  });
}

const startedAt = Date.now();

function evaluateSensor(sensor, now) {
  const rows = store[sensor.channelId] || [];
  const latest = rows.length ? rows[rows.length - 1] : null;
  const silentMinutes = latest ? Math.round((now - latest.t) / 60000) : null;
  const offlineHold = Number((RULES.offline || {}).holdMinutes || 180);
  /* A sensor that has NEVER reported gets the same hold measured from server
     start -- so booting the server does not page the office about six
     sensors that simply have not been screwed to a fridge yet. Until then it
     reads WAITING, which is a state, not an incident. */
  const offline = latest
    ? silentMinutes >= offlineHold
    : (now - startedAt) / 60000 >= offlineHold;
  const waiting = !latest && !offline;
  const flag = SIM.evaluateFlags(KIND_ASSET[sensor.kind], pointsFor(sensor.channelId, now));
  const stats = SIM.summarize(pointsFor(sensor.channelId, now), flag.rule);
  /* The dashboard's Guardian module charts each sensor, so status.json
     carries the recent series -- downsampled to ~96 points (a 48h window
     at 30-min steps) to keep the payload phone-friendly. */
  const allPoints = pointsFor(sensor.channelId, now);
  const step = Math.max(1, Math.ceil(allPoints.length / 96));
  const points = allPoints.filter(function (p, i) { return i % step === 0 || i === allPoints.length - 1; });
  /*
   * BURN-IN OUTRANKS EVERY FLAG, AND OUTRANKS NOTHING ELSE.       (v0.9.62)
   *
   * A sensor installed twenty minutes ago is at room temperature in a
   * glycol vial that has not equilibrated. It WILL read over the line and
   * the warning rule WILL be right to say so -- and paging the office
   * about it would make the very first thing Guardian ever does a false
   * alarm. So during the burn-in window the tier reads `burnin`: nothing
   * in ALERT_TIERS, so no incident, no customer notification, no case
   * opened, and the customer's page says "settling in" rather than
   * "Protected".
   *
   * Two deliberate exceptions, both because they are not false alarms:
   *   - OFFLINE still wins. A sensor that joined and then went silent for
   *     three hours is a failed install, and a failed install that stays
   *     quiet for a day is a customer paying for nothing.
   *   - WAITING still wins. "No readings yet" is more useful to the
   *     installer standing at the fridge than a burn-in countdown on a
   *     sensor that has never spoken.
   *
   * `underlyingTier` carries what the rules DID say, so the office is
   * never blind -- suppressing the page is not the same as hiding the
   * number, and an installer who sees `warn` under a burn-in badge knows
   * to wait and watch it fall rather than drive away.
   */
  const commissioning = SIM.commissioningState(sensor.installedAt, now);
  const ruleTier = flag.tier || "ok";
  const burningIn = commissioning.burningIn && !offline && !waiting;
  const battery = SIM.batteryState((health[canonicalChannel(sensor.channelId)] || {}).batteryVolts);
  const radioHealth = health[canonicalChannel(sensor.channelId)] || null;
  return {
    points: points,
    channelId: sensor.channelId,
    label: sensor.label || sensor.channelId,
    kind: sensor.kind,
    latest: latest ? latest.value : null,
    latestAt: latest ? new Date(latest.t).toISOString() : null,
    silentMinutes: silentMinutes,
    offline: offline,
    tier: offline ? "offline" : waiting ? "waiting" : burningIn ? "burnin" : ruleTier,
    underlyingTier: ruleTier,
    reason: offline
      ? (latest ? "no reading for " + silentMinutes + " min" : "never reported")
      : waiting ? "no readings yet"
      : burningIn
        ? (COMMISSIONING.officeNote || "settling in after install") +
          " " + commissioning.hoursLeft + "h left" +
          (ruleTier !== "ok" ? " (rules would say: " + ruleTier + ")" : "")
      : (flag.reason || ""),
    overForMinutes: flag.overForMinutes || 0,
    readings: rows.length,
    stats: stats,
    commissioning: commissioning,
    battery: battery,
    radio: radioHealth
      ? { rssi: radioHealth.rssi === undefined ? null : radioHealth.rssi,
          snr: radioHealth.snr === undefined ? null : radioHealth.snr,
          dr: radioHealth.dr === undefined ? null : radioHealth.dr,
          at: new Date(radioHealth.at).toISOString() }
      : null
  };
}

function incident(row) {
  const drill = activeDrill(row.channelId);
  const line = {
    at: new Date().toISOString(),
    channelId: row.channelId, label: row.label, kind: row.kind,
    tier: row.tier, reason: row.reason, latest: row.latest
  };
  /* A rehearsal incident must never be mistaken later for a real one. */
  if (REHEARSAL) line.rehearsal = true;
  /* An incident during a drill is the drill's detection event — stamp it so
     the drill sheet reads detection latency straight off the log. */
  if (drill) line.drill = drill.mode;
  fs.appendFileSync(INCIDENT_FILE, JSON.stringify(line) + "\n");
  const text = "[GUARDIAN " + row.tier.toUpperCase() + "] " + row.label + " (" + row.kind + "): " +
    row.reason + (row.latest !== null ? " — latest " + row.latest + "°F" : "") +
    (drill ? " [drill: " + drill.mode + "]" : "");
  console.log(new Date().toISOString() + "  " + text);
  postOfficeWebhook(text);
}

/* One implementation of "make the office phone buzz", shared by flag
   incidents and battery notices. */
function postOfficeWebhook(text) {
  const hook = process.env.ALERT_WEBHOOK_URL;
  if (!hook) return;
  try {
    const url = new URL(hook);
    const body = JSON.stringify({ text: text });
    const req = (url.protocol === "https:" ? https : http).request(url, {
      method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) }
    }, function () {});
    req.on("error", function (err) { console.error("alert webhook failed: " + err.message); });
    req.end(body);
  } catch (e) { console.error("bad ALERT_WEBHOOK_URL: " + e.message); }
}

/*
 * BATTERY NOTICES.                                               (v0.9.62)
 *
 * A flat cell is an offline sensor with an explanation, and the difference
 * between those two sentences is a truck roll. This is deliberately NOT a
 * tier: the tier ladder maps onto what a CUSTOMER is told, and "your
 * sensor needs a battery" is Wilson's errand, not the customer's alarm.
 * So it logs to the incident file and the office webhook, and never
 * touches notifyCustomer.
 *
 * Fires on a level CROSSING, once -- ok -> replace -> critical. Without
 * that, a sensor sitting at 2.59 V would announce itself on every uplink
 * for the six weeks before anyone drove out, which is how an alert
 * channel gets muted.
 */
const lastBatteryLevel = {};

function checkBattery(sensor) {
  const key = canonicalChannel(sensor.channelId);
  const state = SIM.batteryState((health[key] || {}).batteryVolts);
  if (!state.known) return;
  const previous = lastBatteryLevel[key];
  if (previous === state.level) return;
  lastBatteryLevel[key] = state.level;
  if (state.level === "ok") return; /* a fresh cell is not news */
  const label = sensor.label || sensor.channelId;
  const line = {
    at: new Date().toISOString(),
    channelId: sensor.channelId, label: label, kind: sensor.kind,
    tier: "battery", level: state.level,
    reason: state.note, volts: state.volts
  };
  fs.appendFileSync(INCIDENT_FILE, JSON.stringify(line) + "\n");
  const text = "[GUARDIAN BATTERY " + state.level.toUpperCase() + "] " + label +
    " — " + state.volts + "V. " + state.note;
  console.log(new Date().toISOString() + "  " + text);
  postOfficeWebhook(text);
}

const ALERT_TIERS = { warn: true, dispatch: true, offline: true };

function evaluateAll() {
  const now = Date.now();
  sensors.sensors.forEach(function (sensor) {
    const row = evaluateSensor(sensor, now);
    const previous = lastTier[sensor.channelId] || "waiting";
    if (row.tier === previous) return;
    lastTier[sensor.channelId] = row.tier;
    /* Alert tiers log on entry; a return to OK logs as a recovery so the
       drill sheet can time how long a door event takes to clear. The
       waiting->ok first-data transition is nobody's incident. */
    if (ALERT_TIERS[row.tier]) {
      incident(row);
      notifyCustomer(row);
    } else if (row.tier === "ok" && ALERT_TIERS[previous]) {
      incident(Object.assign({}, row, { reason: "recovered — back in band (was " + previous + ")" }));
      /* The all-clear only follows an alert the customer HEARD about. */
      if (previous === "dispatch" || previous === "offline") notifyCustomer(row);
    }
  });
}

/* ---- UbiBot payload parsing --------------------------------------------- */
/*
 * Data-forwarding POST shape (per UbiBot platform docs): channel_id at the
 * top plus a feeds[] array of {created_at, field1: {...} | number, ...}.
 * Field values arrive either as bare numbers or as {value: n} objects, and
 * external probes ride field7-field10 (field1 is onboard temp) -- the sensor
 * file says which field to trust for each channel.
 */
function isSynthetic(channelId) {
  return canonicalChannel(channelId).indexOf(SYNTHETIC_PREFIX) === 0;
}

function ingestForwarding(payload) {
  const channelId = canonicalChannel(payload.channel_id || payload.channelId);
  /*
   * The structural guard. A synthetic reading reaching a production
   * archive is not a cosmetic problem: it would sit in the training file
   * beside real drill labels and there would be no way, later, to tell
   * which correlations were learned from a fridge and which from a
   * JavaScript sine wave.
   */
  if (isSynthetic(channelId) && !REHEARSAL) {
    return { ok: false, message: "channel " + channelId + " uses the reserved synthetic prefix '" +
      SYNTHETIC_PREFIX + "'. This server is not in rehearsal mode, so it will not store invented readings. " +
      "Restart it with GUARDIAN_REHEARSAL=1 (which also sandboxes every data file under rehearsal/)." };
  }
  const sensor = findSensor(channelId);
  if (!sensor) return { ok: false, message: "unknown channel " + channelId };
  const field = sensor.field || "field1";
  /*
   * The LoRa bridge adds two optional siblings to the UbiBot shape:
   * `battery` {volts, status} off the decoder and `radio` {rssi, snr, dr}
   * off ChirpStack's gateway metadata. A UbiBot forward carries neither,
   * so both radios share one endpoint and one set of rules. Every field
   * is read defensively -- Ext=9 mode omits BatV entirely, and a
   * single-gateway uplink can arrive with no SNR at all.
   */
  const battery = payload.battery && typeof payload.battery === "object" ? payload.battery : {};
  const radio = payload.radio && typeof payload.radio === "object" ? payload.radio : {};
  const meta = {
    batteryVolts: Number.isFinite(Number(battery.volts)) ? Number(battery.volts) : null,
    batteryStatus: battery.status === null || battery.status === undefined ? null : String(battery.status),
    rssi: Number.isFinite(Number(radio.rssi)) ? Number(radio.rssi) : null,
    snr: Number.isFinite(Number(radio.snr)) ? Number(radio.snr) : null,
    dr: Number.isFinite(Number(radio.dr)) ? Number(radio.dr) : null
  };
  let taken = 0;
  (payload.feeds || []).forEach(function (feed) {
    const raw = feed[field];
    const value = raw && typeof raw === "object" ? Number(raw.value) : Number(raw);
    const t = Date.parse(feed.created_at || feed.createdAt || "");
    let f = value;
    /* UbiBot reports Celsius by default; the rules speak Fahrenheit. The
       sensor file says which unit the channel sends. */
    if ((sensor.unit || "C").toUpperCase() === "C") f = value * 9 / 5 + 32;
    if (Number.isFinite(t) && Number.isFinite(f)) { record(channelId, t, Math.round(f * 10) / 10, meta); taken += 1; }
  });
  if (taken) { saveStore(); checkBattery(sensor); }
  return { ok: true, taken: taken };
}

/* ---- optional REST poller (small pilots; respects account limits) ------- */
function pollOnce() {
  const key = process.env.UBIBOT_ACCOUNT_KEY;
  if (!key) { console.error("--poll needs UBIBOT_ACCOUNT_KEY in the environment."); process.exit(1); }
  https.get("https://webapi.ubibot.com/channels?account_key=" + encodeURIComponent(key), function (res) {
    let body = "";
    res.on("data", function (c) { body += c; });
    res.on("end", function () {
      try {
        const parsed = JSON.parse(body);
        (parsed.channels || []).forEach(function (channel) {
          const sensor = findSensor(channel.channel_id);
          if (!sensor) return;
          const lastValues = JSON.parse(channel.last_values || "{}");
          const field = lastValues[sensor.field || "field1"];
          if (!field) return;
          const value = Number(field.value);
          const t = Date.parse(field.created_at || channel.last_entry_date || "");
          let f = value;
          if ((sensor.unit || "C").toUpperCase() === "C") f = value * 9 / 5 + 32;
          if (Number.isFinite(t) && Number.isFinite(f)) record(sensor.channelId, t, Math.round(f * 10) / 10);
        });
        saveStore();
      } catch (e) { console.error("poll parse failed: " + e.message); }
    });
  }).on("error", function (err) { console.error("poll failed: " + err.message); });
}

/* ---- status page --------------------------------------------------------- */
function statusRows() {
  const now = Date.now();
  return sensors.sensors.map(function (s) { return evaluateSensor(s, now); });
}

function lastIncidents(limit) {
  try {
    const lines = fs.readFileSync(INCIDENT_FILE, "utf8").trim().split("\n");
    return lines.slice(-limit).reverse().map(function (l) { return JSON.parse(l); });
  } catch (e) { return []; }
}

function esc(t) { return String(t == null ? "" : t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

function statusPage() {
  const rows = statusRows();
  const tierColor = { ok: "#2e7d43", warn: "#8b5d00", dispatch: "#a03030", offline: "#555", waiting: "#888", burnin: "#4a5f8a", battery: "#8b5d00" };
  return "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
    "<title>Guardian Pilot</title>" +
    "<style>body{font:14px/1.5 -apple-system,Segoe UI,sans-serif;margin:24px;color:#222;background:#fafaf8}" +
    "table{border-collapse:collapse;width:100%;margin:12px 0}td,th{border-bottom:1px solid #ddd;padding:8px 10px;text-align:left;font-size:13px}" +
    "th{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#666}.tier{font-weight:700}</style>" +
    "<h1>Wilson Guardian — pilot</h1>" +
    "<p>Live readings judged by the SAME flag rules the product ships (plan-config flagRules via temp-monitoring.js). " +
    "Rules: fresh food warn &gt;" + RULES.fresh_food.maxF + "°F/" + RULES.fresh_food.holdMinutes + "m, dispatch &gt;" + RULES.fresh_food.dispatchF + "°F/" + RULES.fresh_food.dispatchHoldMinutes + "m or no recovery in " + RULES.fresh_food.recoverWithinMinutes + "m; offline " + RULES.offline.holdMinutes + "m.</p>" +
    "<table><tr><th>Sensor</th><th>Kind</th><th>Latest</th><th>Seen</th><th>Tier</th><th>Why</th><th>Over for</th><th>48h avg / in-band</th><th>Radio / battery</th><th>Readings</th><th>Drill</th></tr>" +
    rows.map(function (r) {
      const drill = activeDrill(r.channelId);
      /* Radio and battery in one cell: on hardware week these are the two
         numbers being watched, and they are read together or not at all. */
      const radioCell = [
        r.radio && r.radio.rssi !== null ? "rssi " + r.radio.rssi : "",
        r.radio && r.radio.snr !== null ? "snr " + r.radio.snr : "",
        r.battery && r.battery.known
          ? (r.battery.level === "ok" ? r.battery.volts + "V"
            : "<strong style='color:" + tierColor.battery + "'>" + r.battery.volts + "V " + r.battery.level + "</strong>")
          : ""
      ].filter(Boolean).join(" · ") || "—";
      return "<tr><td>" + esc(r.label) + "</td><td>" + esc(r.kind) + "</td><td>" + (r.latest === null ? "—" : r.latest + "°F") + "</td>" +
        "<td>" + (r.silentMinutes === null ? "never" : r.silentMinutes + "m ago") + "</td>" +
        "<td class='tier' style='color:" + tierColor[r.tier] + "'>" + esc(r.tier.toUpperCase()) + "</td>" +
        "<td>" + esc(r.reason) + "</td><td>" + (r.overForMinutes ? Math.round(r.overForMinutes / 6) / 10 + "h" : "—") + "</td>" +
        "<td>" + (r.stats ? r.stats.avg + "°F / " + (r.stats.inBandPct === null ? "—" : r.stats.inBandPct + "%") : "—") + "</td>" +
        "<td>" + radioCell + "</td>" +
        "<td>" + r.readings + "</td>" +
        "<td>" + (drill ? "<strong style='color:#8b3fa8'>" + esc(drill.mode) + "</strong>" : "—") + "</td></tr>";
    }).join("") + "</table>" +
    "<p style='font-size:12px;color:#666'>A freshly installed sensor reads <strong style='color:" + tierColor.burnin + "'>BURNIN</strong> for " +
    esc(COMMISSIONING.hours || 24) + "h: it charts and the office can watch it, but it does not alert, does not open a case, " +
    "and the customer's page says &ldquo;" + esc(COMMISSIONING.customerLabel || "Getting settled") + "&rdquo; rather than Protected. " +
    "RF pre-qualification numbers: <code>/prequal.json</code>.</p>" +
    "<p style='font-size:12px;color:#666'>Drill labeling: <code>POST /drill {\"channelId\",\"mode\"}</code> before inducing a failure, " +
    "<code>POST /drill/end</code> after full recovery. Labeled dataset at <code>/export.jsonl</code> and <code>/export.csv</code> — " +
    "in-house training data, never shared. Modes: " + DRILL_MODES.join(", ") + ".</p>" +
    "<h2>Incident log (newest first)</h2><table><tr><th>When</th><th>Sensor</th><th>Tier</th><th>Why</th></tr>" +
    lastIncidents(40).map(function (i) {
      return "<tr><td>" + esc(i.at) + "</td><td>" + esc(i.label) + "</td><td class='tier' style='color:" + (tierColor[i.tier] || "#333") + "'>" + esc(i.tier.toUpperCase()) + "</td><td>" + esc(i.reason) + "</td></tr>";
    }).join("") + "</table>" +
    "<p style='color:#888;font-size:12px'>Refreshes on load. Bound to " + esc(HOST) + " — keep it off public networks.</p>";
}

/*
 * THE INSTALL DESK.                                              (v0.9.59)
 *
 * The step that used to be "hand-edit the registry on the shop machine":
 * one call binds a sensor (the DevEUI off its sticker) to a compartment,
 * a label, and a household — creating the household and ITS ACCESS KEY on
 * the spot when it is new. The office module's Install panel drives this.
 *
 *   POST /admin/install   { channelId, kind, label, field?, unit?,
 *                           householdId?  — or —  householdName?,
 *                           contactEmail?, contactPhone? }
 *   GET  /admin/customers  households for the picker (ids and names,
 *                           NEVER keys — a key is shown exactly once, in
 *                           the install response that created it)
 *
 * Gated by GUARDIAN_ADMIN_TOKEN in the server's environment; requests
 * carry it in the x-guardian-admin header. No token in the environment =
 * the endpoints are OFF, and say so. Keys are generated HERE
 * (crypto.randomBytes(24)) — never typed by hand, never chosen by a
 * client.
 */
const ADMIN_TOKEN = process.env.GUARDIAN_ADMIN_TOKEN || "";
const ADMIN_CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type, x-guardian-admin",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};

function adminGate(req, res) {
  if (!ADMIN_TOKEN) {
    res.writeHead(503, Object.assign({ "Content-Type": "application/json" }, ADMIN_CORS));
    res.end(JSON.stringify({ error: "Install endpoints are off: set GUARDIAN_ADMIN_TOKEN in the server's environment to enable them." }));
    return false;
  }
  if (String(req.headers["x-guardian-admin"] || "") !== ADMIN_TOKEN) {
    res.writeHead(403, Object.assign({ "Content-Type": "application/json" }, ADMIN_CORS));
    res.end(JSON.stringify({ error: "not authorized" }));
    return false;
  }
  return true;
}

function installSensor(body) {
  const channelId = String(body.channelId || body.devEui || "").trim().toLowerCase();
  if (!channelId) return { status: 400, error: "channelId (the DevEUI on the sensor's sticker) is required" };
  if (!KIND_ASSET[String(body.kind)]) return { status: 400, error: "kind must be fresh_food, freezer or wine" };
  const label = String(body.label || "").trim();
  if (!label) return { status: 400, error: "label is required — it is what the customer and the office both read" };

  /* The household: existing by id, or created with a fresh key. */
  let customer = null, created = false;
  if (body.householdId) {
    customer = customers.find(function (c) { return c.id === String(body.householdId); });
    if (!customer) return { status: 404, error: "no household with that id" };
  } else {
    const name = String(body.householdName || "").trim();
    if (!name) return { status: 400, error: "pick an existing household or name a new one" };
    customer = {
      id: "cust_" + crypto.randomBytes(6).toString("hex"),
      key: crypto.randomBytes(24).toString("hex"),
      name: name,
      channelIds: [],
      contact: {}
    };
    created = true;
    customers.push(customer);
  }
  if (body.contactEmail || body.contactPhone) {
    customer.contact = customer.contact || {};
    if (body.contactEmail) customer.contact.email = String(body.contactEmail).trim();
    if (body.contactPhone) customer.contact.phone = String(body.contactPhone).trim();
  }

  /* One sensor, one home: a channel already bound to a DIFFERENT household
     is refused — re-running an install for the same household is fine. */
  const elsewhere = customers.find(function (c) {
    return c.id !== customer.id && (c.channelIds || []).some(function (id) { return canonicalChannel(id) === channelId; });
  });
  if (elsewhere) return { status: 409, error: "that sensor is already bound to " + elsewhere.name + " — unbind it there first" };

  let sensor = findSensor(channelId);
  const isNew = !sensor;
  if (!sensor) {
    sensor = { channelId: channelId };
    sensors.sensors.push(sensor);
  }
  const previousKind = sensor.kind;
  sensor.kind = String(body.kind);
  sensor.label = label;
  sensor.field = String(body.field || sensor.field || "field7");
  sensor.unit = String(body.unit || sensor.unit || "C");
  /*
   * WHEN THE BURN-IN CLOCK RESTARTS.
   *
   * On a new binding, always: the sensor was just physically placed.
   * On a re-install, only when the COMPARTMENT changed (the probe moved,
   * so the placement is unproven again) or when the caller explicitly asks
   * -- because relabelling a sensor that has watched a fridge for a year
   * must not blind it for a day. `restartBurnIn` is the flag a technician
   * uses after re-seating a probe.
   */
  if (isNew || previousKind !== sensor.kind || body.restartBurnIn) {
    sensor.installedAt = new Date().toISOString();
    /* A moved probe's battery history is still its own, but its level
       should re-announce if it is low in its new home. */
    delete lastBatteryLevel[channelId];
  }

  customer.channelIds = customer.channelIds || [];
  if (!customer.channelIds.some(function (id) { return String(id) === channelId; })) {
    customer.channelIds.push(channelId);
  }
  saveRegistry();
  console.log(new Date().toISOString() + "  [INSTALL] " + label + " (" + channelId + ") -> " + customer.name + (created ? " (new household, key issued)" : ""));
  const out = {
    ok: true, created: created,
    sensor: { channelId: channelId, kind: sensor.kind, label: sensor.label, field: sensor.field, unit: sensor.unit,
              installedAt: sensor.installedAt || null },
    /* What the panel tells the technician standing at the fridge. */
    commissioning: SIM.commissioningState(sensor.installedAt, Date.now()),
    installNote: COMMISSIONING.installNote || "",
    customer: { id: customer.id, name: customer.name, channelIds: customer.channelIds }
  };
  /* The key crosses the wire exactly once: in the response that minted it.
     Every later listing omits it. */
  if (created) out.key = customer.key;
  return { status: 200, body: out };
}

/*
 * CUSTOMER ALERTING.                                             (v0.9.59)
 *
 * Cayden's #2: the customer should hear it from Wilson before they find a
 * warm fridge. On a DISPATCH or OFFLINE transition for a channel bound to
 * a household — and on the all-clear when it recovers — the server writes
 * a customer-voiced message to the notification OUTBOX
 * (guardian-pilot-notifications.jsonl, gitignored) and, when
 * CUSTOMER_ALERT_WEBHOOK_URL is set, POSTs it there as
 * {to, name, subject, text, tier, sensorLabel} — production points that at
 * the email/SMS sender (SendGrid, Twilio, the dashboard's own mailer);
 * the pilot proves the trigger, the copy and the dedupe.
 *
 * WARN never notifies a customer: warns are the office watching closely,
 * and a customer paged for every warm-up would learn to ignore the alert
 * that matters. Transitions-only firing (the same rule incidents use)
 * is the dedupe.
 */
const NOTIFY_FILE = dataFile("GUARDIAN_NOTIFY_FILE", "guardian-pilot-notifications.jsonl");

function customerFor(channelId) {
  return customers.find(function (c) {
    return (c.channelIds || []).some(function (id) { return canonicalChannel(id) === canonicalChannel(channelId); });
  }) || null;
}

function notifyCustomer(row) {
  const customer = customerFor(row.channelId);
  if (!customer) return;
  let subject, text;
  if (row.tier === "dispatch") {
    subject = "Wilson is responding — " + row.label;
    text = "Wilson Guardian detected a sustained temperature problem with " + row.label +
      (row.latest !== null && row.latest !== undefined ? " (currently " + row.latest + "°F)" : "") +
      ". Wilson has been alerted and is responding as a priority. You don't need to do anything — we'll be in touch.";
  } else if (row.tier === "offline") {
    subject = "A Guardian sensor is offline — " + row.label;
    text = "The Guardian sensor on " + row.label + " has stopped reporting — usually home WiFi or power. " +
      "While it's offline it can't warn anyone. If your internet is up, give Wilson a call and we'll get it sorted.";
  } else if (row.tier === "ok") {
    subject = "All clear — " + row.label;
    text = row.label + " is back in its safe range" +
      (row.latest !== null && row.latest !== undefined ? " (currently " + row.latest + "°F)" : "") +
      ". Wilson Guardian is watching as usual.";
  } else {
    return; /* warn and waiting stay the office's business */
  }
  const note = {
    at: new Date().toISOString(),
    customerId: customer.id, name: customer.name,
    to: customer.contact || {},
    tier: row.tier, sensorLabel: row.label,
    subject: subject, text: text
  };
  fs.appendFileSync(NOTIFY_FILE, JSON.stringify(note) + "\n");
  const hook = process.env.CUSTOMER_ALERT_WEBHOOK_URL;
  if (hook) {
    try {
      const url = new URL(hook);
      const payload = JSON.stringify(note);
      const req = (url.protocol === "https:" ? https : http).request(url, {
        method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) }
      }, function () {});
      req.on("error", function (err) { console.error("customer alert webhook failed: " + err.message); });
      req.end(payload);
    } catch (e) { console.error("bad CUSTOMER_ALERT_WEBHOOK_URL: " + e.message); }
  }
}

/* ---- drill labeling + training export ------------------------------------ */
function labelFor(channelId, epochMs) {
  const active = activeDrill(channelId);
  if (active && epochMs >= active.startedAt) return active.mode;
  for (let i = drills.history.length - 1; i >= 0; i--) {
    const d = drills.history[i];
    if (String(d.channelId) === String(channelId) && epochMs >= d.startedAt && epochMs <= d.endedAt) return d.mode;
  }
  return "healthy";
}

/*
 * The labeled dataset: everything in the durable training file, plus every
 * reading still in the live store that the training file does not already
 * have (labeled by drill window, "healthy" outside one). One row per
 * reading; sorted per channel by time.
 */
function trainingRows() {
  const rows = [];
  const seen = {};
  try {
    fs.readFileSync(TRAINING_FILE, "utf8").trim().split("\n").forEach(function (l) {
      if (!l) return;
      try {
        const r = JSON.parse(l);
        rows.push(r);
        seen[r.channelId + "|" + Date.parse(r.t)] = true;
      } catch (e) { /* a torn line from a crash mid-append; skip it */ }
    });
  } catch (e) { /* no training file yet */ }
  sensors.sensors.forEach(function (s) {
    const channelId = String(s.channelId);
    (store[channelId] || []).forEach(function (r) {
      if (seen[channelId + "|" + r.t]) return;
      rows.push({
        t: new Date(r.t).toISOString(),
        channelId: channelId,
        label: s.label || channelId,
        kind: s.kind,
        f: r.value,
        mode: labelFor(channelId, r.t)
      });
    });
  });
  rows.sort(function (a, b) {
    return a.channelId === b.channelId ? Date.parse(a.t) - Date.parse(b.t) : (a.channelId < b.channelId ? -1 : 1);
  });
  return rows;
}

function csvCell(v) {
  const s = String(v == null ? "" : v);
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function startDrill(body) {
  const channelId = String(body.channelId || "");
  const sensor = findSensor(channelId);
  if (!sensor) return { status: 400, error: "unknown channel " + channelId };
  const mode = String(body.mode || "");
  if (DRILL_MODES.indexOf(mode) === -1) {
    return { status: 400, error: "mode must be one of: " + DRILL_MODES.join(", ") };
  }
  if (drills.active[channelId]) {
    return { status: 409, error: "a '" + drills.active[channelId].mode + "' drill is already running on " + channelId + " — end it first" };
  }
  drills.active[channelId] = {
    channelId: channelId,
    mode: mode,
    note: body.note ? String(body.note) : "",
    startedAt: Date.now()
  };
  saveDrills();
  console.log(new Date().toISOString() + "  [DRILL START] " + (sensor.label || channelId) + " — " + mode);
  return { status: 200, drill: drills.active[channelId] };
}

function endDrill(body) {
  const channelId = String(body.channelId || "");
  const drill = drills.active[channelId];
  if (!drill) return { status: 404, error: "no active drill on " + channelId };
  delete drills.active[channelId];
  const done = Object.assign({}, drill, {
    endedAt: Date.now(),
    endNote: body.note ? String(body.note) : ""
  });
  drills.history.push(done);
  saveDrills();
  console.log(new Date().toISOString() + "  [DRILL END] " + channelId + " — " + done.mode +
    " (" + Math.round((done.endedAt - done.startedAt) / 60000) + " min)");
  return { status: 200, drill: done };
}

/* ---- http ---------------------------------------------------------------- */
const server = http.createServer(function (req, res) {
  if (req.method === "POST" && req.url === "/ubibot") {
    let body = "";
    req.on("data", function (c) { body += c; if (body.length > 2e6) req.destroy(); });
    req.on("end", function () {
      let outcome;
      try { outcome = ingestForwarding(JSON.parse(body)); }
      catch (e) { outcome = { ok: false, message: "unparseable payload" }; }
      evaluateAll();
      /* UbiBot judges the forwarding healthy by this exact body. */
      res.writeHead(outcome.ok ? 200 : 400, { "Content-Type": "text/plain" });
      res.end(outcome.ok ? "SUCCESS" : "ERROR");
    });
    return;
  }
  if (req.method === "POST" && (req.url === "/drill" || req.url === "/drill/end")) {
    let body = "";
    req.on("data", function (c) { body += c; if (body.length > 1e5) req.destroy(); });
    req.on("end", function () {
      let parsed;
      try { parsed = JSON.parse(body); } catch (e) { parsed = null; }
      const outcome = !parsed
        ? { status: 400, error: "unparseable body" }
        : (req.url === "/drill" ? startDrill(parsed) : endDrill(parsed));
      res.writeHead(outcome.status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(outcome.error ? { error: outcome.error } : { ok: true, drill: outcome.drill }));
    });
    return;
  }
  if (req.method === "GET" && req.url === "/drills") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ modes: DRILL_MODES, active: drills.active, history: drills.history }));
    return;
  }
  if (req.method === "GET" && req.url === "/export.jsonl") {
    res.writeHead(200, { "Content-Type": "application/x-ndjson" });
    res.end(trainingRows().map(function (r) { return JSON.stringify(r); }).join("\n") + "\n");
    return;
  }
  if (req.method === "GET" && req.url === "/export.csv") {
    const rows = trainingRows();
    res.writeHead(200, { "Content-Type": "text/csv; charset=utf-8" });
    res.end("t,channel_id,label,kind,temp_f,mode\n" + rows.map(function (r) {
      return [r.t, r.channelId, r.label, r.kind, r.f, r.mode].map(csvCell).join(",");
    }).join("\n") + "\n");
    return;
  }
  if (req.method === "OPTIONS" && req.url.indexOf("/admin/") === 0) {
    /* Preflight for the x-guardian-admin header from the dashboard origin. */
    res.writeHead(204, ADMIN_CORS);
    res.end();
    return;
  }
  if (req.method === "GET" && req.url === "/admin/customers") {
    if (!adminGate(req, res)) return;
    res.writeHead(200, Object.assign({ "Content-Type": "application/json" }, ADMIN_CORS));
    res.end(JSON.stringify({
      customers: customers.map(function (c) {
        return { id: c.id, name: c.name, channelIds: c.channelIds || [],
                 hasContact: Boolean(c.contact && (c.contact.email || c.contact.phone)) };
      })
    }));
    return;
  }
  if (req.method === "POST" && req.url === "/admin/install") {
    if (!adminGate(req, res)) return;
    let body = "";
    req.on("data", function (c) { body += c; if (body.length > 1e5) req.destroy(); });
    req.on("end", function () {
      let outcome;
      try { outcome = installSensor(JSON.parse(body)); }
      catch (e) { outcome = { status: 400, error: "unparseable body" }; }
      res.writeHead(outcome.status, Object.assign({ "Content-Type": "application/json" }, ADMIN_CORS));
      res.end(JSON.stringify(outcome.error ? { error: outcome.error } : outcome.body));
    });
    return;
  }
  if (req.method === "GET" && req.url.indexOf("/customer.json") === 0) {
    /* The customer's own sensors, and nothing else in the world. */
    let key = "";
    try { key = String(new URL(req.url, "http://x").searchParams.get("key") || ""); } catch (e) { key = ""; }
    const customer = key.length >= 24
      ? customers.find(function (c) { return c.key === key; })
      : null;
    if (!customer) {
      /* One answer for every kind of wrong: nothing to enumerate. */
      res.writeHead(404, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ error: "not found" }));
      return;
    }
    const now = Date.now();
    const own = sensors.sensors.filter(function (s) {
      return (customer.channelIds || []).some(function (id) { return canonicalChannel(id) === canonicalChannel(s.channelId); });
    });
    const payload = {
      name: customer.name || "Your home",
      generatedAt: new Date(now).toISOString(),
      sensors: own.map(function (s) {
        const row = evaluateSensor(s, now);
        const status = CUSTOMER_STATUS[row.tier] || CUSTOMER_STATUS.ok;
        const rule = RULES[s.kind] || RULES.fresh_food;
        return {
          label: s.label || "Refrigeration sensor",
          kind: s.kind,
          latest: row.latest,
          latestAt: row.latestAt,
          points: row.points,
          setpointF: rule.setpointF,
          status: status.code,
          statusLabel: status.label,
          statusNote: status.note
        };
      })
    };
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    res.end(JSON.stringify(payload));
    return;
  }
  if (req.method === "GET" && (req.url.indexOf("/history.json") === 0 || req.url.indexOf("/history.csv") === 0)) {
    /*
     * THE ANALYSIS ENDPOINT.
     *   /history.json?channel=<id>&from=<iso|epoch>&to=<iso|epoch>&maxPoints=1200
     *   /history.csv?channel=...            (same window, FULL resolution)
     * Defaults to the last 48 hours. Points are downsampled to maxPoints
     * with extremes preserved; stats always describe the full resolution.
     */
    const q = new URL(req.url, "http://x").searchParams;
    const channelId = String(q.get("channel") || "");
    const sensor = findSensor(channelId);
    if (!sensor) {
      res.writeHead(404, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ error: "unknown channel" }));
      return;
    }
    const parseTime = function (raw, fallback) {
      if (!raw) return fallback;
      const asNumber = Number(raw);
      if (Number.isFinite(asNumber) && String(raw).indexOf("-") === -1) return asNumber;
      const parsed = Date.parse(raw);
      return Number.isFinite(parsed) ? parsed : fallback;
    };
    const to = parseTime(q.get("to"), Date.now());
    const from = parseTime(q.get("from"), to - 48 * 3600000);
    const rows = historyRange(channelId, Math.min(from, to), Math.max(from, to));
    const rule = RULES[sensor.kind] || RULES.fresh_food;

    if (req.url.indexOf("/history.csv") === 0) {
      res.writeHead(200, {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="' + channelId + '-history.csv"',
        "Access-Control-Allow-Origin": "*"
      });
      /* Battery and radio ride in the same export: the RF pre-qualification
         week and the temperature story are one spreadsheet, not two. Empty
         cells for a UbiBot channel or a row written before v0.9.62. */
      res.end("t,channel_id,label,kind,temp_f,battery_v,rssi,snr\n" + rows.map(function (r) {
        return [new Date(r.t).toISOString(), channelId, sensor.label || channelId, sensor.kind, r.f,
                r.b === undefined ? "" : r.b, r.r === undefined ? "" : r.r, r.s === undefined ? "" : r.s]
          .map(csvCell).join(",");
      }).join("\n") + "\n");
      return;
    }
    const points = downsample(rows, Number(q.get("maxPoints") || 1200));
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    res.end(JSON.stringify({
      channel: channelId,
      label: sensor.label || channelId,
      kind: sensor.kind,
      from: new Date(Math.min(from, to)).toISOString(),
      to: new Date(Math.max(from, to)).toISOString(),
      rule: rule,
      rawCount: rows.length,
      downsampled: points.length < rows.length,
      points: points,
      stats: windowStats(rows, rule, Math.max(from, to))
    }));
    return;
  }
  if (req.method === "POST" && req.url === "/rehearsal/register") {
    /*
     * Self-provisioning, rehearsal only. Editing a registry by hand is
     * fine once; it is friction that stops an office ever practising if
     * it is required before every rehearsal. Two hard limits keep this
     * from being a hole: the server must be in rehearsal mode, and the
     * channel must carry the reserved synthetic prefix. No auth beyond
     * that, deliberately — a sandbox that needs a token is a sandbox
     * nobody uses, and it can hold nothing real by construction.
     */
    if (!REHEARSAL) {
      res.writeHead(403, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "not in rehearsal mode" }));
      return;
    }
    let body = "";
    req.on("data", function (c) { body += c; if (body.length > 1e5) req.destroy(); });
    req.on("end", function () {
      let parsed;
      try { parsed = JSON.parse(body); } catch (e) { parsed = null; }
      const channelId = canonicalChannel((parsed || {}).channelId);
      if (!parsed || !isSynthetic(channelId)) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "rehearsal registration accepts only channels beginning '" + SYNTHETIC_PREFIX + "'" }));
        return;
      }
      if (!KIND_ASSET[String(parsed.kind)]) {
        res.writeHead(400, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "kind must be fresh_food, freezer or wine" }));
        return;
      }
      let sensor = findSensor(channelId);
      if (!sensor) {
        sensor = { channelId: channelId };
        sensors.sensors.push(sensor);
      }
      sensor.kind = String(parsed.kind);
      sensor.label = String(parsed.label || ("Rehearsal " + channelId.slice(-4)));
      sensor.field = "field7";
      sensor.unit = "C";
      sensor.synthetic = true;
      saveRegistry();
      console.log(new Date().toISOString() + "  [REHEARSAL] registered " + sensor.label + " (" + channelId + ")");
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: true, sensor: { channelId: channelId, kind: sensor.kind, label: sensor.label } }));
    });
    return;
  }
  if (req.method === "GET" && req.url.indexOf("/prequal.json") === 0) {
    /*
     * THE RF PRE-QUALIFICATION INSTRUMENT.
     *   /prequal.json                      every sensor, last `minDays` days
     *   /prequal.json?channel=<id>         one sensor
     *   /prequal.json?from=&to=            an explicit window (iso or epoch)
     * Pass criteria come from config; see prequalReport() above.
     */
    const q = new URL(req.url, "http://x").searchParams;
    const to = (function () {
      const raw = q.get("to");
      if (!raw) return Date.now();
      const asNumber = Number(raw);
      if (Number.isFinite(asNumber) && String(raw).indexOf("-") === -1) return asNumber;
      const parsed = Date.parse(raw);
      return Number.isFinite(parsed) ? parsed : Date.now();
    })();
    const minDays = Number(PREQUAL.minDays) > 0 ? Number(PREQUAL.minDays) : 7;
    const from = (function () {
      const raw = q.get("from");
      if (!raw) return to - minDays * 86400000;
      const asNumber = Number(raw);
      if (Number.isFinite(asNumber) && String(raw).indexOf("-") === -1) return asNumber;
      const parsed = Date.parse(raw);
      return Number.isFinite(parsed) ? parsed : to - minDays * 86400000;
    })();
    const wanted = q.get("channel") ? [findSensor(q.get("channel"))].filter(Boolean) : sensors.sensors;
    if (q.get("channel") && !wanted.length) {
      res.writeHead(404, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
      res.end(JSON.stringify({ error: "unknown channel" }));
      return;
    }
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    res.end(JSON.stringify({
      from: new Date(Math.min(from, to)).toISOString(),
      to: new Date(Math.max(from, to)).toISOString(),
      sensors: wanted.map(function (s) { return prequalReport(s, Math.min(from, to), Math.max(from, to)); })
    }));
    return;
  }
  if (req.method === "GET" && req.url === "/status.json") {
    /* CORS: the dashboard's Guardian module (a page on another origin,
       e.g. the live dashboard) polls this endpoint for its live feed. The
       server still binds the office LAN only -- the header widens which
       PAGES may read it, not which networks can reach it. */
    res.writeHead(200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
    res.end(JSON.stringify({ sensors: statusRows(), incidents: lastIncidents(100), rules: RULES,
      /* Every consumer of this feed should be able to say out loud whether
         it is looking at invented data. */
      rehearsal: REHEARSAL,
      drills: { active: drills.active, history: drills.history } }));
    return;
  }
  if (req.method === "GET" && (req.url === "/" || req.url === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(statusPage());
    return;
  }
  /*
   * SERVE THE TWO PAGES FROM THE SERVER'S OWN ORIGIN.            (v0.9.65)
   *
   * guardian.html polls this server from the browser. Opened as a FILE it
   * has a null origin, and depending on the browser that fetch is blocked
   * or allowed on a whim — so the page renders and then sits there saying
   * the feed is unreachable, which looks like a broken product and is
   * actually a browser rule. Served from here it is same-origin and the
   * question never arises.
   *
   * A WHITELIST, not a static file server: exactly two names, matched
   * whole, resolved against ROOT. There is no path to traverse because
   * there is no path — a filename the list does not contain is a 404. A
   * general static handler on a box holding customer data would be a much
   * bigger promise than this needs to make.
   */
  if (req.method === "GET") {
    const wanted = req.url.split("?")[0];
    const PAGES = { "/guardian.html": true, "/guardian-customer.html": true };
    if (PAGES[wanted]) {
      const file = path.join(ROOT, wanted.slice(1));
      fs.readFile(file, function (err, body) {
        if (err) {
          res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
          res.end(wanted.slice(1) + " has not been built yet.\n" +
            "Run:  python3 tools/build_guardian_module.py\n");
          return;
        }
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(body);
      });
      return;
    }
  }
  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("not found");
});

server.listen(PORT, HOST, function () {
  if (REHEARSAL) {
    console.log("");
    console.log("  ****  REHEARSAL MODE  ****");
    console.log("  Synthetic readings are accepted (channels beginning '" + SYNTHETIC_PREFIX + "').");
    console.log("  Data files default into  " + DATA_DIR);
    console.log("  (any explicit GUARDIAN_*_FILE in the environment still wins).");
    console.log("  Nothing written here belongs in the real archive. Delete it when done.");
    console.log("");
  }
  console.log("Guardian pilot server on http://" + HOST + ":" + PORT +
    "  (" + sensors.sensors.length + " sensor" + (sensors.sensors.length === 1 ? "" : "s") +
    ", " + (POLL ? "polling UbiBot every 90s" : "waiting for data forwarding") + ")");
  if (POLL) { pollOnce(); setInterval(pollOnce, 90000); }
  setInterval(evaluateAll, 30000);
  evaluateAll();
});
