/*
 * WILSON REFRIGERATION GUARDIAN — iPhone HOME-SCREEN WIDGET        (v1.2)
 *
 * Cayden: "Can we make the temps on the customers end display as a widget
 * on their phones?"
 *
 * A true live home-screen widget normally needs a native app. This script
 * is the concierge shortcut: it runs inside SCRIPTABLE (free, on the App
 * Store), which renders real iOS widgets from JavaScript. Wilson's tech
 * sets it up on the customer's phone at install — about two minutes:
 *
 *   1. Install "Scriptable" from the App Store (free, by Simon Støvring).
 *   2. In Scriptable: + new script, paste this whole file, name it
 *      "Wilson Guardian".
 *   3. Fill in the two lines below (the customer's key, Wilson's feed URL).
 *   4. Long-press the home screen -> + -> Scriptable -> small or medium
 *      widget -> choose "Wilson Guardian".
 *
 * The widget shows each monitored compartment's current temperature with
 * a status dot, and when the sensors last reported. iOS refreshes widgets
 * on its own schedule (roughly every 15-30 minutes — that is an iOS
 * budget, not ours); tapping the widget opens the full charts page.
 *
 * It reads the SAME endpoint the customer page reads —
 * GET <feed>/customer.json?key=... — so the key shows this household and
 * nothing else, and there is nothing new to secure. The key lives on the
 * customer's own phone, which is exactly where their key belongs.
 *
 * Android note: no Scriptable there. The customer page installs to the
 * home screen as a one-tap app instead (menu -> Add to Home screen), and
 * the native Wilson app is the long-term answer on both platforms.
 */

// ---- fill in these two lines at setup ------------------------------------
const CUSTOMER_KEY = "PASTE-THE-CUSTOMER-KEY-HERE";
const FEED_URL = "https://guardian.wilsonappliance.com"; // Wilson's Guardian server
// The full charts page the widget opens when tapped:
const CHARTS_URL = "https://wilsonappliance.com/guardian-customer.html?key=" + encodeURIComponent(CUSTOMER_KEY);
// ---------------------------------------------------------------------------

const COLORS = {
  bg: new Color("#12331f"),
  ink: new Color("#f4f8f5"),
  sub: new Color("#9bb3a3"),
  protectedDot: new Color("#5fbe85"),
  watchingDot: new Color("#e4c767"),
  respondingDot: new Color("#e58a78"),
  offlineDot: new Color("#8a968c"),
  // A freshly installed sensor inside its burn-in window: charting, not
  // yet watching. It must NOT wear the green dot -- a green dot is the
  // one thing on this widget that means "you are covered".
  settlingDot: new Color("#8fa8cc")
};

function dotColor(status) {
  if (status === "responding") return COLORS.respondingDot;
  if (status === "watching") return COLORS.watchingDot;
  if (status === "offline" || status === "waiting") return COLORS.offlineDot;
  if (status === "settling") return COLORS.settlingDot;
  return COLORS.protectedDot;
}

function shortLabel(sensor) {
  // "Thermador Refrigerator — Kitchen (Fresh food)" is too long for a
  // widget row; keep the location and compartment, the parts the customer
  // thinks in.
  const label = String(sensor.label || "Sensor");
  const parts = label.split("—");
  return (parts.length > 1 ? parts[parts.length - 1] : label).trim();
}

async function fetchData() {
  const req = new Request(FEED_URL.replace(/\/$/, "") + "/customer.json?key=" + encodeURIComponent(CUSTOMER_KEY));
  req.timeoutInterval = 15;
  return await req.loadJSON();
}

function buildWidget(data, err) {
  const w = new ListWidget();
  w.backgroundColor = COLORS.bg;
  w.url = CHARTS_URL;
  w.setPadding(14, 14, 12, 14);

  const title = w.addText("WILSON GUARDIAN");
  title.font = Font.semiboldSystemFont(10);
  title.textColor = COLORS.sub;
  w.addSpacer(6);

  if (err) {
    const line = w.addText("Can't reach the Guardian server");
    line.font = Font.systemFont(12);
    line.textColor = COLORS.ink;
    w.addSpacer(2);
    const sub = w.addText("Temps resume when the connection returns.");
    sub.font = Font.systemFont(10);
    sub.textColor = COLORS.sub;
    return w;
  }

  const isSmall = (config.widgetFamily || "medium") === "small";
  const sensors = (data.sensors || []).slice(0, isSmall ? 2 : 4);

  sensors.forEach(function (s) {
    const row = w.addStack();
    row.centerAlignContent();

    const dot = row.addText("●");
    dot.font = Font.systemFont(9);
    dot.textColor = dotColor(s.status);
    row.addSpacer(6);

    const name = row.addText(shortLabel(s));
    name.font = Font.systemFont(isSmall ? 11 : 12);
    name.textColor = COLORS.sub;
    name.lineLimit = 1;
    row.addSpacer();

    const temp = row.addText(
      s.latest === null || s.latest === undefined ? "—" : Math.round(s.latest) + "°"
    );
    temp.font = Font.boldSystemFont(isSmall ? 15 : 16);
    temp.textColor = COLORS.ink;

    w.addSpacer(4);
  });

  w.addSpacer();
  const worst = (data.sensors || []).reduce(function (acc, s) {
    // Worst first. An UNKNOWN status returns -1 from indexOf, which would
    // sort ahead of everything and then fall through to the friendliest
    // label -- so unknown statuses are ignored rather than promoted.
    const order = ["responding", "offline", "watching", "waiting", "settling", "protected"];
    if (order.indexOf(s.status) === -1) return acc;
    return order.indexOf(s.status) < order.indexOf(acc) ? s.status : acc;
  }, "protected");
  const footText = worst === "protected" ? "Protected"
    : worst === "watching" ? "Watching closely"
    : worst === "responding" ? "Wilson alerted — responding"
    : worst === "offline" ? "A sensor is offline"
    : worst === "settling" ? "A new sensor is settling in"
    : "Waiting for readings";
  const foot = w.addText(footText + " · " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
  foot.font = Font.systemFont(9);
  foot.textColor = worst === "protected" ? COLORS.sub : dotColor(worst);
  return w;
}

let widget;
try {
  const data = await fetchData();
  widget = buildWidget(data, null);
} catch (e) {
  widget = buildWidget(null, e);
}

if (config.runsInWidget) {
  Script.setWidget(widget);
} else {
  await widget.presentMedium();
}
Script.complete();
